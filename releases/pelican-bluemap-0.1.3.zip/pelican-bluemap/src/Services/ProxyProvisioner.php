<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Models\Allocation;
use Ehaic\PelicanBlueMap\Clients\NpmClient;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Exceptions\NpmException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Support\SubdomainGenerator;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Contracts\Cache\LockTimeoutException;
use Illuminate\Support\Facades\Cache;

/** NPM proxy host + Let's Encrypt certificate lifecycle for one installation (D§8). */
class ProxyProvisioner
{
    public const MAX_LABEL_TRIES = 5;

    public const BUFFERING_NOTICE = 'Live updates may be delayed: ask an admin to add proxy_buffering off; to this host';

    /** @var list<string> non-fatal notices of the current operation (drained by takeNotices) */
    private static array $notices = [];

    /** @return list<string> */
    public static function takeNotices(): array
    {
        $n = self::$notices;
        self::$notices = [];

        return $n;
    }

    /**
     * Sends a host body with the fixed advanced_config; when NPM refuses it (non-admin plugin user) retries once
     * without it and records a non-fatal notice.
     *
     * @param \Closure(array<string, mixed>): array<string, mixed> $send
     * @param \Closure(bool): array<string, mixed> $bodyFor receives $withAdvanced
     * @return array<string, mixed>
     */
    public function sendHost(\Closure $send, \Closure $bodyFor): array
    {
        try {
            return $send($bodyFor(true));
        } catch (NpmException $e) {
            if (! NpmClient::isAdvancedConfigRefusal($e)) {
                throw $e;
            }
            Trace::warning('proxy.advanced_config_refused', ['status' => $e->status, 'error' => $e->getMessage()]);
        }
        $host = $send($bodyFor(false));
        if (! in_array(self::BUFFERING_NOTICE, self::$notices, true)) {
            self::$notices[] = self::BUFFERING_NOTICE;
        }

        return $host;
    }

    /**
     * Find or create the HTTP-only proxy host and record subdomain/fqdn/ids on the row.
     *
     * @return array<string, mixed> NpmHost
     */
    public function ensureHost(Installation $i, Allocation $a, ?string $requestedLabel): array
    {
        $npm = app(NpmClient::class);
        $settings = app(Settings::class);
        $forward = app(AllocationPicker::class)->forwardHost($a);
        $port = (int) $a->port;

        // Already created (by an earlier run): confirm it still exists.
        if ($i->npm_host_id !== null) {
            $host = $npm->getHost((int) $i->npm_host_id);
            if ($host !== null) {
                $this->record($i, $host, $a, $forward);

                return $host;
            }
            Trace::warning('proxy.host_vanished', ['npm_host_id' => $i->npm_host_id]);
            $i->npm_host_id = null;
            $i->save();
        }

        $lock = Cache::lock('pelican-bluemap:subdomain', 30);
        try {
            return $lock->block(10, fn () => $this->createHostLocked($i, $a, $requestedLabel, $forward, $port, $npm, $settings));
        } catch (LockTimeoutException) {
            throw new BlueMapException('Another BlueMap address is being created right now. Try again in a moment.');
        }
    }

    /** @return array<string, mixed> */
    private function createHostLocked(Installation $i, Allocation $a, ?string $requestedLabel, string $forward, int $port, NpmClient $npm, Settings $settings): array
    {
        $base = $settings->baseDomain();
        $gen = new SubdomainGenerator();
        $reserved = $settings->reservedSubdomains();

        $requestedLabel = $requestedLabel !== null ? strtolower(trim($requestedLabel)) : null;
        if ($requestedLabel === '') {
            $requestedLabel = null;
        }
        if ($requestedLabel !== null) {
            if (!$gen->isValidLabel($requestedLabel) || in_array($requestedLabel, $reserved, true)) {
                throw new BlueMapException('That subdomain is not allowed. Use 1-40 lowercase letters, digits or dashes (not starting or ending with a dash).');
            }
            $labels = [$requestedLabel];
        } else {
            $labels = array_slice($gen->candidates((string) $i->server->name, $reserved), 0, self::MAX_LABEL_TRIES);
        }
        if ($labels === []) {
            throw new BlueMapException('Could not build a subdomain from the server name. Enter one by hand.');
        }

        // Hosts this NPM user owns: adopts a host whose creation response was lost.
        $own = [];
        foreach ($npm->listHosts() as $h) {
            foreach ($h['domain_names'] ?? [] as $d) {
                $own[strtolower((string) $d)] = $h;
            }
        }

        foreach ($labels as $label) {
            $fqdn = "{$label}.{$base}";
            $takenByRow = Installation::query()->where('fqdn', $fqdn)->where('id', '!=', $i->id)->exists();
            if ($takenByRow) {
                continue;
            }
            if (isset($own[$fqdn])) {
                $host = $own[$fqdn];
                if ($this->hostBelongsElsewhere((int) $host['id'], $i)) {
                    continue;
                }
                Trace::info('proxy.host_adopted', ['npm_host_id' => $host['id'], 'fqdn' => $fqdn]);
                $this->record($i, $host, $a, $forward, $label, $fqdn);

                return $host;
            }

            try {
                $host = $this->sendHost(
                    fn (array $b) => $npm->createHost($b),
                    fn (bool $adv) => NpmClient::hostBody($fqdn, $forward, $port, 0, $settings->hsts(), $adv),
                );
            } catch (NpmException $e) {
                if ($e->alreadyInUse) {
                    Trace::info('proxy.label_taken', ['fqdn' => $fqdn]);

                    continue;
                }
                throw $e;
            }
            Trace::info('proxy.host_created', ['npm_host_id' => $host['id'], 'fqdn' => $fqdn]);
            $this->record($i, $host, $a, $forward, $label, $fqdn);

            return $host;
        }

        throw new BlueMapException($requestedLabel !== null
            ? 'That address is already taken. Choose another subdomain.'
            : 'Could not find a free subdomain after several tries. Enter one by hand.');
    }

    private function hostBelongsElsewhere(int $npmHostId, Installation $i): bool
    {
        return Installation::query()->where('npm_host_id', $npmHostId)->where('id', '!=', $i->id)->exists();
    }

    /** @param array<string, mixed> $host */
    private function record(Installation $i, array $host, Allocation $a, string $forward, ?string $label = null, ?string $fqdn = null): void
    {
        $i->npm_host_id = (int) $host['id'];
        $i->forward_host = $forward;
        $i->web_port = (int) $a->port;
        $i->allocation_id = (int) $a->id;
        if ($label !== null && $fqdn !== null) {
            $i->subdomain = $label;
            $i->fqdn = $fqdn;
        }
        $i->save();
    }

    /**
     * Find or create the certificate and attach it to the host. Never throws for Let's Encrypt failures.
     *
     * @return array{ok: bool, status: string, step: ?string, message: string, next: ?string}
     */
    public function ensureCertificate(Installation $i): array
    {
        $npm = app(NpmClient::class);
        $settings = app(Settings::class);
        $result = fn (bool $ok, string $msg) => ['ok' => $ok, 'status' => (string) $i->status, 'step' => 'certificate', 'message' => $msg, 'next' => null];

        if ($i->npm_host_id === null || $i->fqdn === null) {
            return $result(false, 'There is no proxy host yet. Retry the install first.');
        }

        $cooldownKey = 'pelican-bluemap:cert:cooldown:' . $i->server_id;
        $until = (int) Cache::get($cooldownKey, 0);
        if ($until > time()) {
            return $result(false, 'The last certificate attempt failed. Try again at ' . gmdate('H:i', $until) . ' UTC (this protects the Let\'s Encrypt rate limit).');
        }

        try {
            $cert = null;
            if ($i->npm_cert_id !== null) {
                $cert = $npm->getCertificate((int) $i->npm_cert_id);
            }
            if ($cert === null) {
                foreach ($npm->listCertificates() as $c) {
                    if (in_array(strtolower((string) $i->fqdn), array_map('strtolower', $c['domain_names'] ?? []), true)) {
                        $cert = $c;
                        break;
                    }
                }
            }

            if ($cert === null) {
                $cap = (int) config('pelican-bluemap.cert_hourly_cap', 10);
                Cache::add('pelican-bluemap:cert:hourly', 0, 3600);
                if ((int) Cache::get('pelican-bluemap:cert:hourly', 0) >= $cap) {
                    return $result(false, 'Too many certificate requests in the last hour. Try again later.');
                }
                Cache::increment('pelican-bluemap:cert:hourly');

                $i->cert_status = 'pending';
                $i->cert_error = null;
                $i->save();

                try {
                    $cert = $npm->createCertificate((string) $i->fqdn);
                } catch (\Throwable $e) {
                    return $this->certFailed($i, $e, $cooldownKey, true);
                }
            }

            $i->npm_cert_id = (int) $cert['id'];
            $i->save();

            try {
                $this->sendHost(
                    fn (array $b) => $npm->updateHost((int) $i->npm_host_id, $b),
                    fn (bool $adv) => NpmClient::hostBody((string) $i->fqdn, (string) $i->forward_host, (int) $i->web_port, (int) $cert['id'], $settings->hsts(), $adv),
                );
            } catch (\Throwable $e) {
                // The certificate exists; only attaching failed. A retry reuses it, so no cooldown.
                return $this->certFailed($i, $e, $cooldownKey, false, 'The certificate was issued but could not be attached to the proxy host: ');
            }

            $i->cert_status = 'issued';
            $i->cert_error = null;
            $i->cert_expires_at = !empty($cert['expires_on']) ? $this->parseDate((string) $cert['expires_on']) : null;
            $i->save();
            Trace::info('proxy.cert_issued', ['npm_cert_id' => $i->npm_cert_id, 'fqdn' => $i->fqdn]);

            return $result(true, 'HTTPS is on for https://' . $i->fqdn . '.');
        } catch (\Throwable $e) {
            return $this->certFailed($i, $e, $cooldownKey, false);
        }
    }

    private function certFailed(Installation $i, \Throwable $e, string $cooldownKey, bool $cooldown, string $prefix = ''): array
    {
        $msg = $e instanceof BlueMapException ? $e->getMessage() : 'Unexpected error while requesting the certificate (see the panel log).';
        Trace::warning('proxy.cert_failed', ['fqdn' => $i->fqdn, 'cause' => get_class($e), 'error' => $msg]);
        $i->cert_status = 'failed';
        $i->cert_error = mb_substr($prefix . $msg, 0, 1000);
        $i->save();
        if ($cooldown) {
            Cache::put($cooldownKey, time() + 60 * (int) config('pelican-bluemap.cert_cooldown_minutes', 15), 60 * (int) config('pelican-bluemap.cert_cooldown_minutes', 15));
        }

        return [
            'ok' => false, 'status' => (string) $i->status, 'step' => 'certificate',
            'message' => 'The map stays on plain HTTP. ' . $i->cert_error, 'next' => null,
        ];
    }

    private function parseDate(string $s): ?\Illuminate\Support\Carbon
    {
        try {
            return \Illuminate\Support\Carbon::parse($s);
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * PUT the host with the current forward target (and the certificate flags once HTTPS is on).
     *
     * @return array<string, mixed> NpmHost
     */
    public function syncHost(Installation $i, Allocation $a): array
    {
        if ($i->npm_host_id === null || $i->fqdn === null) {
            throw new BlueMapException('There is no proxy host to update.');
        }
        $forward = app(AllocationPicker::class)->forwardHost($a);
        $certId = $i->cert_status === 'issued' && $i->npm_cert_id !== null ? (int) $i->npm_cert_id : 0;
        $npm = app(NpmClient::class);
        $hsts = app(Settings::class)->hsts();
        $host = $this->sendHost(
            fn (array $b) => $npm->updateHost((int) $i->npm_host_id, $b),
            fn (bool $adv) => NpmClient::hostBody((string) $i->fqdn, $forward, (int) $a->port, $certId, $hsts, $adv),
        );
        $i->forward_host = $forward;
        $i->web_port = (int) $a->port;
        $i->allocation_id = (int) $a->id;
        $i->save();

        return $host;
    }

    /** Deletes the host (404 = already gone). Also finds an unrecorded host with our fqdn (lost response). */
    public function removeHost(Installation $i): void
    {
        $npm = app(NpmClient::class);
        $id = $i->npm_host_id;
        if ($id === null && $i->fqdn !== null) {
            foreach ($npm->listHosts() as $h) {
                if (in_array(strtolower((string) $i->fqdn), array_map('strtolower', $h['domain_names'] ?? []), true)) {
                    $id = (int) $h['id'];
                    break;
                }
            }
        }
        if ($id !== null) {
            $npm->deleteHost((int) $id);
            Trace::info('proxy.host_deleted', ['npm_host_id' => $id]);
        }
        $i->npm_host_id = null;
        $i->save();
    }

    /** Deletes the certificate (only after the host is gone: NPM refuses to delete one in use). */
    public function removeCertificate(Installation $i): void
    {
        $npm = app(NpmClient::class);
        $id = $i->npm_cert_id;
        if ($id === null && $i->fqdn !== null) {
            foreach ($npm->listCertificates() as $c) {
                if (in_array(strtolower((string) $i->fqdn), array_map('strtolower', $c['domain_names'] ?? []), true)) {
                    $id = (int) $c['id'];
                    break;
                }
            }
        }
        if ($id !== null) {
            $npm->deleteCertificate((int) $id);
            Trace::info('proxy.cert_deleted', ['npm_cert_id' => $id]);
        }
        $i->npm_cert_id = null;
        $i->cert_status = 'none';
        $i->cert_error = null;
        $i->cert_expires_at = null;
        $i->save();
    }

    /** @return array{host: ?array<string, mixed>, cert: ?array<string, mixed>, error: ?string} */
    public function status(Installation $i): array
    {
        $npm = app(NpmClient::class);
        $host = null;
        $cert = null;
        $error = null;
        try {
            if ($i->npm_host_id !== null) {
                $host = $npm->getHost((int) $i->npm_host_id);
                if ($host === null) {
                    $error = 'The proxy host no longer exists in Nginx Proxy Manager.';
                }
            }
            if ($i->npm_cert_id !== null) {
                $cert = $npm->getCertificate((int) $i->npm_cert_id);
            }
        } catch (\Throwable $e) {
            $error = $e instanceof BlueMapException ? $e->getMessage() : 'Could not read Nginx Proxy Manager.';
        }

        return ['host' => $host, 'cert' => $cert, 'error' => $error];
    }
}
