<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Models\User;
use App\Repositories\Daemon\DaemonServerRepository;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Exceptions\ServerNotStoppedException;

/** Stopped-server rule, conflict states and permission checks (D§3). */
class ServerGuard
{
    private ?Server $server = null;

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;

        return $new;
    }

    /** Fresh state from Wings (never cached): running|starting|stopping|offline, or "missing" when unreachable. */
    public function state(): string
    {
        try {
            $details = app(DaemonServerRepository::class)->setServer($this->server())->getDetails(5);
        } catch (\Throwable) {
            return 'missing';
        }

        return (string) ($details['state'] ?? 'missing');
    }

    public function isStopped(): bool
    {
        return $this->state() === 'offline';
    }

    public function assertStopped(): void
    {
        // Suspended, installing, restoring a backup, transferring: Wings may say "offline" but files must not change.
        $fresh = $this->server()->fresh();
        if ($fresh === null || $fresh->isInConflictState()) {
            throw new BlueMapException('The server is suspended, installing, restoring a backup or being transferred. Try again later.');
        }

        $state = $this->state();
        if ($state !== 'offline') {
            throw new ServerNotStoppedException($state);
        }
    }

    public function can(?User $user, SubuserPermission ...$perms): bool
    {
        if ($user === null) {
            return false;
        }
        foreach ($perms as $perm) {
            if (!$user->can($perm, $this->server())) {
                return false;
            }
        }

        return true;
    }

    public function assertCan(?User $user, SubuserPermission ...$perms): void
    {
        if (!$this->can($user, ...$perms)) {
            $names = implode(', ', array_map(fn (SubuserPermission $p) => $p->value, $perms));
            throw new BlueMapException("You don't have permission to do this on this server (needs: {$names}).");
        }
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }
}
