<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Models\Allocation;
use App\Models\Server;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Support\Settings;

/** Picks and describes the server allocation BlueMap's web server listens on (D§8.1, D§8.2). */
class AllocationPicker
{
    public const NOTE = 'BlueMap web';

    /**
     * Non-primary allocations of the server: "bluemap" notes first, then the current one, then by port.
     *
     * @return list<Allocation>
     */
    public function candidates(Server $server, ?int $currentId = null): array
    {
        $all = $server->allocations()->where('id', '!=', $server->allocation_id)->get()->all();
        usort($all, function (Allocation $a, Allocation $b) use ($currentId) {
            $rank = fn (Allocation $x) => str_contains(strtolower((string) $x->notes), 'bluemap') ? 0 : ((int) $x->id === $currentId ? 1 : 2);

            return [$rank($a), (int) $a->port] <=> [$rank($b), (int) $b->port];
        });

        return array_values($all);
    }

    /** Must belong to the server and not be its primary allocation. */
    public function resolve(Server $server, int $allocationId): Allocation
    {
        $a = $server->allocations()->where('id', $allocationId)->first();
        if ($a === null) {
            throw new BlueMapException('That port does not belong to this server.');
        }
        if ((int) $a->id === (int) $server->allocation_id) {
            throw new BlueMapException("The server's main port can't be used for the map; pick another allocation.");
        }

        return $a;
    }

    /** Where NPM sends traffic: the setting, else the allocation's concrete IP, else the node's FQDN. */
    public function forwardHost(Allocation $a): string
    {
        $setting = app(Settings::class)->forwardHost();
        if ($setting !== null && $setting !== '') {
            return $setting;
        }
        $ip = trim((string) $a->ip);
        if ($ip !== '' && !in_array($ip, ['0.0.0.0', '::', '[::]'], true) && !str_starts_with($ip, '127.') && $ip !== '::1') {
            return $ip;
        }

        return (string) $a->node->fqdn;
    }

    public function label(Allocation $a): string
    {
        $ip = (string) $a->ip;
        $addr = (str_contains($ip, ':') ? "[{$ip}]" : $ip) . ':' . (int) $a->port;
        $note = trim((string) $a->notes);

        return $note !== '' ? "{$addr} ({$note})" : $addr;
    }

    /** Sets the note "BlueMap web" only when there is none. */
    public function tagNote(Allocation $a): void
    {
        if (trim((string) $a->notes) === '') {
            $a->notes = self::NOTE;
            $a->save();
        }
    }

    /** Clears the note only if it is exactly ours. */
    public function clearNote(Allocation $a): void
    {
        if ($a->notes === self::NOTE) {
            $a->notes = null;
            $a->save();
        }
    }
}
