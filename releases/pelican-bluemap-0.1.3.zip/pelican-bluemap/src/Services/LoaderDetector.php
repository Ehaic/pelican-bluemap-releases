<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Models\Server;
use Ehaic\PelicanBlueMap\Support\ConfigRenderer;

/**
 * Works out the loader, the Minecraft version and what BlueMap already exists on a server (D§4).
 * The static helpers are pure and unit-tested; detect() reads the server through Wings.
 *
 * @phpstan-type MapEntry array{id: string, file: string, storage: ?string}
 */
class LoaderDetector
{
    public const LOADERS = ['fabric', 'forge', 'neoforge', 'paper', 'spigot', 'sponge', 'vanilla', 'unknown'];

    private const MAX_CONF_BYTES = 1024 * 1024;

    private ?Server $server = null;

    /** @var array<string, list<array{name: string, size: int, is_file: bool, modified: ?string}>> per-request listing cache */
    private array $listings = [];

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->listings = [];

        return $new;
    }

    // ------------------------------------------------------------------ detect

    /**
     * @return array{loader: string, loader_source: string, mc_version: ?string, mc_source: string,
     *               jar_dir: ?string, config_dir: ?string, existing_jars: list<array{name: string, size: int}>,
     *               config_exists: bool, maps: list<array{id: string, file: string, storage: ?string}>,
     *               fabric_api_present: bool, driver_present: bool}
     */
    public function detect(?string $loaderOverride = null, ?string $mcOverride = null): array
    {
        $server = $this->server();
        $files = app(ServerFiles::class)->forServer($server);
        $vars = $this->eggVariables();
        $eggName = (string) ($server->egg?->name ?? '');

        // --- loader
        $probes = [];
        foreach (self::PROBES as $path) {
            $probes[$path] = $this->listed($path);
        }
        $loader = self::loaderFromProbes($probes);
        $loaderSource = 'files';
        if ($loader === null) {
            $loader = self::loaderFromEggVariables($vars, $eggName);
            $loaderSource = 'egg_variable';
        }
        if ($loader === null) {
            $loader = self::loaderFromEggName($eggName);
            $loaderSource = 'egg_name';
        }
        if ($loader === null) {
            $loader = 'unknown';
            $loaderSource = 'none';
        }
        if ($loaderOverride !== null && in_array($loaderOverride, self::LOADERS, true) && $loaderOverride !== 'unknown') {
            if ($loaderOverride !== $loader) {
                $loaderSource = 'none';
            }
            $loader = $loaderOverride;
        }

        // --- Minecraft version
        [$mc, $mcSource] = $this->detectMc($files, $vars);
        if ($mcOverride !== null && self::isConcreteVersion($mcOverride)) {
            if ($mcOverride !== $mc) {
                $mcSource = 'none';
            }
            $mc = $mcOverride;
        }

        // --- what exists already
        $layout = self::layoutFor($loader);
        $jarDir = $layout['jar_dir'] ?? null;
        $configDir = $layout['config_dir'] ?? null;

        $existing = [];
        $fabricApi = false;
        if ($jarDir !== null) {
            foreach ($this->listDir($jarDir) as $e) {
                if (!$e['is_file']) {
                    continue;
                }
                if (self::isBlueMapJar($e['name'])) {
                    $existing[] = ['name' => $e['name'], 'size' => $e['size']];
                }
                if (self::isFabricApiJar($e['name'])) {
                    $fabricApi = true;
                }
            }
        }

        $maps = [];
        $configExists = false;
        if ($configDir !== null) {
            $configExists = $this->listed($configDir);
            foreach ($this->listDir($configDir . '/maps') as $e) {
                if (!$e['is_file'] || !str_ends_with($e['name'], '.conf')) {
                    continue;
                }
                $text = $files->read($configDir . '/maps/' . $e['name'], self::MAX_CONF_BYTES);
                $maps[] = [
                    'id' => substr($e['name'], 0, -5),
                    'file' => $configDir . '/maps/' . $e['name'],
                    'storage' => $text === null ? null : self::parseMapStorage($text),
                ];
            }
        }

        $driverFile = (string) config('pelican-bluemap.jdbc_driver.filename', 'mariadb-java-client-3.5.11.jar');
        $driverPresent = false;
        foreach ($this->listDir('bluemap/drivers') as $e) {
            if ($e['is_file'] && $e['name'] === $driverFile) {
                $driverPresent = true;
            }
        }

        return [
            'loader' => $loader, 'loader_source' => $loaderSource,
            'mc_version' => $mc, 'mc_source' => $mcSource,
            'jar_dir' => $jarDir, 'config_dir' => $configDir,
            'existing_jars' => $existing,
            'config_exists' => $configExists,
            'maps' => $maps,
            'fabric_api_present' => $fabricApi,
            'driver_present' => $driverPresent,
        ];
    }

    /** @return array{0: ?string, 1: string} [version, source] */
    private function detectMc(ServerFiles $files, array $vars): array
    {
        // 1. latest.log (vanilla line, printed by every loader)
        $max = (int) config('pelican-bluemap.max_log_bytes', 8 * 1024 * 1024);
        $log = $files->read('logs/latest.log', $max);
        if ($log !== null && ($v = self::mcFromLog($log)) !== null) {
            return [$v, 'log'];
        }

        // 2. versions/ folder
        $names = array_map(fn ($e) => $e['name'], array_filter($this->listDir('versions'), fn ($e) => !$e['is_file']));
        if (($v = self::mcFromVersionsDir(array_values($names))) !== null) {
            return [$v, 'versions_dir'];
        }

        // 3 + 4. libraries
        $names = [];
        foreach (['libraries/net/minecraft/server', 'libraries/net/minecraftforge/forge', 'libraries/net/neoforged/forge'] as $d) {
            foreach ($this->listDir($d) as $e) {
                if (!$e['is_file']) {
                    $names[] = $e['name'];
                }
            }
        }
        if (($v = self::mcFromLibraryDirs($names)) !== null) {
            return [$v, 'libraries'];
        }

        // 5. egg variables
        foreach (['MC_VERSION', 'MINECRAFT_VERSION', 'VANILLA_VERSION'] as $key) {
            $val = trim((string) ($vars[$key] ?? ''));
            if (self::isConcreteVersion($val)) {
                return [$val, 'egg_variable'];
            }
        }

        // 6. NeoForge version
        $neo = trim((string) ($vars['NEOFORGE_VERSION'] ?? ''));
        if ($neo !== '' && ($v = self::mcFromNeoForge($neo)) !== null) {
            return [$v, 'neoforge_version'];
        }

        return [null, 'none'];
    }

    /** Egg variables: env_variable => effective value (server value, else the egg default). */
    private function eggVariables(): array
    {
        $out = [];
        try {
            foreach ($this->server()->variables as $var) {
                $out[(string) $var->env_variable] = (string) ($var->server_value ?? $var->default_value ?? '');
            }
        } catch (\Throwable) {
            // Detection still works from files and the egg name.
        }

        return $out;
    }

    // ------------------------------------------------------------------ probing

    /** Paths probed for the loader (a file or directory each). */
    private const PROBES = [
        'libraries/net/neoforged/neoforge', 'libraries/net/neoforged/forge', 'libraries/net/minecraftforge/forge',
        '.fabric', 'fabric-server-launch.jar', 'fabric-server-launcher.properties',
        'config/sponge', 'libraries/org/spongepowered',
        'config/paper-global.yml', 'paper.yml', 'purpur.yml', 'spigot.yml',
    ];

    /** @return list<array{name: string, size: int, is_file: bool, modified: ?string}> */
    private function listDir(string $dir): array
    {
        return $this->listings[$dir] ??= app(ServerFiles::class)->forServer($this->server())->list($dir);
    }

    private function listed(string $path): bool
    {
        $parent = dirname($path);
        $name = basename($path);
        foreach ($this->listDir($parent === '.' ? '' : $parent) as $e) {
            if ($e['name'] === $name) {
                return true;
            }
        }

        return false;
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }

    // ------------------------------------------------------------------ pure helpers

    /** @return array{jar_dir: string, config_dir: string}|null */
    public static function layoutFor(string $loader): ?array
    {
        return match ($loader) {
            'fabric', 'forge', 'neoforge', 'sponge' => ['jar_dir' => 'mods', 'config_dir' => 'config/bluemap'],
            'paper', 'spigot' => ['jar_dir' => 'plugins', 'config_dir' => 'plugins/BlueMap'],
            default => null,
        };
    }

    /** "Starting minecraft server version 1.21.1" (the last such line wins); snapshots like 24w14a give null. */
    public static function mcFromLog(string $log): ?string
    {
        if (preg_match_all('/Starting minecraft server version (\S+)/', $log, $m) && $m[1] !== []) {
            $v = end($m[1]);

            return self::isConcreteVersion($v) ? $v : null;
        }

        return null;
    }

    /** Exactly one distinct concrete version folder → that version. @param list<string> $dirNames */
    public static function mcFromVersionsDir(array $dirNames): ?string
    {
        $found = array_values(array_unique(array_filter($dirNames, fn ($n) => self::isConcreteVersion($n))));

        return count($found) === 1 ? $found[0] : null;
    }

    /** "1.21.1-20240808.144430" / "1.20.1-47.2.0" → "1.21.1"; several distinct versions → null. @param list<string> $dirNames */
    public static function mcFromLibraryDirs(array $dirNames): ?string
    {
        $found = [];
        foreach ($dirNames as $n) {
            $v = explode('-', $n, 2)[0];
            if (self::isConcreteVersion($v)) {
                $found[$v] = true;
            }
        }

        return count($found) === 1 ? (string) array_key_first($found) : null;
    }

    /** "21.1.77" → "1.21.1", "20.4.237" → "1.20.4", "21.0.1" → "1.21". Year-based versions (>= 25) → null. */
    public static function mcFromNeoForge(string $neoVersion): ?string
    {
        if (!preg_match('/^(\d+)\.(\d+)(?:\.|-|$)/', trim($neoVersion), $m)) {
            return null;
        }
        $a = (int) $m[1];
        $b = (int) $m[2];
        if ($a < 20 || $a >= 25) {
            return null;
        }

        return $b === 0 ? "1.{$a}" : "1.{$a}.{$b}";
    }

    /** @param array<string, string> $vars env_variable => value */
    public static function loaderFromEggVariables(array $vars, string $eggName): ?string
    {
        $has = fn (string $k) => trim((string) ($vars[$k] ?? '')) !== '';
        $name = strtolower($eggName);

        if ($has('NEOFORGE_VERSION')) {
            return 'neoforge';
        }
        if ($has('FABRIC_VERSION') || $has('LOADER_VERSION')) {
            return 'fabric';
        }
        if ($has('SPONGE_TYPE') || $has('SPONGE_VERSION')) {
            return 'sponge';
        }
        if ($has('FORGE_VERSION') && !str_contains($name, 'sponge')) {
            return 'forge';
        }
        $project = strtolower(trim((string) ($vars['PROJECT'] ?? '')));
        if (in_array($project, ['paper', 'folia', 'purpur'], true)) {
            return 'paper';
        }
        if ($has('BUILD_NUMBER') && (str_contains($name, 'paper') || str_contains($name, 'purpur'))) {
            return 'paper';
        }

        return null;
    }

    public static function loaderFromEggName(string $eggName): ?string
    {
        // "CurseForge" and "FTB" are modpack eggs, not "Forge" eggs.
        $n = str_replace('curseforge', '', strtolower($eggName));

        return match (true) {
            str_contains($n, 'neoforge') => 'neoforge',
            str_contains($n, 'sponge') => 'sponge',
            str_contains($n, 'forge') => 'forge',
            (bool) preg_match('/paper|purpur|folia|pufferfish/', $n) => 'paper',
            (bool) preg_match('/spigot|bukkit/', $n) => 'spigot',
            str_contains($n, 'fabric') => 'fabric',
            str_contains($n, 'vanilla') => 'vanilla',
            default => null,
        };
    }

    /** @param array<string, bool> $probes probe path => exists */
    public static function loaderFromProbes(array $probes): ?string
    {
        $has = fn (string $p) => ($probes[$p] ?? false) === true;

        return match (true) {
            $has('libraries/net/neoforged/neoforge'), $has('libraries/net/neoforged/forge') => 'neoforge',
            $has('libraries/net/minecraftforge/forge') => 'forge',
            $has('.fabric'), $has('fabric-server-launch.jar'), $has('fabric-server-launcher.properties') => 'fabric',
            $has('config/sponge') => 'sponge',
            // Paper bundles Sponge's Configurate (libraries/org/spongepowered/configurate-*), so Paper's own
            // files must win over that library folder.
            $has('config/paper-global.yml'), $has('paper.yml'), $has('purpur.yml') => 'paper',
            $has('spigot.yml') => 'spigot',
            $has('libraries/org/spongepowered') => 'sponge',
            default => null,
        };
    }

    public static function isBlueMapJar(string $name): bool
    {
        return (bool) preg_match('/^bluemap.*\.jar$/i', $name);
    }

    public static function isFabricApiJar(string $name): bool
    {
        return (bool) preg_match('/^fabric-api-\d[^\/]*\.jar$/i', $name);
    }

    public static function isConcreteVersion(string $v): bool
    {
        return (bool) preg_match('/^\d+\.\d+(\.\d+)?$/', $v);
    }

    /** The map's storage id ("file", "sql", ...), null when not set. */
    public static function parseMapStorage(string $hocon): ?string
    {
        return ConfigRenderer::getTopLevelKey($hocon, 'storage');
    }
}
