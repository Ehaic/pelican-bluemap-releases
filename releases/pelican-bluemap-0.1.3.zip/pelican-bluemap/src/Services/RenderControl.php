<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Models\User;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Support\Trace;

/** BlueMap console commands (pause, resume, update, ...). Each is one fixed string; only a validated map id is appended. */
class RenderControl
{
    public const ACTIONS = [
        'pause' => 'bluemap stop', 'resume' => 'bluemap start', 'update' => 'bluemap update',
        'force_update' => 'bluemap force-update', 'reload' => 'bluemap reload light', 'purge' => 'bluemap purge',
    ];

    private ?Server $server = null;
    private ?User $user = null;

    public function forServer(Server $server, ?User $user): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->user = $user;

        return $new;
    }

    /** @return array{ok: bool, status: string, step: ?string, message: string, next: ?string} */
    public function send(string $action, ?string $mapId = null): array
    {
        $server = $this->server ?? throw new \LogicException('Call forServer() first.');
        Trace::begin((int) $server->id);
        $status = 'none';

        try {
            $guard = app(ServerGuard::class)->forServer($server);
            $guard->assertCan($this->user, SubuserPermission::ControlConsole);

            $row = Installation::forServer($server) ?? throw new BlueMapException('BlueMap is not installed on this server.');
            $status = (string) $row->status;

            if (!array_key_exists($action, self::ACTIONS)) {
                throw new BlueMapException('Unknown BlueMap action.');
            }
            $command = self::ACTIONS[$action];
            $commands = [$command];
            if ($action === 'update' || $action === 'force_update') {
                // From the console BlueMap needs a target: a bare "bluemap update" answers "Not enough
                // arguments!" (seen live with BlueMap 5.16). Send one command per map.
                $maps = app(LoaderDetector::class)->forServer($server)->detect($row->loader, $row->mc_version)['maps'];
                $commands = self::perMapCommands($command, array_column($maps, 'id'));
                if ($commands === []) {
                    throw new BlueMapException('BlueMap has no maps yet. Start the server once and wait for BlueMap to load.');
                }
            }

            if ($action === 'purge') {
                if ($mapId === null || !preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $mapId)) {
                    throw new BlueMapException('Pick a map to purge.');
                }
                $maps = app(LoaderDetector::class)->forServer($server)->detect($row->loader, $row->mc_version)['maps'];
                if (!in_array($mapId, array_column($maps, 'id'), true)) {
                    throw new BlueMapException('That map does not exist on this server.');
                }
                $commands = [$command . ' ' . $mapId];
            }

            if ($guard->state() !== 'running') {
                throw new BlueMapException('The server must be running to send BlueMap commands.');
            }

            foreach ($commands as $c) {
                $server->send($c);
            }
            Trace::info('render.sent', ['action' => $action, 'map' => $mapId]);

            return ['ok' => true, 'status' => $status, 'step' => null, 'message' => 'Sent. See the console for output.', 'next' => null];
        } catch (BlueMapException $e) {
            return ['ok' => false, 'status' => $status, 'step' => null, 'message' => $e->getMessage(), 'next' => null];
        } catch (\Throwable $e) {
            report($e);
            Trace::error('render.failed', ['action' => $action, 'cause' => get_class($e)]);

            return ['ok' => false, 'status' => $status, 'step' => null, 'message' => 'Could not send the command to the server (it may be offline).', 'next' => null];
        } finally {
            Trace::end();
        }
    }

    /**
     * "<command> <map id>" for every valid map id (ids are checked: they end up on the server console).
     *
     * @param array<int, mixed> $mapIds
     * @return list<string>
     */
    public static function perMapCommands(string $command, array $mapIds): array
    {
        $out = [];
        foreach ($mapIds as $id) {
            if (is_string($id) && preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $id) === 1) {
                $out[] = $command . ' ' . $id;
            }
        }

        return array_values(array_unique($out));
    }
}
