<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Exceptions\Repository\DuplicateDatabaseNameException;
use App\Exceptions\Service\Database\DatabaseClientFeatureNotEnabledException;
use App\Exceptions\Service\Database\NoSuitableDatabaseHostException;
use App\Exceptions\Service\Database\TooManyDatabasesException;
use App\Models\Database;
use App\Models\DatabaseHost;
use App\Models\Server;
use App\Services\Databases\DatabaseManagementService;
use App\Services\Databases\DeployServerDatabaseService;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Support\ConfigRenderer;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Support\Facades\Cache;

/** The map database: created through the panel's own services (D§7). */
class DatabaseProvisioner
{
    public const DB_SUFFIX = 'bluemap';

    /** Below this a BlueMap texture save can fail with "Got a packet bigger than 'max_allowed_packet' bytes" (MariaDB default: 16 MiB). */
    public const MIN_PACKET_BYTES = 64 * 1024 * 1024;

    /** Seconds a host's max_allowed_packet is remembered (the preflight runs on every page render). */
    private const PACKET_TTL = 120;

    /** @return array{ok: bool, reason: ?string, existing_database_id: ?int} */
    public function preflight(Server $server, ?int $databaseId): array
    {
        $existing = $this->adoptable($server, $databaseId);
        if ($existing !== null) {
            return ['ok' => true, 'reason' => null, 'existing_database_id' => (int) $existing->id];
        }

        $fail = fn (string $reason) => ['ok' => false, 'reason' => $reason, 'existing_database_id' => null];

        if (!config('panel.client_features.databases.enabled')) {
            return $fail('Databases are turned off in the panel. Ask an admin to enable them.');
        }
        $limit = $server->database_limit;
        $used = $server->databases()->count();
        if ($limit === null || (int) $limit === 0) {
            return $fail("This server's database limit is 0. Ask an admin to set Feature Limits → Databases to at least 1.");
        }
        if ($used >= (int) $limit) {
            return $fail("This server already uses {$used} of {$limit} databases. Ask an admin to raise Feature Limits → Databases, or delete one.");
        }
        if (DatabaseHost::query()->count() === 0) {
            return $fail('No database host is configured in the panel. Ask an admin to add one.');
        }

        return ['ok' => true, 'reason' => null, 'existing_database_id' => null];
    }

    /** @return array{database: Database, created: bool} */
    public function ensure(Server $server, ?int $databaseId): array
    {
        $existing = $this->adoptable($server, $databaseId);
        if ($existing !== null) {
            return ['database' => $existing, 'created' => false];
        }

        $pre = $this->preflight($server, null);
        if (!$pre['ok']) {
            throw new BlueMapException((string) $pre['reason']);
        }

        try {
            $db = app(DeployServerDatabaseService::class)->handle($server, ['database' => self::DB_SUFFIX, 'remote' => '%']);
        } catch (TooManyDatabasesException) {
            throw new BlueMapException("This server's database limit is reached. Ask an admin to raise it.");
        } catch (NoSuitableDatabaseHostException) {
            throw new BlueMapException('No suitable database host is available for this server. Ask an admin to link one to its node.');
        } catch (DatabaseClientFeatureNotEnabledException) {
            throw new BlueMapException('Databases are turned off in the panel. Ask an admin to enable them.');
        } catch (DuplicateDatabaseNameException) {
            throw new BlueMapException("A database named s{$server->id}_" . self::DB_SUFFIX . ' already exists for this server.');
        }

        Trace::info('db.created', ['database' => $db->database, 'id' => $db->id]);

        return ['database' => $db, 'created' => true];
    }

    /** @return array{host: string, port: int, database: string, user: string, password: string, url: string} */
    public function jdbcTarget(Database $db): array
    {
        $settings = app(Settings::class);
        $host = $settings->jdbcHost() ?? (string) $db->host->host;
        $port = $settings->jdbcPort() ?? (int) $db->host->port;
        Trace::addSecret((string) $db->password);

        return [
            'host' => $host, 'port' => $port, 'database' => (string) $db->database,
            'user' => (string) $db->username, 'password' => (string) $db->password,
            'url' => ConfigRenderer::jdbcUrl($host, $port, (string) $db->database),
        ];
    }

    /**
     * Panel → database check with the map database's own credentials (3 s timeout), counting BlueMap's tables.
     *
     * @return array{ok: bool, tables: ?int, error: ?string}
     */
    public function testConnection(Database $db): array
    {
        $host = $db->host;
        try {
            $pdo = new \PDO(
                'mysql:host=' . $host->host . ';port=' . (int) $host->port . ';dbname=' . $db->database . ';charset=utf8mb4',
                (string) $db->username,
                (string) $db->password,
                [\PDO::ATTR_TIMEOUT => 3, \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION],
            );
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ? AND table_name LIKE ?');
            $stmt->execute([(string) $db->database, 'bluemap\\_%']);

            return ['ok' => true, 'tables' => (int) $stmt->fetchColumn(), 'error' => null];
        } catch (\PDOException $e) {
            $code = (int) $e->getCode();
            $msg = match ($code) {
                1045 => 'Access denied for the map database user.',
                1049 => 'The map database does not exist on the database host.',
                2002, 2006 => 'The panel cannot reach the database host.',
                default => "Connection failed (error {$code}).",
            };

            return ['ok' => false, 'tables' => null, 'error' => $msg];
        } catch (\Throwable) {
            return ['ok' => false, 'tables' => null, 'error' => 'Connection check failed.'];
        }
    }

    // ------------------------------------------------------------------ max_allowed_packet

    /** The admin-actionable warning for a too-small max_allowed_packet; null when it is fine or unknown. Pure. */
    public static function packetWarning(?int $bytes): ?string
    {
        if ($bytes === null || $bytes >= self::MIN_PACKET_BYTES) {
            return null;
        }
        $mib = round($bytes / 1048576, 1);
        $mib = $mib == floor($mib) ? (string) (int) $mib : (string) $mib;

        return "The database server's max_allowed_packet is {$mib} MiB (at least 64 MiB is recommended). BlueMap saves large texture files and fails with \"Got a packet bigger than 'max_allowed_packet' bytes\" below that. "
            . self::packetFix();
    }

    /** The fix, worded for whoever runs the database server. */
    public static function packetFix(): string
    {
        return 'Fix (admin): add `max_allowed_packet = 256M` under [mysqld] in a .cnf file in the database server\'s config (for example /etc/mysql/conf.d/) and restart the database server.';
    }

    /**
     * Smallest known max_allowed_packet over $hosts, as a warning (or null). $reader maps a host to bytes or null;
     * it may throw: a host that cannot be read (no privilege, unreachable) is skipped silently. Pure apart from $reader.
     *
     * @param iterable<mixed> $hosts
     * @param callable(mixed): ?int $reader
     */
    public static function packetWarningFor(iterable $hosts, callable $reader): ?string
    {
        $min = null;
        foreach ($hosts as $host) {
            try {
                $bytes = $reader($host);
            } catch (\Throwable $e) {
                Trace::debug('db.packet_read_failed', ['cause' => get_class($e)]);
                continue;
            }
            if (is_int($bytes) && $bytes > 0 && ($min === null || $bytes < $min)) {
                $min = $bytes;
            }
        }

        return self::packetWarning($min);
    }

    /**
     * Warning about the database host(s) this server's map database lives on / would be created on, or null.
     * Never throws and never blocks: no privilege or no connection simply means "no warning".
     */
    public function packetCheck(Server $server, ?Database $db = null): ?string
    {
        try {
            if ($db !== null) {
                $hosts = $db->host !== null ? [$db->host] : [];
            } else {
                $hosts = $server->node->databaseHosts()->get()->all();
                if ($hosts === []) {
                    $hosts = DatabaseHost::query()->get()->all();   // "allow random" picks any host
                }
            }

            return self::packetWarningFor($hosts, fn ($host) => $this->maxAllowedPacket($host));
        } catch (\Throwable $e) {
            Trace::debug('db.packet_check_failed', ['cause' => get_class($e)]);

            return null;
        }
    }

    /** @@global.max_allowed_packet of a host through the panel's own admin connection; null when it cannot be read. */
    public function maxAllowedPacket(DatabaseHost $host): ?int
    {
        $key = 'pelican-bluemap:packet:' . $host->id . ':' . md5($host->host . ':' . $host->port);
        $hit = Cache::get($key);
        if (is_int($hit)) {
            return $hit;
        }
        try {
            $row = $host->buildConnection()->selectOne('SELECT @@global.max_allowed_packet AS v');
            $bytes = $row !== null ? (int) ((array) $row)['v'] : 0;
        } catch (\Throwable $e) {
            Trace::debug('db.packet_read_failed', ['host' => $host->id, 'cause' => get_class($e)]);

            return null;
        }
        if ($bytes <= 0) {
            return null;
        }
        Cache::put($key, $bytes, self::PACKET_TTL);

        return $bytes;
    }

    public function drop(Database $db): void
    {
        app(DatabaseManagementService::class)->delete($db);
        Trace::info('db.dropped', ['database' => $db->database]);
    }

    /** The recorded database if it still exists for this server, else the server's own s{id}_bluemap. */
    private function adoptable(Server $server, ?int $databaseId): ?Database
    {
        if ($databaseId !== null) {
            $db = $server->databases()->where('id', $databaseId)->first();
            if ($db !== null) {
                return $db;
            }
        }

        return $server->databases()->where('database', DatabaseManagementService::generateUniqueDatabaseName(self::DB_SUFFIX, (int) $server->id))->first();
    }
}
