<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Clients;

use Ehaic\PelicanBlueMap\Exceptions\NpmException;
use Ehaic\PelicanBlueMap\Support\CircuitBreaker;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Http;

/**
 * Nginx Proxy Manager REST client (docs/DESIGN.md §8.4, docs/RESEARCH.md §3). Version-aware: NPM >= 2.13 takes the
 * Let's Encrypt e-mail from the owning user and rejects `letsencrypt_*` meta keys; test-http is POST there, GET before.
 *
 * Every call: connect timeout 5 s, request timeout 20 s (certificate POST 150 s), no automatic retry, except one
 * retry with a fresh token after a 401. A transport failure trips the "npm" circuit breaker for 60 s.
 */
class NpmClient
{
    /** Fixed nginx snippet for every host the plugin owns (BlueMap ignores X-Accel-Buffering; REVIEW-1 #12). Not user-editable. */
    public const ADVANCED_CONFIG = 'proxy_buffering off;';

    private const CONNECT_TIMEOUT = 5;
    private const TIMEOUT = 20;
    private const CERT_TIMEOUT = 150;
    private const TEST_HTTP_TIMEOUT = 40;
    private const TOKEN_KEY = 'pelican-bluemap:npm:token';
    private const VERSION_KEY = 'pelican-bluemap:npm:version';

    private ?CircuitBreaker $breaker = null;

    // ---- public API ---------------------------------------------------------------------------------

    /** @return array{major: int, minor: int, revision: int, version: string} */
    public function info(): array
    {
        $hit = Cache::get(self::VERSION_KEY);
        if (is_array($hit) && isset($hit['major'], $hit['version'])) {
            return $hit;
        }
        $body = $this->send('GET', '/api', null, auth: false);
        $info = self::parseVersion(is_array($body) ? $body : []);
        Cache::put(self::VERSION_KEY, $info, 600);

        return $info;
    }

    /** Settings-page connection test. Never throws. @return array{ok: bool, version: ?string, email: ?string, permissions: array<string,string>, problems: list<string>} */
    public function preflight(): array
    {
        $r = ['ok' => false, 'version' => null, 'email' => null, 'permissions' => [], 'problems' => []];
        $settings = $this->settings();
        if (! $settings->isConfigured()) {
            $r['problems'][] = 'Fill in the NPM URL, e-mail, password and base domain first (a password that was saved before an APP_KEY change must be entered again).';

            return $r;
        }
        try {
            // A manual test must see the current state, not a cached version or a "down" mark.
            Cache::forget(self::VERSION_KEY);
            $this->breaker()->reset();
            $r['version'] = $this->info()['version'];
            $me = $this->send('GET', '/api/users/me', ['expand' => 'permissions']);
            $me = is_array($me) ? $me : [];
            $r['email'] = isset($me['email']) ? (string) $me['email'] : null;
            $perm = is_array($me['permissions'] ?? null) ? $me['permissions'] : [];
            foreach ($perm as $k => $v) {
                if (in_array($k, ['id', 'created_on', 'modified_on', 'user_id'], true) || ! is_scalar($v)) {
                    continue;
                }
                $r['permissions'][(string) $k] = (string) $v;
            }
            $roles = is_array($me['roles'] ?? null) ? $me['roles'] : [];
            if (in_array('admin', $roles, true)) {
                $r['problems'][] = 'This NPM user is an admin. Use a dedicated non-admin user (it can then only see its own hosts and certificates).';
            }
            foreach (['proxy_hosts', 'certificates'] as $need) {
                if (($r['permissions'][$need] ?? null) !== 'manage') {
                    $r['problems'][] = "The NPM user needs \"manage\" permission for {$need} (it has \"" . ($r['permissions'][$need] ?? 'none') . '").';
                }
            }
            if (($r['permissions']['visibility'] ?? 'user') === 'all' && ! in_array('admin', $roles, true)) {
                $r['problems'][] = 'The NPM user can see all users\' hosts (visibility "all"). Set it to "user".';
            }
        } catch (NpmException $e) {
            $r['problems'][] = $e->getMessage();
        } catch (\Throwable $e) {
            Trace::error('npm.preflight', ['error' => $e->getMessage()]);
            $r['problems'][] = 'Unexpected error while testing NPM (see the panel log).';
        }
        $r['ok'] = $r['problems'] === [];

        return $r;
    }

    /** Ask NPM whether $fqdn is reachable from the internet on port 80 (test-http). Never throws. @return array{ok: bool, reason: ?string} */
    public function testHttp(string $fqdn): array
    {
        try {
            $info = $this->info();
            if (self::supportsPostTestHttp($info)) {
                $body = $this->send('POST', '/api/nginx/certificates/test-http', ['domains' => [$fqdn]], timeout: self::TEST_HTTP_TIMEOUT);
            } else {
                $body = $this->send('GET', '/api/nginx/certificates/test-http', ['domains' => json_encode([$fqdn])], timeout: self::TEST_HTTP_TIMEOUT);
            }
        } catch (NpmException $e) {
            return ['ok' => false, 'reason' => $e->getMessage()];
        }
        $result = is_array($body) ? ($body[$fqdn] ?? (count($body) === 1 ? reset($body) : null)) : null;
        if ($result === 'ok') {
            return ['ok' => true, 'reason' => null];
        }

        return ['ok' => false, 'reason' => is_string($result) && $result !== '' ? $result : 'No usable answer from NPM.'];
    }

    /** @return list<array> own hosts */
    public function listHosts(): array
    {
        $body = $this->send('GET', '/api/nginx/proxy-hosts');

        return array_values(array_map([self::class, 'normaliseHost'], $this->rows($body)));
    }

    public function getHost(int $id): ?array
    {
        try {
            $body = $this->send('GET', '/api/nginx/proxy-hosts/' . $id);
        } catch (NpmException $e) {
            if ($e->status === 404) {
                return null;
            }
            throw $e;
        }

        return is_array($body) ? self::normaliseHost($body) : null;
    }

    /** @throws NpmException with alreadyInUse=true when the domain is taken (by any NPM user) */
    public function createHost(array $body): array
    {
        return self::normaliseHost($this->expectObject($this->send('POST', '/api/nginx/proxy-hosts', $body)));
    }

    public function updateHost(int $id, array $body): array
    {
        return self::normaliseHost($this->expectObject($this->send('PUT', '/api/nginx/proxy-hosts/' . $id, $body)));
    }

    /** 404 = already gone = ok. */
    public function deleteHost(int $id): void
    {
        $this->delete('/api/nginx/proxy-hosts/' . $id);
    }

    /** @return list<array> */
    public function listCertificates(): array
    {
        $body = $this->send('GET', '/api/nginx/certificates');

        return array_values(array_map([self::class, 'normaliseCert'], $this->rows($body)));
    }

    public function getCertificate(int $id): ?array
    {
        try {
            $body = $this->send('GET', '/api/nginx/certificates/' . $id);
        } catch (NpmException $e) {
            if ($e->status === 404) {
                return null;
            }
            throw $e;
        }

        return is_array($body) ? self::normaliseCert($body) : null;
    }

    /** Requests a Let's Encrypt certificate (blocks until certbot is done, up to 150 s). */
    public function createCertificate(string $fqdn): array
    {
        $info = $this->info();
        $email = $this->settings()->letsencryptEmail();
        if (! self::supportsPostTestHttp($info) && ($email === null || $email === '')) {
            throw new NpmException('NPM ' . $info['version'] . ' needs a Let\'s Encrypt e-mail. Set it on the BlueMap settings page.');
        }
        $body = $this->send('POST', '/api/nginx/certificates', self::certBody($fqdn, $info, $email), timeout: self::CERT_TIMEOUT, tripOnTimeout: false);

        return self::normaliseCert($this->expectObject($body));
    }

    /** 404 = already gone = ok. */
    public function deleteCertificate(int $id): void
    {
        $this->delete('/api/nginx/certificates/' . $id);
    }

    /** False while NPM is marked down by the circuit breaker. */
    public function isAvailable(): bool
    {
        return ! $this->breaker()->isOpen();
    }

    // ---- pure helpers -------------------------------------------------------------------------------

    /**
     * Body for POST/PUT /nginx/proxy-hosts. $certificateId = 0 → plain HTTP host (D§8.4). Carries the fixed
     * ADVANCED_CONFIG (BlueMap ignores X-Accel-Buffering); $withAdvanced = false is the retry body for NPM users
     * that may not set advanced_config.
     *
     * @return array<string, mixed>
     */
    public static function hostBody(string $fqdn, string $forwardHost, int $forwardPort, int $certificateId, bool $hsts, bool $withAdvanced = true): array
    {
        $tls = $certificateId > 0;

        $body = [
            'domain_names' => [$fqdn],
            'forward_scheme' => 'http',
            'forward_host' => $forwardHost,
            'forward_port' => $forwardPort,
            'certificate_id' => $tls ? $certificateId : 0,
            'ssl_forced' => $tls,
            'hsts_enabled' => $tls && $hsts,
            'hsts_subdomains' => false,
            'http2_support' => $tls,
            'block_exploits' => true,
            'caching_enabled' => false,
            'allow_websocket_upgrade' => true,
            'access_list_id' => 0,
            'enabled' => true,
            'meta' => new \stdClass(), // must encode as {} (NPM's schema wants an object)
            'locations' => [],
        ];
        if ($withAdvanced) {
            $body['advanced_config'] = self::ADVANCED_CONFIG;
        }

        return $body;
    }

    /** True when NPM refused the body, which may just be the advanced_config restriction (400/403, not "in use"). */
    public static function isAdvancedConfigRefusal(NpmException $e): bool
    {
        return in_array($e->status, [400, 403], true) && ! $e->alreadyInUse;
    }

    /**
     * Body for POST /nginx/certificates. NPM >= 2.13 uses the NPM user's own e-mail and rejects
     * letsencrypt_* keys; older versions need them.
     *
     * @param array{major: int, minor: int, revision?: int, version?: string} $info
     * @return array<string, mixed>
     */
    public static function certBody(string $fqdn, array $info, ?string $leEmail): array
    {
        $meta = ['dns_challenge' => false];
        if (! self::supportsPostTestHttp($info)) {
            if ($leEmail !== null && $leEmail !== '') {
                $meta['letsencrypt_email'] = $leEmail;
            }
            $meta['letsencrypt_agree'] = true;
        }

        return [
            'provider' => 'letsencrypt',
            'nice_name' => $fqdn,
            'domain_names' => [$fqdn],
            'meta' => $meta,
        ];
    }

    /** @return array{id: int, domain_names: list<string>, forward_host: string, forward_port: int, certificate_id: int, enabled: bool, ssl_forced: bool, nginx_online: ?bool, nginx_err: ?string} */
    public static function normaliseHost(array $raw): array
    {
        $meta = is_array($raw['meta'] ?? null) ? $raw['meta'] : [];
        $online = $meta['nginx_online'] ?? null;
        $err = $meta['nginx_err'] ?? null;

        return [
            'id' => (int) ($raw['id'] ?? 0),
            'domain_names' => self::strings($raw['domain_names'] ?? []),
            'forward_host' => (string) ($raw['forward_host'] ?? ''),
            'forward_port' => (int) ($raw['forward_port'] ?? 0),
            'certificate_id' => (int) ($raw['certificate_id'] ?? 0),
            'enabled' => self::bool($raw['enabled'] ?? false),
            'ssl_forced' => self::bool($raw['ssl_forced'] ?? false),
            'nginx_online' => $online === null ? null : self::bool($online),
            'nginx_err' => is_string($err) && $err !== '' ? $err : null,
        ];
    }

    /** @return array{id: int, domain_names: list<string>, provider: string, expires_on: ?string} */
    public static function normaliseCert(array $raw): array
    {
        $exp = $raw['expires_on'] ?? null;

        return [
            'id' => (int) ($raw['id'] ?? 0),
            'domain_names' => self::strings($raw['domain_names'] ?? []),
            'provider' => (string) ($raw['provider'] ?? ''),
            'expires_on' => is_string($exp) && $exp !== '' ? $exp : null,
        ];
    }

    /** NPM answers 400 "<host> is already in use" when any user owns the host name. */
    public static function isAlreadyInUse(int $status, string $body): bool
    {
        return in_array($status, [400, 409], true) && stripos($body, 'already in use') !== false;
    }

    /**
     * @param array<string, mixed> $apiRoot decoded GET /api
     * @return array{major: int, minor: int, revision: int, version: string}
     */
    public static function parseVersion(array $apiRoot): array
    {
        $v = $apiRoot['version'] ?? null;
        if (! is_array($v) || ! isset($v['major'], $v['minor'])) {
            throw new NpmException('That URL did not answer like Nginx Proxy Manager (no version in /api).');
        }
        $major = (int) $v['major'];
        $minor = (int) $v['minor'];
        $rev = (int) ($v['revision'] ?? 0);

        return ['major' => $major, 'minor' => $minor, 'revision' => $rev, 'version' => "{$major}.{$minor}.{$rev}"];
    }

    /** NPM >= 2.13: user's own LE e-mail, POST test-http. */
    private static function supportsPostTestHttp(array $info): bool
    {
        return (int) $info['major'] > 2 || ((int) $info['major'] === 2 && (int) $info['minor'] >= 13);
    }

    /** @return list<string> */
    private static function strings(mixed $v): array
    {
        return is_array($v) ? array_values(array_map('strval', array_filter($v, 'is_scalar'))) : [];
    }

    private static function bool(mixed $v): bool
    {
        return $v === true || $v === 1 || $v === '1' || $v === 'true';
    }

    // ---- transport ----------------------------------------------------------------------------------

    private function settings(): Settings
    {
        return app(Settings::class);
    }

    private function breaker(): CircuitBreaker
    {
        return $this->breaker ??= new CircuitBreaker('npm', 60);
    }

    /** @return list<array> */
    private function rows(mixed $body): array
    {
        return is_array($body) ? array_values(array_filter($body, 'is_array')) : [];
    }

    private function expectObject(mixed $body): array
    {
        if (! is_array($body) || $body === [] || ! isset($body['id'])) {
            throw new NpmException('Nginx Proxy Manager sent an unexpected answer.');
        }

        return $body;
    }

    private function delete(string $path): void
    {
        try {
            $this->send('DELETE', $path);
        } catch (NpmException $e) {
            if ($e->status !== 404) {
                throw $e;
            }
        }
    }

    private function token(bool $fresh = false): string
    {
        if (! $fresh) {
            $stored = Cache::get(self::TOKEN_KEY);
            if (is_string($stored) && $stored !== '') {
                try {
                    return Crypt::decryptString($stored);
                } catch (\Throwable) {
                    Cache::forget(self::TOKEN_KEY);
                }
            }
        }
        $s = $this->settings();
        $password = $s->npmPassword();
        if ($s->npmUrl() === '' || $s->npmEmail() === '' || $password === null) {
            throw new NpmException('The NPM connection is not configured (Admin → Plugins → BlueMap → Settings).');
        }
        $body = $this->send('POST', '/api/tokens', ['identity' => $s->npmEmail(), 'secret' => $password], auth: false);
        if (! is_array($body)) {
            throw new NpmException('Nginx Proxy Manager sent an unexpected answer to the login.');
        }
        if (! empty($body['requires_2fa'])) {
            throw new NpmException('The NPM user has 2FA enabled; the plugin needs a user without 2FA.');
        }
        $token = (string) ($body['token'] ?? '');
        if ($token === '') {
            throw new NpmException('NPM login failed (no token returned).');
        }
        $ttl = 3600;
        if (isset($body['expires']) && ($ts = strtotime((string) $body['expires'])) !== false) {
            $ttl = max(0, $ts - time() - 300);
        }
        if ($ttl > 0) {
            Cache::put(self::TOKEN_KEY, Crypt::encryptString($token), $ttl);
        }

        return $token;
    }

    /**
     * @param array<string, mixed>|null $data JSON body (or query string for GET)
     * @return mixed decoded JSON ([] for an empty body)
     * @throws NpmException
     */
    private function send(string $method, string $path, ?array $data = null, bool $auth = true, int $timeout = self::TIMEOUT, bool $tripOnTimeout = true, bool $retried = false): mixed
    {
        $breaker = $this->breaker();
        if ($breaker->isOpen()) {
            throw new NpmException('Nginx Proxy Manager is not reachable right now. Try again in a minute.');
        }
        $url = $this->settings()->npmUrl() . $path;
        if ($this->settings()->npmUrl() === '') {
            throw new NpmException('The NPM URL is not configured (Admin → Plugins → BlueMap → Settings).');
        }

        $request = Http::acceptJson()->connectTimeout(self::CONNECT_TIMEOUT)->timeout($timeout)->withHeaders(['User-Agent' => (string) config('pelican-bluemap.user_agent')]);
        if ($auth) {
            $request = $request->withToken($this->token());
        }
        $started = microtime(true);
        try {
            /** @var Response $response */
            $response = match ($method) {
                'GET' => $request->get($url, $data ?? []),
                'POST' => $request->asJson()->post($url, $data ?? []),
                'PUT' => $request->asJson()->put($url, $data ?? []),
                'DELETE' => $request->delete($url),
                default => throw new \InvalidArgumentException('Bad method'),
            };
        } catch (ConnectionException $e) {
            $timedOut = stripos($e->getMessage(), 'timed out') !== false;
            if ($tripOnTimeout || ! $timedOut) {
                $breaker->trip();
            }
            Trace::warning('npm.unreachable', ['method' => $method, 'path' => $path, 'timed_out' => $timedOut, 'error' => $e->getMessage()]);
            throw new NpmException($timedOut ? 'Nginx Proxy Manager did not answer in time.' : 'Nginx Proxy Manager is not reachable.', $e);
        }

        Trace::debug('npm.call', ['method' => $method, 'path' => $path, 'status' => $response->status(), 'ms' => (int) ((microtime(true) - $started) * 1000)]);

        if ($response->status() === 401 && $auth && ! $retried) {
            Cache::forget(self::TOKEN_KEY);
            $this->token(true);

            return $this->send($method, $path, $data, true, $timeout, $tripOnTimeout, true);
        }
        if ($response->failed()) {
            $raw = $response->body();
            $message = $this->errorMessage($response);
            $inUse = self::isAlreadyInUse($response->status(), $raw);
            Trace::warning('npm.error', ['method' => $method, 'path' => $path, 'status' => $response->status(), 'message' => $message]);
            throw new NpmException(
                $inUse ? $message : ($response->status() === 401 ? 'NPM login failed: wrong e-mail or password.' : 'Nginx Proxy Manager answered HTTP ' . $response->status() . ($message !== '' ? ': ' . $message : '')),
                null,
                $response->status(),
                $inUse,
            );
        }
        if ($response->body() === '') {
            return [];
        }
        $json = $response->json();

        return $json ?? [];
    }

    private function errorMessage(Response $response): string
    {
        $json = $response->json();
        $msg = is_array($json) ? ($json['error']['message'] ?? $json['message'] ?? '') : '';
        $msg = is_string($msg) ? $msg : '';

        return mb_strimwidth(trim(preg_replace('/\s+/', ' ', $msg) ?? $msg), 0, 200, '…');
    }
}
