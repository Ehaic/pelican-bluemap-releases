<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Clients;

use Ehaic\PelicanBlueMap\Exceptions\ModrinthException;
use Ehaic\PelicanBlueMap\Support\CircuitBreaker;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/**
 * Modrinth API v2 client (BlueMap and Fabric API builds). docs/DESIGN.md §4 "Build selection".
 *
 * @phpstan-type ModrinthVersion array{id: string, project_id: string, version_number: string, version_type: string, loaders: list<string>, game_versions: list<string>, date_published: string, file: array{url: string, filename: string, size: int, sha1: string, sha512: string}, requires_fabric_api: bool}
 * @phpstan-type BuildChoice array{status: string, bluemap: ?array, fabric_api: ?array, query_loaders: list<string>, message: ?string}
 */
class ModrinthClient
{
    public const BLUEMAP_PROJECT = 'swbUV1cr';
    public const FABRIC_API_PROJECT = 'P7dR8mSH';
    private const CACHE_SECONDS = 1800;
    private const CONNECT_TIMEOUT = 5;
    private const TIMEOUT = 15;

    private ?CircuitBreaker $breaker = null;

    /**
     * Versions of a project (id or slug) for the given loaders and one MC version, newest first.
     * Failures are never cached.
     *
     * @param list<string> $loaders
     * @return list<array>
     * @throws ModrinthException
     */
    public function versions(string $project, array $loaders, string $mcVersion): array
    {
        if (preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $project) !== 1) {
            throw new ModrinthException('Invalid Modrinth project.');
        }
        $key = 'pelican-bluemap:modrinth:' . md5($project . '|' . implode(',', $loaders) . '|' . $mcVersion);
        $hit = Cache::get($key);
        if (is_array($hit)) {
            return $hit;
        }

        $breaker = $this->breaker();
        if ($breaker->isOpen()) {
            throw new ModrinthException('Modrinth is not reachable right now. Try again in a minute.');
        }

        $url = rtrim((string) config('pelican-bluemap.modrinth_url', 'https://api.modrinth.com/v2'), '/') . '/project/' . $project . '/version';
        $started = microtime(true);
        try {
            $response = Http::withHeaders(['User-Agent' => (string) config('pelican-bluemap.user_agent')])
                ->acceptJson()
                ->connectTimeout(self::CONNECT_TIMEOUT)
                ->timeout(self::TIMEOUT)
                ->get($url, [
                    'loaders' => json_encode(array_values($loaders), JSON_UNESCAPED_SLASHES),
                    'game_versions' => json_encode([$mcVersion], JSON_UNESCAPED_SLASHES),
                ]);
        } catch (ConnectionException $e) {
            $breaker->trip();
            Trace::warning('modrinth.unreachable', ['project' => $project, 'error' => $e->getMessage()]);
            throw new ModrinthException('Modrinth is not reachable right now. Try again in a minute.', $e);
        }

        Trace::debug('modrinth.versions', ['project' => $project, 'loaders' => implode(',', $loaders), 'mc' => $mcVersion, 'status' => $response->status(), 'ms' => (int) ((microtime(true) - $started) * 1000)]);

        if ($response->status() === 404) {
            return [];
        }
        if ($response->status() === 429 || $response->serverError()) {
            $breaker->trip();
            throw new ModrinthException('Modrinth is not answering properly (HTTP ' . $response->status() . '). Try again in a minute.');
        }
        if (! $response->successful()) {
            throw new ModrinthException('Modrinth rejected the request (HTTP ' . $response->status() . ').');
        }
        $raw = $response->json();
        if (! is_array($raw)) {
            throw new ModrinthException('Modrinth sent an unreadable answer.');
        }

        $versions = self::normalise($raw);
        Cache::put($key, $versions, self::CACHE_SECONDS);

        return $versions;
    }

    /**
     * Pick the BlueMap build (and Fabric API when needed) for a loader and MC version.
     *
     * @return array{status: 'ok'|'unsupported'|'none'|'error', bluemap: ?array, fabric_api: ?array, query_loaders: list<string>, message: ?string}
     */
    public function bestBlueMap(string $loader, string $mcVersion, bool $fabricApiPresent): array
    {
        $loaders = self::queryLoadersFor($loader, $mcVersion);
        $result = fn (string $status, ?array $bluemap, ?array $fabric, ?string $message): array => [
            'status' => $status, 'bluemap' => $bluemap, 'fabric_api' => $fabric, 'query_loaders' => $loaders, 'message' => $message,
        ];
        $min = (int) config('pelican-bluemap.min_bluemap_major', 5);

        try {
            $versions = $this->versions('bluemap', $loaders, $mcVersion);
        } catch (ModrinthException $e) {
            return $result('error', null, null, $e->getMessage());
        }

        $pick = self::pickNewestRelease($versions, $min);
        if ($pick === null) {
            $releases = array_filter($versions, static fn (array $v): bool => $v['version_type'] === 'release');
            if ($releases === []) {
                return $result('none', null, null, "There is no BlueMap build for {$loader} {$mcVersion}.");
            }

            return $result('unsupported', null, null, "Only BlueMap versions older than {$min}.x exist for {$loader} {$mcVersion}, and this plugin supports BlueMap {$min} or newer.");
        }

        $fabric = null;
        if ($pick['requires_fabric_api'] && ! $fabricApiPresent) {
            try {
                $fabric = self::pickNewestRelease($this->versions('fabric-api', ['fabric'], $mcVersion), 0);
            } catch (ModrinthException $e) {
                return $result('error', $pick, null, $e->getMessage());
            }
            if ($fabric === null) {
                return $result('none', $pick, null, "BlueMap needs Fabric API, but there is no Fabric API release for Minecraft {$mcVersion}.");
            }
        }

        return $result('ok', $pick, $fabric, null);
    }

    /** False while Modrinth is marked down by the circuit breaker. */
    public function isAvailable(): bool
    {
        return ! $this->breaker()->isOpen();
    }

    // ---- pure helpers -------------------------------------------------------------------------------

    /**
     * Normalise Modrinth version objects, newest first. Versions without a usable primary .jar are dropped:
     * only cdn.modrinth.com https URLs and safe file names are accepted.
     *
     * @param list<array> $raw
     * @return list<array{id: string, project_id: string, version_number: string, version_type: string, loaders: list<string>, game_versions: list<string>, date_published: string, file: array{url: string, filename: string, size: int, sha1: string, sha512: string}, requires_fabric_api: bool}>
     */
    public static function normalise(array $raw): array
    {
        $out = [];
        foreach ($raw as $v) {
            if (! is_array($v) || ! isset($v['id'], $v['project_id'], $v['version_number'])) {
                continue;
            }
            $file = null;
            $files = is_array($v['files'] ?? null) ? $v['files'] : [];
            foreach ($files as $f) {
                if (is_array($f) && ($f['primary'] ?? false) === true) {
                    $file = $f;
                    break;
                }
            }
            $file ??= is_array($files[0] ?? null) ? $files[0] : null;
            if ($file === null) {
                continue;
            }
            $url = (string) ($file['url'] ?? '');
            $name = (string) ($file['filename'] ?? '');
            $host = parse_url($url, PHP_URL_HOST);
            $scheme = parse_url($url, PHP_URL_SCHEME);
            if ($scheme !== 'https' || $host !== 'cdn.modrinth.com' || preg_match('/^[A-Za-z0-9._+-]{1,128}\.jar$/D', $name) !== 1) {
                continue;
            }
            $requiresFabric = false;
            foreach (is_array($v['dependencies'] ?? null) ? $v['dependencies'] : [] as $d) {
                if (is_array($d) && ($d['project_id'] ?? null) === self::FABRIC_API_PROJECT && ($d['dependency_type'] ?? null) === 'required') {
                    $requiresFabric = true;
                }
            }
            $hashes = is_array($file['hashes'] ?? null) ? $file['hashes'] : [];
            $out[] = [
                'id' => (string) $v['id'],
                'project_id' => (string) $v['project_id'],
                'version_number' => (string) $v['version_number'],
                'version_type' => (string) ($v['version_type'] ?? ''),
                'loaders' => array_values(array_map('strval', is_array($v['loaders'] ?? null) ? $v['loaders'] : [])),
                'game_versions' => array_values(array_map('strval', is_array($v['game_versions'] ?? null) ? $v['game_versions'] : [])),
                'date_published' => (string) ($v['date_published'] ?? ''),
                'file' => [
                    'url' => $url,
                    'filename' => $name,
                    'size' => (int) ($file['size'] ?? 0),
                    'sha1' => strtolower((string) ($hashes['sha1'] ?? '')),
                    'sha512' => strtolower((string) ($hashes['sha512'] ?? '')),
                ],
                'requires_fabric_api' => $requiresFabric,
            ];
        }
        usort($out, static fn (array $a, array $b): int => strcmp($b['date_published'], $a['date_published']));

        return $out;
    }

    /**
     * Modrinth loader names to query (D§4): NeoForge 1.20.1 is a Forge fork, Paper also runs Spigot builds
     * (newest wins), Spigot only takes Spigot builds.
     *
     * @return list<string>
     */
    public static function queryLoadersFor(string $loader, string $mcVersion): array
    {
        return match (true) {
            $loader === 'neoforge' && $mcVersion === '1.20.1' => ['forge'],
            $loader === 'paper' => ['paper', 'spigot'],
            default => [$loader],
        };
    }

    /**
     * Newest `release` whose BlueMap major is >= $minMajor.
     *
     * @param list<array> $versions
     */
    public static function pickNewestRelease(array $versions, int $minMajor): ?array
    {
        $best = null;
        foreach ($versions as $v) {
            if (($v['version_type'] ?? null) !== 'release') {
                continue;
            }
            $major = self::majorOf((string) ($v['version_number'] ?? ''));
            if ($major === null || $major < $minMajor) {
                continue;
            }
            if ($best === null || strcmp((string) $v['date_published'], (string) $best['date_published']) > 0) {
                $best = $v;
            }
        }

        return $best;
    }

    /** "5.7-neoforge" → 5, "3.20-neoforge-1.20.2" → 3, "v5.1" → 5. */
    public static function majorOf(string $versionNumber): ?int
    {
        return preg_match('/^v?(\d+)/i', trim($versionNumber), $m) === 1 ? (int) $m[1] : null;
    }

    private function breaker(): CircuitBreaker
    {
        return $this->breaker ??= new CircuitBreaker('modrinth', 60);
    }
}
