<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Models;

use App\Models\Allocation;
use App\Models\Database;
use App\Models\Server;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * One BlueMap installation per server (state of the install pipeline and the resources it created).
 *
 * @property int $id
 * @property int $server_id
 * @property string $status
 * @property ?string $failed_step
 * @property ?string $last_error
 * @property array<int, string> $steps_done
 * @property string $loader
 * @property string $mc_version
 * @property string $jar_dir
 * @property string $config_dir
 * @property ?string $bluemap_version_id
 * @property ?string $bluemap_version_number
 * @property ?string $jar_path
 * @property ?string $jar_sha1
 * @property ?string $driver_path
 * @property ?string $fabric_api_path
 * @property bool $fabric_api_by_plugin
 * @property ?int $database_id
 * @property bool $db_created_by_plugin
 * @property ?int $allocation_id
 * @property ?int $web_port
 * @property ?string $forward_host
 * @property ?string $subdomain
 * @property ?string $fqdn
 * @property ?int $npm_host_id
 * @property ?int $npm_cert_id
 * @property string $cert_status
 * @property ?string $cert_error
 * @property mixed $cert_expires_at
 * @property bool $maps_finalized
 * @property ?array<int, string> $backups
 * @property ?int $created_by
 */
class Installation extends Model
{
    protected $table = 'bluemap_installations';

    protected $guarded = ['id'];

    protected function casts(): array
    {
        return [
            'steps_done' => 'array',
            'backups' => 'array',
            'fabric_api_by_plugin' => 'bool',
            'db_created_by_plugin' => 'bool',
            'maps_finalized' => 'bool',
            'cert_expires_at' => 'datetime',
        ];
    }

    public static function forServer(Server $server): ?self
    {
        return static::query()->where('server_id', $server->id)->first();
    }

    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    public function database(): BelongsTo
    {
        return $this->belongsTo(Database::class);
    }

    public function allocation(): BelongsTo
    {
        return $this->belongsTo(Allocation::class);
    }

    public function hasStep(string $step): bool
    {
        return in_array($step, $this->steps_done ?? [], true);
    }

    public function markStep(string $step): void
    {
        $steps = $this->steps_done ?? [];
        if (!in_array($step, $steps, true)) {
            $steps[] = $step;
        }
        $this->steps_done = array_values($steps);
        $this->save();
    }

    public function unmarkStep(string $step): void
    {
        $this->steps_done = array_values(array_filter($this->steps_done ?? [], fn ($s) => $s !== $step));
        $this->save();
    }

    public function fail(string $step, string $message): void
    {
        $this->status = 'failed';
        $this->failed_step = $step;
        $this->last_error = $message;
        $this->save();
    }

    /** "https://{fqdn}" once the certificate is issued, "http://{fqdn}" before, null without an fqdn. */
    public function url(): ?string
    {
        if ($this->fqdn === null || $this->fqdn === '') {
            return null;
        }

        return ($this->cert_status === 'issued' ? 'https://' : 'http://') . $this->fqdn;
    }
}
