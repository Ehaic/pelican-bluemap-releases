<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Filament\Server\Pages;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Repositories\Daemon\DaemonServerRepository;
use App\Traits\Filament\BlockAccessInConflict;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Services\AllocationPicker;
use Ehaic\PelicanBlueMap\Services\InstallationService;
use Ehaic\PelicanBlueMap\Support\Ui;
use Ehaic\PelicanBlueMap\Services\RenderControl;
use Ehaic\PelicanBlueMap\Services\ServerGuard;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Services\StatusService;
use Ehaic\PelicanBlueMap\Support\InstallPlan;
use Ehaic\PelicanBlueMap\Support\MinecraftJavaGate;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Wizards\WizardStateStore;
use Filament\Actions\Action;
use Filament\Actions\ActionGroup;
use Filament\Facades\Filament;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Infolists\Components\TextEntry;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Callout;
use Filament\Schemas\Components\Html;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Text;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Schema;
use Illuminate\Support\HtmlString;
use Livewire\Attributes\Locked;
use Throwable;

/**
 * The BlueMap page of a Minecraft Java server: status, install/update/uninstall, web address and render controls.
 *
 * Built from Filament schema components only (no plugin Tailwind classes: they are not in the panel CSS).
 * Every action handler re-checks the permission and the services re-check permission and stopped state.
 */
class BlueMapPage extends Page
{
    use BlockAccessInConflict;

    protected static string|\BackedEnum|null $navigationIcon = 'tabler-map';

    protected static ?string $slug = 'bluemap';

    protected static ?int $navigationSort = 31;

    private const SUPPORTED_LOADERS = ['fabric', 'forge', 'neoforge', 'paper', 'spigot', 'sponge'];

    /** Server id at mount; handlers always re-resolve the server from the tenant and compare. */
    #[Locked]
    public ?int $serverId = null;

    /** Server state at the last full render; the 5 s poll re-renders only when it changes. */
    #[Locked]
    public ?string $knownState = null;

    /** @var array<string, mixed>|null per-request StatusSnapshot (protected: not kept between requests) */
    protected ?array $snapshotMemo = null;

    protected bool $snapshotFailed = false;

    /** @var list<array<string, mixed>>|null per-request list of after-start actions the wizards queued */
    protected ?array $wizardPendingMemo = null;

    // ------------------------------------------------------------------------------------------------
    // Access, navigation
    // ------------------------------------------------------------------------------------------------

    public static function canAccess(): bool
    {
        $server = Filament::getTenant();
        if (!$server instanceof Server) {
            return false;
        }

        // Our own canAccess() replaces BlockAccessInConflict's, so repeat the conflict check.
        return parent::canAccess()
            && !$server->isInConflictState()
            && (bool) user()?->can(SubuserPermission::FileRead, $server)
            && MinecraftJavaGate::matches($server);
    }

    public static function getNavigationLabel(): string
    {
        return static::t('nav');
    }

    public function getTitle(): string
    {
        return static::t('title');
    }

    public function mount(): void
    {
        $this->serverId = $this->server()->id;
        $this->knownState = (string) $this->snap('server.state', 'unknown');
    }

    protected static function t(string $key, array $replace = []): string
    {
        return trans('pelican-bluemap::strings.' . $key, $replace);
    }

    /** Translation that falls back to the raw value when the key does not exist. */
    protected static function tOr(string $key, string $fallback): string
    {
        $label = static::t($key);

        return $label === 'pelican-bluemap::strings.' . $key ? $fallback : $label;
    }

    // ------------------------------------------------------------------------------------------------
    // Server, permissions, snapshot
    // ------------------------------------------------------------------------------------------------

    protected function server(): Server
    {
        /** @var Server $server */
        $server = Filament::getTenant();

        // serverId is #[Locked], this is belt and braces against a tenant switch inside one component.
        abort_if($this->serverId !== null && $this->serverId !== $server->id, 403);

        return $server;
    }

    protected function can(SubuserPermission ...$permissions): bool
    {
        $user = user();
        if ($user === null) {
            return false;
        }
        foreach ($permissions as $permission) {
            if (!$user->can($permission, $this->server())) {
                return false;
            }
        }

        return true;
    }

    /** install / resume / finish setup / update / change port */
    protected function canMutate(): bool
    {
        return $this->can(SubuserPermission::FileCreate, SubuserPermission::FileUpdate, SubuserPermission::FileDelete);
    }

    protected function canUninstall(): bool
    {
        return $this->can(SubuserPermission::FileDelete, SubuserPermission::FileUpdate);
    }

    protected function canProxy(): bool
    {
        return $this->can(SubuserPermission::FileUpdate);
    }

    protected function canConsole(): bool
    {
        return $this->can(SubuserPermission::ControlConsole);
    }

    /** @return array<string, mixed> the StatusSnapshot (an empty shell when it could not be built) */
    protected function snapshot(): array
    {
        if ($this->snapshotMemo === null) {
            try {
                $this->snapshotMemo = app(StatusService::class)->snapshot($this->server(), user());
                $this->snapshotFailed = false;
            } catch (Throwable $e) {
                report($e);
                $this->snapshotFailed = true;
                $this->snapshotMemo = [];
            }
        }

        return $this->snapshotMemo;
    }

    /** Dot-path read from the snapshot (null sections are "not applicable"). */
    protected function snap(string $path, mixed $default = null): mixed
    {
        return data_get($this->snapshot(), $path, $default);
    }

    protected function forgetState(): void
    {
        $this->snapshotMemo = null;
    }

    protected function installation(): ?Installation
    {
        return Installation::forServer($this->server());
    }

    protected function serverState(): string
    {
        return (string) $this->snap('server.state', 'unknown');
    }

    protected function isStopped(): bool
    {
        return (bool) $this->snap('server.stopped', false);
    }

    protected function isRunning(): bool
    {
        return in_array($this->serverState(), ['running', 'starting'], true);
    }

    protected function stateLabel(): string
    {
        return static::tOr('state.' . $this->serverState(), $this->serverState());
    }

    protected function isManaged(): bool
    {
        return (bool) $this->snap('managed', false);
    }

    protected function installStatus(): ?string
    {
        $status = $this->snap('installation_status');

        return is_string($status) ? $status : null;
    }

    protected function loader(): string
    {
        return (string) $this->snap('detection.loader', 'unknown');
    }

    /** Poll only while something is in progress. */
    protected function shouldPoll(): bool
    {
        return (in_array($this->installStatus(), ['installing', 'uninstalling'], true) && !$this->isStale())
            || $this->snap('web.cert_status') === 'pending';
    }

    /**
     * An "installing" / "uninstalling" row whose request died (PHP timeout, crash, panel restart): older than the
     * service's 10 minute lock. Retry / Undo install are offered for it; the service lock still protects a
     * request that is really running.
     */
    protected function isStale(): bool
    {
        if (!in_array($this->installStatus(), ['installing', 'uninstalling'], true)) {
            return false;
        }

        return InstallPlan::isStale($this->installStatus(), $this->installation()?->updated_at?->getTimestamp(), time());
    }

    /** Retry / Undo install apply to a failed install or one that was interrupted. */
    protected function canRecover(): bool
    {
        return $this->installStatus() === 'failed' || ($this->installStatus() === 'installing' && $this->isStale());
    }

    /** The 5 s state poll: re-render only when the server state changed. */
    public function pollServerState(): void
    {
        try {
            $state = app(ServerGuard::class)->forServer($this->server())->state();
        } catch (Throwable $e) {
            report($e);
            $state = 'unknown';
        }

        if ($state === $this->knownState) {
            $this->skipRender();

            return;
        }

        $this->knownState = $state;
        $this->forgetState();
    }

    /** Target of the 10 s poll while installing / requesting a certificate: the re-render is the refresh. */
    public function refreshStatus(): void
    {
        $this->forgetState();
    }

    // ------------------------------------------------------------------------------------------------
    // Action plumbing
    // ------------------------------------------------------------------------------------------------

    /**
     * Pelican turns actions into icon-only buttons; inside a dropdown force real list items.
     *
     * @param  array<int, Action>  $actions
     * @return array<int, Action>
     */
    protected function listItems(array $actions): array
    {
        return array_map(
            fn (Action $action) => $action->grouped()->extraAttributes(['style' => 'min-height:3rem;font-size:1rem;padding-inline:1rem']),
            $actions
        );
    }

    /** Needs a stopped server: disabled with a tooltip otherwise. The service re-checks when it runs. */
    protected function needsStopped(Action $action, string $label): Action
    {
        return $action
            ->disabled(fn () => !$this->isStopped())
            ->tooltip(fn () => $this->isStopped() ? $label : static::t('tooltip.stop_first', ['state' => $this->stateLabel()]));
    }

    /**
     * Run a service call and turn the result into a notification. Returns the OperationResult (or null).
     *
     * @param  \Closure(): array<string, mixed>  $work
     * @return array<string, mixed>|null
     */
    protected function run(string $titleKey, bool $permitted, \Closure $work): ?array
    {
        if (!$permitted) {
            Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.no_permission'))->danger()->send();

            return null;
        }

        try {
            $result = $work();
            ServerFiles::invalidate((int) $this->server()->id);   // the cached log/listing reads are stale after any action
            $this->forgetState();

            $notification = Notification::make()
                ->title(static::t('notify.' . $titleKey))
                ->body((string) ($result['message'] ?? '') ?: null);
            (($result['ok'] ?? false) ? $notification->success() : $notification->danger())->send();

            return $result;
        } catch (BlueMapException $e) {
            $this->forgetState();
            Notification::make()->title(static::t('notify.' . $titleKey))->body($e->getMessage())->danger()->send();
        } catch (Throwable $e) {
            report($e);
            $this->forgetState();
            Notification::make()->title(static::t('notify.failed'))->body(static::t('notify.failed_unexpected'))->danger()->send();
        }

        return null;
    }

    protected function service(): InstallationService
    {
        return app(InstallationService::class)->forServer($this->server(), user());
    }

    // ------------------------------------------------------------------------------------------------
    // Power (same repository call as the console page)
    // ------------------------------------------------------------------------------------------------

    protected function sendPower(string $signal, SubuserPermission $permission): void
    {
        $server = $this->server();

        if (!$this->can($permission)) {
            return;
        }

        try {
            app(DaemonServerRepository::class)->setServer($server)->power($signal)->throw();
            cache()->forget("servers.$server->uuid.status");
            Notification::make()->title(static::t('power.sent_' . $signal))->success()->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(static::t('power.failed'))->danger()->send();
        }

        $this->forgetState();
    }

    /** @return array<int, Action> */
    protected function powerActions(): array
    {
        return [
            Action::make('power_start')
                ->label(static::t('power.start'))->button()->icon('tabler-player-play-filled')->color('primary')
                ->visible(fn () => $this->can(SubuserPermission::ControlStart) && $this->serverState() === 'offline')
                ->action(fn () => $this->sendPower('start', SubuserPermission::ControlStart)),
            Action::make('power_restart')
                ->label(static::t('power.restart'))->button()->icon('tabler-reload')->color('gray')
                ->visible(fn () => $this->can(SubuserPermission::ControlRestart) && $this->isRunning())
                ->action(fn () => $this->sendPower('restart', SubuserPermission::ControlRestart)),
            Action::make('power_stop')
                ->label(static::t('power.stop'))->button()->icon('tabler-player-stop-filled')->color('danger')
                ->visible(fn () => $this->can(SubuserPermission::ControlStop) && $this->isRunning())
                ->action(fn () => $this->sendPower('stop', SubuserPermission::ControlStop)),
        ];
    }

    // ------------------------------------------------------------------------------------------------
    // Page content
    // ------------------------------------------------------------------------------------------------

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            Callout::make(fn () => $this->bannerHeading())
                ->key('bluemap-state-banner')
                ->extraAttributes(['wire:poll.5s' => 'pollServerState'])
                ->status(fn () => $this->isStopped() ? 'success' : 'warning')
                ->description(fn () => $this->isStopped() ? static::t('banner.stopped_body') : static::t('banner.not_stopped_body'))
                ->actions($this->powerActions()),

            // Always present: carries the 10 s poll while an operation is in progress.
            Callout::make(fn () => $this->statusHeading())
                ->key('bluemap-status')
                ->extraAttributes(fn () => $this->shouldPoll() ? ['wire:poll.10s' => 'refreshStatus'] : [])
                ->status(fn () => $this->statusLevel())
                ->description(fn () => $this->statusBody()),

            Callout::make(static::t('status.unsupported_title'))
                ->key('bluemap-unsupported')
                ->visible(fn () => !$this->isManaged() && $this->loader() === 'vanilla')
                ->warning()
                ->description(static::t('status.unsupported_body')),

            Callout::make(static::t('status.mc_mismatch'))
                ->key('bluemap-mc-mismatch')
                ->visible(fn () => (bool) $this->snap('bluemap.mc_mismatch', false))
                ->warning()
                ->description(static::t('status.mc_mismatch_body')),

            Callout::make(static::t('status.settings_missing'))
                ->key('bluemap-settings-missing')
                ->visible(fn () => !$this->isManaged() && $this->snap('preflight.settings_ok') === false)
                ->warning()
                ->description(static::t('status.settings_missing_body')),

            Callout::make(static::t('status.npm_down'))
                ->key('bluemap-npm-down')
                ->visible(fn () => $this->snap('npm_available') === false && $this->snap('preflight.settings_ok') !== false)
                ->warning()
                ->description(static::t('status.npm_down_body')),

            Callout::make(static::t('status.modrinth_down'))
                ->key('bluemap-modrinth-down')
                ->visible(fn () => !$this->isManaged() && $this->snap('modrinth_available') === false)
                ->warning()
                ->description(static::t('status.modrinth_down_body')),

            Callout::make(static::t('status.wings_down'))
                ->key('bluemap-wings-down')
                ->visible(fn () => $this->snap('wings_available') === false)
                ->danger()
                ->description(static::t('status.wings_down_body')),

            Callout::make(static::t('status.render_error'))
                ->key('bluemap-render-error')
                ->visible(fn () => $this->managedErrorText() !== '')
                ->danger()
                ->description(fn () => $this->managedErrorText()),

            Callout::make(static::t('status.packet_small'))
                ->key('bluemap-packet-small')
                ->visible(fn () => (string) $this->snap('database.max_packet_warning', '') !== '')
                ->warning()
                ->description(fn () => new HtmlString(Ui::withCode((string) $this->snap('database.max_packet_warning', '')))),

            Callout::make(fn () => trans_choice('pelican-bluemap::strings.wizard_pending.title', count($this->wizardPending()), ['count' => count($this->wizardPending())]))
                ->key('bluemap-wizard-pending')
                ->visible(fn () => $this->canCustomise() && $this->wizardPending() !== [])
                ->info()
                ->description(static::t('wizard_pending.body'))
                ->actions([
                    Action::make('open_customise_pending')->label(static::t('wizard_pending.open'))->icon('tabler-adjustments')
                        ->url(fn () => BlueMapCustomisePage::getUrl()),
                ]),

            $this->preflightSection(),
            $this->statusSection(),
            $this->bluemapSection(),
            $this->databaseSection(),
            $this->webSection(),
            $this->healthSection(),
            $this->renderSection(),
        ]);
    }

    /** Latest BlueMap error from the server log (first line, its exception line and the hint); '' when there is none. */
    protected function managedErrorText(): string
    {
        $errors = (array) $this->snap('render_errors', []);
        if ($errors === []) {
            return '';
        }
        $e = (array) end($errors);
        $text = (string) ($e['line'] ?? '');
        if (!empty($e['detail'])) {
            $text .= ' — ' . $e['detail'];
        }
        if (!empty($e['hint'])) {
            $text .= ' → ' . $e['hint'];
        }

        return $text;
    }

    protected function bannerHeading(): string
    {
        return $this->isStopped()
            ? static::t('banner.stopped')
            : static::t('banner.not_stopped', ['state' => $this->stateLabel()]);
    }

    protected function statusHeading(): string
    {
        if ($this->snapshotFailed || $this->snapshot() === []) {
            return static::t('status.snapshot_failed');
        }

        return match ($this->installStatus()) {
            'installing' => static::t('status.installing'),
            'uninstalling' => static::t('status.uninstalling'),
            'failed' => static::t('status.failed', ['step' => (string) ($this->snap('failed_step') ?: '?')]),
            'awaiting_first_start' => static::t('status.awaiting'),
            'active' => (bool) $this->snap('needs_finish_setup', false) ? static::t('status.finish') : static::t('status.active'),
            default => $this->snap('bluemap.jar_present') ? static::t('status.unmanaged') : static::t('status.not_installed'),
        };
    }

    protected function statusBody(): ?string
    {
        if ($this->snapshotFailed || $this->snapshot() === []) {
            return static::t('status.snapshot_failed_body');
        }

        return match ($this->installStatus()) {
            'installing' => static::t('status.installing_body'),
            'failed' => trim(((string) $this->snap('last_error', '')) . ' ' . static::t('status.failed_body')),
            'awaiting_first_start' => static::t('status.awaiting_body'),
            'active' => (bool) $this->snap('needs_finish_setup', false)
                ? static::t('status.finish_body')
                : static::t('status.active_body', ['version' => (string) ($this->snap('bluemap.installed_version') ?: '?')]),
            'uninstalling' => null,
            default => $this->snap('bluemap.jar_present') ? static::t('status.unmanaged_body') : static::t('status.not_installed_body'),
        };
    }

    protected function statusLevel(): string
    {
        if ($this->snapshotFailed || $this->snapshot() === []) {
            return 'danger';
        }

        return match ($this->installStatus()) {
            'failed' => 'danger',
            'installing', 'uninstalling', 'awaiting_first_start' => 'info',
            'active' => (bool) $this->snap('needs_finish_setup', false) ? 'warning' : 'success',
            default => 'info',
        };
    }

    /** The Customise page needs a finished install (the wizards edit the finished config). */
    protected function canCustomise(): bool
    {
        return $this->can(SubuserPermission::FileRead)
            && $this->isManaged()
            && $this->installStatus() === 'active'
            && (bool) $this->snap('maps_finalized', false)
            && !(bool) $this->snap('needs_finish_setup', false);
    }

    /** @return list<array<string, mixed>> after-start actions queued by wizards (read from the installation row only) */
    protected function wizardPending(): array
    {
        if ($this->wizardPendingMemo === null) {
            $this->wizardPendingMemo = [];
            try {
                $row = $this->installation();
                if ($row !== null) {
                    $this->wizardPendingMemo = app(WizardStateStore::class)->pending($row);
                }
            } catch (Throwable $e) {
                report($e);
            }
        }

        return $this->wizardPendingMemo;
    }

    // ---- sections ----------------------------------------------------------------------------------

    /** Label/value row. Empty values show a dash. */
    protected function entry(string $key, string $labelKey, \Closure $state): TextEntry
    {
        return TextEntry::make($key)
            ->label(static::t($labelKey))
            ->state($state)
            ->placeholder(static::t('none'))
            ->extraAttributes(['style' => 'overflow-wrap:anywhere;min-width:0']);
    }

    protected function yesNo(mixed $value): ?string
    {
        return $value === null ? static::t('unknown') : static::t($value ? 'yes' : 'no');
    }

    protected function preflightSection(): Section
    {
        return Section::make(static::t('section.preflight'))
            ->key('bluemap-preflight')
            ->visible(fn () => !$this->isManaged() && $this->loader() !== 'vanilla' && $this->snapshot() !== [])
            ->schema([
                Html::make(fn () => new HtmlString($this->preflightHtml())),
            ]);
    }

    protected function preflightHtml(): string
    {
        $pre = $this->snap('preflight');
        if (!is_array($pre)) {
            return '<p>' . e(static::t('preflight.unavailable')) . '</p>';
        }

        $rows = [];
        foreach ((array) ($pre['blockers'] ?? []) as $line) {
            $rows[] = Ui::mark('error') . e((string) $line);
        }
        foreach ((array) ($pre['warnings'] ?? []) as $line) {
            $rows[] = Ui::mark('warning') . e((string) $line);
        }
        if ($rows === []) {
            $rows[] = Ui::mark('ok') . e(static::t('preflight.ok'));
        }

        return implode('', array_map(static fn (string $r) => '<p style="margin:.25rem 0;overflow-wrap:anywhere">' . $r . '</p>', $rows));
    }

    protected function statusSection(): Section
    {
        return Section::make(static::t('section.status'))
            ->key('bluemap-section-status')
            ->visible(fn () => $this->snapshot() !== [])
            ->columns(['default' => 1, 'md' => 2])
            ->schema([
                $this->entry('s_state', 'field.server_state', fn () => $this->stateLabel()),
                $this->entry('s_loader', 'field.loader', function () {
                    $loader = $this->loader();
                    $src = (string) $this->snap('detection.loader_source', 'none');

                    return static::tOr('loader.' . $loader, $loader) . ' · ' . static::tOr('source.' . $src, $src);
                }),
                $this->entry('s_mc', 'field.mc_version', function () {
                    $mc = $this->snap('detection.mc_version');
                    if (!$mc) {
                        return null;
                    }
                    $src = (string) $this->snap('detection.mc_source', 'none');

                    return $mc . ' · ' . static::tOr('source.' . $src, $src);
                }),
                $this->entry('s_managed', 'field.managed', fn () => static::t($this->isManaged() ? 'field.managed_yes' : 'field.managed_no')),
            ]);
    }

    protected function bluemapSection(): Section
    {
        return Section::make(static::t('section.bluemap'))
            ->key('bluemap-section-bluemap')
            ->visible(fn () => $this->snapshot() !== []
                && ($this->isManaged() || $this->snap('bluemap.jar_present') || $this->snap('maps', []) !== []))
            ->columns(['default' => 1, 'md' => 2])
            ->schema([
                $this->entry('b_version', 'field.installed_version', fn () => $this->snap('bluemap.installed_version')),
                $this->entry('b_update', 'field.update', function () {
                    $update = $this->snap('bluemap.update');

                    return is_array($update)
                        ? static::t('field.update_available', ['version' => (string) ($update['version_number'] ?? '?')])
                        : static::t('field.up_to_date');
                })->visible(fn () => $this->snap('bluemap.installed_version') !== null),
                $this->entry('b_jar', 'field.jar_present', fn () => $this->yesNo($this->snap('bluemap.jar_present'))),
                $this->entry('b_driver', 'field.driver_present', fn () => $this->yesNo($this->snap('bluemap.driver_present'))),
                $this->entry('b_fabric', 'field.fabric_api_present', fn () => $this->yesNo($this->snap('bluemap.fabric_api_present')))
                    ->visible(fn () => $this->snap('bluemap.fabric_api_present') !== null),
                $this->entry('b_finalized', 'field.maps_finalized', fn () => $this->yesNo((bool) $this->snap('maps_finalized', false)))
                    ->visible(fn () => $this->isManaged()),
                $this->entry('b_maps', 'field.maps', fn () => array_map(
                    static fn (array $m) => $m['id'] . ' (' . ($m['storage'] ?? '?') . ')',
                    (array) $this->snap('maps', [])
                ))->badge()->color('gray')->visible(fn () => (array) $this->snap('maps', []) !== []),
                $this->entry('b_unmanaged', 'field.unmanaged_jars', fn () => (array) $this->snap('bluemap.unmanaged_jars', []))
                    ->badge()->color('warning')->visible(fn () => (array) $this->snap('bluemap.unmanaged_jars', []) !== []),
            ]);
    }

    protected function databaseSection(): Section
    {
        return Section::make(static::t('section.database'))
            ->key('bluemap-section-database')
            ->visible(fn () => is_array($this->snap('database')))
            ->columns(['default' => 1, 'md' => 2])
            ->schema([
                $this->entry('d_name', 'field.db_name', fn () => $this->snap('database.name')),
                $this->entry('d_target', 'field.db_target', fn () => $this->snap('database.jdbc_host') . ':' . $this->snap('database.jdbc_port')),
                $this->entry('d_conn', 'field.db_connection', function () {
                    $ok = $this->snap('database.panel_connect_ok');
                    if ($ok === null) {
                        return static::t('unknown');
                    }

                    return $ok ? static::t('field.db_ok') : static::t('field.db_failed', ['error' => (string) $this->snap('database.error', '?')]);
                }),
                $this->entry('d_tables', 'field.db_tables', fn () => $this->snap('database.tables'))
                    ->visible(fn () => $this->snap('database.tables') !== null),
            ]);
    }

    protected function webSection(): Section
    {
        return Section::make(static::t('section.web'))
            ->key('bluemap-section-web')
            ->visible(fn () => is_array($this->snap('web')))
            ->columns(['default' => 1, 'md' => 2])
            ->schema([
                $this->entry('w_url', 'field.url', fn () => $this->snap('web.url'))
                    ->url(fn () => $this->safeUrl($this->snap('web.url')), true)
                    ->visible(fn () => $this->snap('web.url') !== null),
                $this->entry('w_fqdn', 'field.fqdn', fn () => $this->snap('web.fqdn')),
                $this->entry('w_alloc', 'field.allocation', function () {
                    $alloc = (string) $this->snap('web.allocation', '');

                    return $this->snap('web.allocation_missing')
                        ? static::t('field.allocation_missing', ['allocation' => $alloc ?: '?'])
                        : $alloc;
                }),
                $this->entry('w_forward', 'field.forward', fn () => $this->snap('web.forward')),
                $this->entry('w_host', 'field.host', function () {
                    $ok = $this->snap('web.host_ok');
                    if ($ok === null) {
                        return static::t('unknown');
                    }

                    return $ok ? static::t('field.host_ok') : static::t('field.host_failed', ['error' => (string) $this->snap('web.host_error', '?')]);
                }),
                $this->entry('w_cert', 'field.cert', function () {
                    $status = (string) $this->snap('web.cert_status', 'none');
                    $text = match ($status) {
                        'issued' => static::t('field.cert_issued'),
                        'pending' => static::t('field.cert_pending'),
                        'failed' => static::t('field.cert_failed', ['error' => (string) $this->snap('web.cert_error', '?')]),
                        default => static::t('field.cert_none'),
                    };
                    $expires = $this->snap('web.cert_expires_at');

                    return $status === 'issued' && $expires
                        ? $text . ' · ' . static::t('field.cert_expires', ['date' => (string) $expires])
                        : $text;
                }),
                $this->entry('w_retry', 'field.cert_retry_after', fn () => $this->snap('web.cert_retry_after'))
                    ->visible(fn () => $this->snap('web.cert_retry_after') !== null),
                $this->entry('w_server', 'field.webserver', function () {
                    $up = $this->snap('web.webserver_reachable');

                    return $up === null ? null : static::t($up ? 'field.webserver_up' : 'field.webserver_down');
                })->visible(fn () => $this->snap('web.webserver_reachable') !== null),
            ]);
    }

    /** Only http(s) URLs become links. */
    protected function safeUrl(mixed $url): ?string
    {
        return is_string($url) && preg_match('#^https?://#i', $url) === 1 ? $url : null;
    }

    protected function healthSection(): Section
    {
        return Section::make(static::t('section.health'))
            ->key('bluemap-section-health')
            ->visible(fn () => (array) $this->snap('health', []) !== [])
            ->collapsible()
            ->schema([
                Html::make(fn () => new HtmlString($this->healthHtml())),
            ]);
    }

    protected function healthHtml(): string
    {
        $out = '';
        foreach ((array) $this->snap('health', []) as $row) {
            $icon = match ($row['level'] ?? 'info') {
                'error' => Ui::mark('error'),
                'warning' => Ui::mark('warning'),
                default => Ui::mark('info'),
            };
            $out .= '<p style="margin:.25rem 0;overflow-wrap:anywhere;font-family:monospace;font-size:.85em">'
                . $icon . ' ' . e((string) ($row['line'] ?? '')) . '</p>';
            if (!empty($row['hint'])) {
                $out .= '<p style="margin:0 0 .5rem 1.5rem;overflow-wrap:anywhere">→ ' . e((string) $row['hint']) . '</p>';
            }
        }

        return $out;
    }

    protected function renderSection(): Section
    {
        return Section::make(static::t('section.render'))
            ->key('bluemap-section-render')
            ->visible(fn () => $this->canConsole() && $this->renderAvailable())
            ->headerActions([
                ActionGroup::make($this->listItems($this->renderActions()))
                    ->label(static::t('action.render'))->icon('tabler-adjustments')->button()->color('gray'),
            ])
            ->schema([
                $this->entry('r_state', 'field.render_state', function () {
                    $paused = $this->snap('render.paused');

                    return $paused === null ? null : static::t($paused ? 'field.render_paused' : 'field.render_running');
                })->visible(fn () => $this->snap('render.paused') !== null),
                Text::make(fn () => static::t('tooltip.running_first', ['state' => $this->stateLabel()]))
                    ->visible(fn () => !$this->isRunning()),
            ]);
    }

    protected function renderAvailable(): bool
    {
        return $this->isManaged() || (bool) $this->snap('bluemap.jar_present', false);
    }

    // ------------------------------------------------------------------------------------------------
    // Render actions (console commands; need the server running)
    // ------------------------------------------------------------------------------------------------

    /** @return array<int, Action> */
    protected function renderActions(): array
    {
        $running = fn (Action $a, string $label) => $a
            ->visible(fn () => $this->canConsole() && $this->renderAvailable())
            ->disabled(fn () => !$this->isRunning())
            ->tooltip(fn () => $this->isRunning() ? $label : static::t('tooltip.running_first', ['state' => $this->stateLabel()]));

        return [
            $running(
                Action::make('render_pause')->label(static::t('action.pause'))->icon('tabler-player-pause')
                    ->visible(fn () => $this->canConsole() && $this->snap('render.paused') !== true)
                    ->action(fn () => $this->sendRender('pause')),
                static::t('action.pause')
            )->visible(fn () => $this->canConsole() && $this->renderAvailable() && $this->snap('render.paused') !== true),
            $running(
                Action::make('render_resume')->label(static::t('action.resume_render'))->icon('tabler-player-play')
                    ->action(fn () => $this->sendRender('resume')),
                static::t('action.resume_render')
            )->visible(fn () => $this->canConsole() && $this->renderAvailable() && $this->snap('render.paused') !== false),
            $running(
                Action::make('render_update')->label(static::t('action.update_maps'))->icon('tabler-refresh')
                    ->action(fn () => $this->sendRender('update')),
                static::t('action.update_maps')
            ),
            $running(
                Action::make('render_reload')->label(static::t('action.reload'))->icon('tabler-reload')
                    ->action(fn () => $this->sendRender('reload')),
                static::t('action.reload')
            ),
            $running(
                Action::make('render_force_update')->label(static::t('action.force_update'))->icon('tabler-hammer')->color('warning')
                    ->requiresConfirmation()
                    ->modalDescription(static::t('action.force_update_body'))
                    ->action(fn () => $this->sendRender('force_update')),
                static::t('action.force_update')
            ),
            $running(
                Action::make('render_purge')->label(static::t('action.purge'))->icon('tabler-trash')->color('danger')
                    ->modalHeading(static::t('action.purge'))
                    ->modalDescription(static::t('action.purge_body'))
                    ->modalSubmitActionLabel(static::t('action.purge_submit'))
                    ->schema(fn () => [
                        Select::make('map_id')->label(static::t('field.map'))->required()
                            ->options(fn () => collect((array) $this->snap('maps', []))->mapWithKeys(fn (array $m) => [(string) $m['id'] => (string) $m['id']])->all()),
                    ])
                    ->action(fn (array $data) => $this->sendRender('purge', (string) ($data['map_id'] ?? ''))),
                static::t('action.purge')
            )->visible(fn () => $this->canConsole() && $this->renderAvailable() && (array) $this->snap('maps', []) !== []),
        ];
    }

    protected function sendRender(string $action, ?string $mapId = null): void
    {
        $this->run('render', $this->canConsole(), fn () => app(RenderControl::class)->forServer($this->server(), user())->send($action, $mapId));
    }

    // ------------------------------------------------------------------------------------------------
    // Header actions
    // ------------------------------------------------------------------------------------------------

    /** @return array<int, Action|ActionGroup> */
    protected function getHeaderActions(): array
    {
        return [
            $this->installAction(),

            Action::make('customise')->label(static::t('action.customise'))->icon('tabler-adjustments')->color('primary')->button()
                ->tooltip(static::t('action.customise_tooltip'))
                ->visible(fn () => $this->canCustomise())
                ->url(fn () => BlueMapCustomisePage::getUrl()),

            $this->needsStopped(
                Action::make('resume')->label(static::t('action.resume'))->icon('tabler-player-track-next')->color('warning')->button()
                    ->visible(fn () => $this->canMutate() && $this->canRecover())
                    ->action(fn () => $this->run('resume', $this->canMutate(), function () {
                        $result = $this->service()->resume();
                        $this->maybeRequestCertificate($result);

                        return $result;
                    })),
                static::t('action.resume')
            ),

            $this->needsStopped(
                Action::make('finish_setup')->label(static::t('action.finish_setup'))->icon('tabler-circle-check')->color('primary')->button()
                    ->visible(fn () => $this->canMutate() && (bool) $this->snap('needs_finish_setup', false))
                    ->requiresConfirmation()
                    ->modalDescription(static::t('action.finish_setup_body'))
                    ->action(fn () => $this->run('finish_setup', $this->canMutate(), fn () => $this->service()->finishSetup())),
                static::t('action.finish_setup')
            ),

            $this->needsStopped(
                Action::make('update')->label(static::t('action.update'))->icon('tabler-arrow-up-circle')->color('warning')->button()
                    ->visible(fn () => $this->canMutate() && $this->isManaged() && is_array($this->snap('bluemap.update')))
                    ->requiresConfirmation()
                    ->modalDescription(static::t('action.update_body'))
                    ->action(fn () => $this->run('update', $this->canMutate(), fn () => $this->service()->update())),
                static::t('action.update')
            ),

            ActionGroup::make($this->listItems([
                Action::make('open_map')->label(static::t('action.open_map'))->icon('tabler-external-link')
                    ->visible(fn () => $this->safeUrl($this->snap('web.url')) !== null)
                    ->url(fn () => $this->safeUrl($this->snap('web.url')), true),

                Action::make('retry_certificate')->label(static::t('action.retry_certificate'))->icon('tabler-certificate')
                    ->visible(fn () => $this->canProxy() && $this->isManaged() && in_array($this->snap('web.cert_status'), ['none', 'failed'], true))
                    ->action(fn () => $this->requestCertificate()),

                $this->needsStopped(
                    Action::make('change_port')->label(static::t('action.change_port'))->icon('tabler-plug')
                        ->visible(fn () => $this->canMutate() && $this->isManaged() && is_array($this->snap('web')))
                        ->modalHeading(static::t('action.change_port'))
                        ->modalDescription(static::t('action.change_port_body'))
                        ->fillForm(fn () => ['allocation_id' => $this->installation()?->allocation_id])
                        ->schema(fn () => [
                            Select::make('allocation_id')->label(static::t('field.port_select'))->required()
                                ->options(fn () => $this->portOptions()),
                        ])
                        ->action(fn (array $data) => $this->run(
                            'change_port',
                            $this->canMutate(),
                            fn () => $this->service()->changePort((int) ($data['allocation_id'] ?? 0))
                        )),
                    static::t('action.change_port')
                ),

                $this->needsStopped(
                    Action::make('rollback')->label(static::t('action.rollback'))->icon('tabler-arrow-back-up')->color('warning')
                        ->visible(fn () => $this->canMutate() && $this->canRecover())
                        ->modalHeading(static::t('action.rollback'))
                        ->modalDescription(static::t('action.rollback_body'))
                        ->schema(fn () => $this->rollbackSchema())
                        ->action(fn (array $data) => $this->doRollback($data)),
                    static::t('action.rollback')
                ),

                Action::make('forget_npm')->label(static::t('action.forget_npm'))->icon('tabler-link-off')->color('danger')
                    ->visible(fn () => $this->canProxy() && $this->installStatus() === 'failed' && $this->installation()?->npm_host_id !== null)
                    ->requiresConfirmation()
                    ->modalDescription(static::t('action.forget_npm_body'))
                    ->action(fn () => $this->run('forget_npm', $this->canProxy(), fn () => $this->service()->forgetNpm())),

                $this->needsStopped(
                    Action::make('uninstall')->label(static::t('action.uninstall'))->icon('tabler-trash')->color('danger')
                        ->visible(fn () => $this->canUninstall() && ($this->isManaged() || $this->installStatus() !== null))
                        ->modalHeading(static::t('action.uninstall'))
                        ->modalDescription(static::t('action.uninstall_body'))
                        ->modalSubmitActionLabel(static::t('action.uninstall_submit'))
                        ->fillForm(['remove_config' => true, 'remove_web_data' => true, 'remove_fabric_api' => false, 'drop_database' => false])
                        ->schema(fn () => $this->uninstallSchema())
                        ->action(fn (array $data) => $this->doUninstall($data)),
                    static::t('action.uninstall')
                ),

                Action::make('open_folder')->label(static::t('action.open_folder'))->icon('tabler-folder-open')
                    ->visible(fn () => $this->can(SubuserPermission::FileRead))
                    ->url(fn () => \App\Filament\Server\Resources\Files\Pages\ListFiles::getUrl(['path' => $this->configFolder()]), true),
            ]))
                ->label(static::t('action.manage'))->icon('tabler-dots-vertical')->button()->color('gray'),
        ];
    }

    protected function configFolder(): string
    {
        return (string) ($this->installation()?->config_dir ?: $this->snap('detection.config_dir') ?: '');
    }

    // ---- install -------------------------------------------------------------------------------------

    protected function installAction(): Action
    {
        return $this->needsStopped(
            Action::make('install')->label(static::t('action.install'))->icon('tabler-download')->color('primary')->button()
                ->visible(fn () => $this->canMutate() && !$this->isManaged() && $this->installStatus() === null
                    && $this->loader() !== 'vanilla' && is_array($this->snap('preflight')))
                ->modalHeading(static::t('action.install'))
                ->modalDescription(static::t('action.install_body'))
                ->modalSubmitActionLabel(static::t('action.install_submit'))
                ->fillForm(fn () => $this->installDefaults())
                ->schema(fn () => $this->installSchema())
                ->action(fn (array $data) => $this->doInstall($data)),
            static::t('action.install')
        )->disabled(fn () => !$this->isStopped() || !(bool) $this->snap('preflight.can_install', false))
            ->tooltip(fn () => match (true) {
                !$this->isStopped() => static::t('tooltip.stop_first', ['state' => $this->stateLabel()]),
                !(bool) $this->snap('preflight.can_install', false) => static::t('tooltip.not_ready'),
                default => static::t('action.install'),
            });
    }

    /** @return array<string, mixed> */
    protected function installDefaults(): array
    {
        $loader = $this->loader();
        $mc = $this->snap('detection.mc_version');
        $allocations = (array) $this->snap('preflight.allocations', []);

        return [
            'allocation_id' => $allocations[0]['id'] ?? null,
            'subdomain' => $this->snap('preflight.subdomain_suggestion'),
            'loader' => in_array($loader, self::SUPPORTED_LOADERS, true) ? $loader : null,
            'mc_version' => is_string($mc) ? $mc : null,
            'install_fabric_api' => $loader === 'fabric' && !(bool) $this->snap('detection.fabric_api_present', false),
        ];
    }

    /** @return array<int, mixed> */
    protected function installSchema(): array
    {
        $loader = $this->loader();
        $loaderSource = (string) $this->snap('detection.loader_source', 'none');
        $mcSource = (string) $this->snap('detection.mc_source', 'none');
        $mc = $this->snap('detection.mc_version');
        $domain = app(Settings::class)->baseDomain();

        return [
            Text::make(static::t('field.eula')),
            Select::make('allocation_id')
                ->label(static::t('field.allocation_select'))
                ->helperText(static::t('field.allocation_hint'))
                ->options(fn () => collect((array) $this->snap('preflight.allocations', []))
                    ->mapWithKeys(fn (array $a) => [(int) $a['id'] => (string) $a['label']])->all())
                ->required(),
            TextInput::make('subdomain')
                ->label(static::t('field.subdomain'))
                ->helperText(static::t('field.subdomain_hint'))
                ->suffix('.' . $domain)
                ->maxLength(63)
                ->regex('/^[a-z0-9]([a-z0-9-]*[a-z0-9])?$/')
                ->dehydrateStateUsing(fn ($state) => ($s = strtolower(trim((string) $state))) === '' ? null : $s),
            Select::make('loader')
                ->label(static::t('field.loader_select'))
                ->helperText(in_array($loader, self::SUPPORTED_LOADERS, true)
                    ? static::t('field.loader_hint', ['loader' => static::tOr('loader.' . $loader, $loader), 'source' => static::tOr('source.' . $loaderSource, $loaderSource)])
                    : static::t('field.loader_hint_unknown'))
                ->options(collect(self::SUPPORTED_LOADERS)->mapWithKeys(fn (string $l) => [$l => static::t('loader.' . $l)])->all())
                ->required()
                ->live(),
            TextInput::make('mc_version')
                ->label(static::t('field.mc_version'))
                ->helperText(is_string($mc) && $mc !== ''
                    ? static::t('field.mc_hint', ['version' => $mc, 'source' => static::tOr('source.' . $mcSource, $mcSource)])
                    : static::t('field.mc_hint_unknown'))
                ->required()
                ->regex('/^\d+\.\d+(\.\d+)?$/')
                ->validationMessages(['regex' => static::t('field.mc_invalid')]),
            Toggle::make('install_fabric_api')
                ->label(static::t('field.fabric_api'))
                ->helperText(static::t('field.fabric_api_hint'))
                ->inline(false)
                ->visible(fn (Get $get) => $get('loader') === 'fabric'),
        ];
    }

    /** @param array<string, mixed> $data */
    protected function doInstall(array $data): void
    {
        $detected = $this->loader();
        $detectedMc = $this->snap('detection.mc_version');
        $loader = (string) ($data['loader'] ?? '');
        $mc = trim((string) ($data['mc_version'] ?? ''));

        $result = $this->run('install', $this->canMutate(), fn () => $this->service()->install([
            'allocation_id' => (int) ($data['allocation_id'] ?? 0),
            'subdomain' => ($sub = strtolower(trim((string) ($data['subdomain'] ?? '')))) === '' ? null : $sub,
            // null = "as detected", so the service keeps its own detection source.
            'loader' => ($loader === '' || $loader === $detected) ? null : $loader,
            'mc_version' => ($mc === '' || $mc === $detectedMc) ? null : $mc,
            'install_fabric_api' => ($loader === 'fabric' || ($loader === '' && $detected === 'fabric')) && !empty($data['install_fabric_api']),
        ]));

        $this->maybeRequestCertificate($result);
    }

    /** The certificate request is slow (Let's Encrypt), so it runs in its own Livewire request. */
    protected function maybeRequestCertificate(?array $result): void
    {
        if (($result['ok'] ?? false) && ($result['next'] ?? null) === 'certificate') {
            $this->js('$wire.requestCertificate()');
        }
    }

    /** Public so the browser (and the retry action) can call it; permission is checked here and in the service. */
    public function requestCertificate(): void
    {
        $this->run('certificate', $this->canProxy(), fn () => $this->service()->requestCertificate());
    }

    // ---- change port / rollback / uninstall -----------------------------------------------------------

    /** @return array<int, string> allocation id => label */
    protected function portOptions(): array
    {
        $picker = app(AllocationPicker::class);
        $out = [];
        foreach ($picker->candidates($this->server(), $this->installation()?->allocation_id) as $allocation) {
            $out[(int) $allocation->id] = $picker->label($allocation);
        }

        return $out;
    }

    /** @return array<int, mixed> */
    protected function rollbackSchema(): array
    {
        $created = (bool) $this->installation()?->db_created_by_plugin;
        $name = $this->server()->name;

        return [
            Toggle::make('drop_database')
                ->label(static::t('action.rollback_drop'))
                ->helperText(static::t('field.drop_database_hint'))
                ->inline(false)
                ->default(false)
                ->live()
                ->visible(fn () => $created && $this->can(SubuserPermission::DatabaseDelete)),
            TextInput::make('confirm_name')
                ->label(static::t('field.confirm_name', ['name' => $name]))
                ->validationAttribute(static::t('field.confirm_name_attribute'))
                ->visible(fn (Get $get) => $created && (bool) $get('drop_database'))
                ->required(fn (Get $get) => (bool) $get('drop_database')),
        ];
    }

    /** @param array<string, mixed> $data */
    protected function doRollback(array $data): void
    {
        $drop = !empty($data['drop_database']);

        if ($drop && !$this->confirmName($data)) {
            return;
        }
        if ($drop && !$this->can(SubuserPermission::DatabaseDelete)) {
            $this->run('rollback', false, fn () => []);

            return;
        }

        $this->run('rollback', $this->canMutate(), fn () => $this->service()->rollback($drop));
    }

    /** @return array<int, mixed> */
    protected function uninstallSchema(): array
    {
        $installation = $this->installation();
        $name = $this->server()->name;
        $canDrop = $installation?->database_id !== null && $this->can(SubuserPermission::DatabaseDelete);

        return [
            Toggle::make('remove_config')->label(static::t('field.remove_config'))->inline(false),
            Toggle::make('remove_web_data')->label(static::t('field.remove_web_data'))->inline(false),
            Toggle::make('remove_fabric_api')->label(static::t('field.remove_fabric_api'))->inline(false)
                ->visible(fn () => (bool) $this->installation()?->fabric_api_by_plugin),
            Toggle::make('drop_database')->label(static::t('field.drop_database'))
                ->helperText(static::t('field.drop_database_hint'))->inline(false)->live()
                ->visible(fn () => $canDrop),
            TextInput::make('confirm_name')
                ->label(static::t('field.confirm_name', ['name' => $name]))
                ->validationAttribute(static::t('field.confirm_name_attribute'))
                ->visible(fn (Get $get) => $canDrop && (bool) $get('drop_database'))
                ->required(fn (Get $get) => $canDrop && (bool) $get('drop_database')),
        ];
    }

    /** @param array<string, mixed> $data */
    protected function doUninstall(array $data): void
    {
        $drop = !empty($data['drop_database']);

        if ($drop && !$this->can(SubuserPermission::DatabaseDelete)) {
            $this->run('uninstall', false, fn () => []);

            return;
        }
        if ($drop && !$this->confirmName($data)) {
            return;
        }

        $fabric = (bool) $this->installation()?->fabric_api_by_plugin && !empty($data['remove_fabric_api']);

        $this->run('uninstall', $this->canUninstall(), fn () => $this->service()->uninstall([
            'remove_config' => !empty($data['remove_config']),
            'remove_web_data' => !empty($data['remove_web_data']),
            'remove_fabric_api' => $fabric,
            'drop_database' => $drop,
            'confirm_name' => $drop ? trim((string) ($data['confirm_name'] ?? '')) : null,
        ]));
    }

    /** Dropping a database needs the server name typed exactly. */
    protected function confirmName(array $data): bool
    {
        if (trim((string) ($data['confirm_name'] ?? '')) === $this->server()->name) {
            return true;
        }

        Notification::make()->title(static::t('notify.failed'))->body(static::t('field.confirm_mismatch'))->danger()->send();

        return false;
    }
}
