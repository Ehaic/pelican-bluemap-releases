<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Filament\Server\Wizards;

use Ehaic\PelicanBlueMap\Wizards\Support\Check;

/**
 * Pure: turns the raw form state of a wizard modal into the `$input` array the wizard definitions validate and plan.
 *
 * Only fields that exist in the StepSpec are forwarded (a tampered Livewire payload can't smuggle extra keys), and every
 * value is coerced by the field type. Values that don't fit are passed through unchanged so the wizard's own
 * `validate()` rejects them with its message: this class never "fixes" input silently.
 */
final class WizardInput
{
    /**
     * @param list<array<string, mixed>> $steps StepSpec list from WizardService::open()
     * @param array<string, mixed> $state raw form state
     * @return array<string, mixed>
     */
    public static function fromState(array $steps, array $state): array
    {
        $out = [];
        foreach (self::fields($steps) as $spec) {
            $name = (string) $spec['name'];
            if (!array_key_exists($name, $state)) {
                continue;
            }
            $out[$name] = self::coerce($spec, $state[$name]);
        }

        return $out;
    }

    /**
     * @param list<array<string, mixed>> $steps
     * @return list<array<string, mixed>> every top-level FieldSpec of every step
     */
    public static function fields(array $steps): array
    {
        $out = [];
        foreach ($steps as $step) {
            foreach ((array) ($step['fields'] ?? []) as $f) {
                $out[] = $f;
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $spec */
    public static function coerce(array $spec, mixed $v): mixed
    {
        switch ((string) $spec['type']) {
            case 'toggle':
                return Check::bool($v);
            case 'int':
                if (Check::blank($v)) {
                    return null;
                }
                $i = Check::int($v, PHP_INT_MIN + 1, PHP_INT_MAX - 1);

                return $i ?? $v;
            case 'float':
            case 'slider':
                if (Check::blank($v)) {
                    return null;
                }
                $f = Check::float($v, -1.0e12, 1.0e12);

                return $f === null ? $v : round($f, 3);
            case 'multiselect':
            case 'players':
                return array_values(array_map('strval', array_filter(is_array($v) ? $v : [], 'is_scalar')));
            case 'repeater':
                return self::rows($spec, $v);
            case 'select':
            case 'radio':
            case 'map':
                if (!is_scalar($v)) {
                    return null;
                }
                // Options with integer keys (e.g. 1200 minutes) come back from the browser as strings.
                foreach ((array) ($spec['options'] ?? []) as $key => $_label) {
                    if ((string) $key === (string) $v) {
                        return $key;
                    }
                }

                return (string) $v;
            case 'color':
            case 'text':
            case 'textarea':
            default:
                return is_scalar($v) ? (string) $v : '';
        }
    }

    /**
     * @param array<string, mixed> $spec
     * @return list<array<string, mixed>>
     */
    private static function rows(array $spec, mixed $v): array
    {
        $children = (array) ($spec['children'] ?? []);
        $max = $spec['max_items'] ?? null;
        $out = [];
        foreach (is_array($v) ? array_values($v) : [] as $row) {
            if (!is_array($row)) {
                continue;
            }
            $clean = [];
            foreach ($children as $child) {
                $n = (string) $child['name'];
                $clean[$n] = array_key_exists($n, $row) ? self::coerce($child, $row[$n]) : self::coerce($child, null);
            }
            $out[] = $clean;
            if (is_int($max) && count($out) >= max($max, 1) + 100) {
                break;   // far beyond the limit: stop reading; validate() reports the overflow
            }
        }

        return $out;
    }

    /**
     * Visible-if rule of a FieldSpec evaluated on a state array (loose compare: the browser mixes ints and strings).
     *
     * @param array<string, mixed> $spec
     * @param array<string, mixed> $state
     */
    public static function isVisible(array $spec, array $state): bool
    {
        $rule = $spec['visible_if'] ?? null;
        if (!is_array($rule)) {
            return true;
        }
        $cur = $state[(string) $rule['field']] ?? null;
        foreach ((array) ($rule['in'] ?? []) as $allowed) {
            if ((string) $allowed === (string) $cur) {
                return true;
            }
        }

        return false;
    }
}
