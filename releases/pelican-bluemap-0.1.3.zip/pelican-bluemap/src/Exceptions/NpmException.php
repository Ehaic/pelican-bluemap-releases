<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Exceptions;

/** Nginx Proxy Manager failure. $status is the HTTP status when NPM answered, null for transport errors. */
class NpmException extends BlueMapException
{
    public function __construct(
        string $userMessage,
        ?\Throwable $prev = null,
        public readonly ?int $status = null,
        public readonly bool $alreadyInUse = false,
    ) {
        parent::__construct($userMessage, $prev);
    }
}
