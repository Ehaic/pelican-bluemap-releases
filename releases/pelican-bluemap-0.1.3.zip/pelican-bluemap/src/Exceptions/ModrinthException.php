<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Exceptions;

/** Modrinth API failure (transport or HTTP error). */
class ModrinthException extends BlueMapException
{
}
