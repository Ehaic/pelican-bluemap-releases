<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Exceptions;

/** Thrown when a file change is attempted while the server is not offline. */
class ServerNotStoppedException extends BlueMapException
{
    public function __construct(public readonly string $state = 'unknown')
    {
        parent::__construct("Stop the server first (it is {$state}).");
    }
}
