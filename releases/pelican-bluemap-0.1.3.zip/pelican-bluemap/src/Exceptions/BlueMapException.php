<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Exceptions;

/** An expected failure. getMessage() is shown to the user verbatim (English, no secrets). */
class BlueMapException extends \RuntimeException
{
    public function __construct(string $userMessage, ?\Throwable $prev = null)
    {
        parent::__construct($userMessage, 0, $prev);
    }
}
