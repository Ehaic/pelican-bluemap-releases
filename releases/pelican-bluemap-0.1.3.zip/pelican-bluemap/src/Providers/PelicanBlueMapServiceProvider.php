<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Providers;

use App\Models\Server;
use Ehaic\PelicanBlueMap\Clients\ModrinthClient;
use Ehaic\PelicanBlueMap\Clients\NpmClient;
use Ehaic\PelicanBlueMap\Observers\ServerObserver;
use Ehaic\PelicanBlueMap\Support\Settings;
use Illuminate\Support\ServiceProvider;

class PelicanBlueMapServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        // Stateless / shared. The per-server services (InstallationService, StatusService, ServerFiles, ...)
        // use forServer() clones and are deliberately not bound, so they are resolved fresh each time.
        $this->app->singleton(Settings::class);
        $this->app->singleton(ModrinthClient::class);
        $this->app->singleton(NpmClient::class);
    }

    public function boot(): void
    {
        // Removes the NPM host/certificate when a server is deleted.
        Server::observe(ServerObserver::class);
    }
}
