<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap;

use App\Contracts\Plugins\HasPluginSettings;
use App\Traits\EnvironmentWriterTrait;
use Ehaic\PelicanBlueMap\Clients\NpmClient;
use Ehaic\PelicanBlueMap\Support\Settings;
use Filament\Actions\Action;
use Filament\Contracts\Plugin;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Notifications\Notification;
use Filament\Panel;
use Filament\Schemas\Components\Actions;
use Throwable;

class PelicanBlueMapPlugin implements HasPluginSettings, Plugin
{
    use EnvironmentWriterTrait;

    public function getId(): string
    {
        return 'pelican-bluemap';
    }

    public function register(Panel $panel): void
    {
        // Only the server panel has pages; the admin panel is listed in plugin.json for the settings form.
        if ($panel->getId() !== 'server') {
            return;
        }

        $panel->discoverPages(
            plugin_path($this->getId(), 'src/Filament/Server/Pages'),
            'Ehaic\\PelicanBlueMap\\Filament\\Server\\Pages'
        );
    }

    public function boot(Panel $panel): void {}

    /** @return array<string, mixed> The password is never sent to the browser: the field starts empty. */
    public function getSettingsFormData(): array
    {
        return [
            'npm_url' => (string) config('pelican-bluemap.npm_url'),
            'npm_email' => (string) config('pelican-bluemap.npm_email'),
            'npm_password' => '',
            'base_domain' => (string) config('pelican-bluemap.base_domain'),
            'le_email' => (string) config('pelican-bluemap.le_email'),
            'hsts' => (bool) config('pelican-bluemap.hsts'),
            'forward_host' => (string) config('pelican-bluemap.forward_host'),
            'jdbc_host' => (string) config('pelican-bluemap.jdbc_host'),
            'jdbc_port' => (string) config('pelican-bluemap.jdbc_port'),
            'reserved' => (string) config('pelican-bluemap.reserved'),
            'debug' => (bool) config('pelican-bluemap.debug'),
        ];
    }

    /** @return array<int, mixed> */
    public function getSettingsForm(): array
    {
        $t = static fn (string $key) => trans('pelican-bluemap::strings.settings.' . $key);

        return [
            TextInput::make('npm_url')->label($t('npm_url'))->helperText($t('npm_url_hint'))
                ->required()->maxLength(255)->url()->placeholder('http://192.168.4.171:81'),
            TextInput::make('npm_email')->label($t('npm_email'))->email()->required()->maxLength(255),
            TextInput::make('npm_password')->label($t('npm_password'))->helperText($t('npm_password_hint'))
                ->password()->revealable(false)->autocomplete('new-password')->maxLength(255),
            TextInput::make('base_domain')->label($t('base_domain'))->helperText($t('base_domain_hint'))
                ->required()->maxLength(190)->placeholder('example.com'),
            TextInput::make('le_email')->label($t('le_email'))->helperText($t('le_email_hint'))
                ->email()->maxLength(255),
            Toggle::make('hsts')->label($t('hsts'))->helperText($t('hsts_hint'))->inline(false),
            TextInput::make('forward_host')->label($t('forward_host'))->helperText($t('forward_host_hint'))
                ->maxLength(255)->placeholder('192.168.4.171'),
            TextInput::make('jdbc_host')->label($t('jdbc_host'))->helperText($t('jdbc_host_hint'))
                ->maxLength(255)->placeholder('192.168.4.171'),
            TextInput::make('jdbc_port')->label($t('jdbc_port'))->numeric()->minValue(1)->maxValue(65535)
                ->placeholder('3306'),
            TextInput::make('reserved')->label($t('reserved'))->helperText($t('reserved_hint'))->maxLength(2000),
            Toggle::make('debug')->label($t('debug'))->helperText($t('debug_hint'))->inline(false),
            // These buttons test the SAVED settings (save first, then test).
            Actions::make([
                Action::make('test_npm')->label($t('test_npm'))->icon('tabler-plug-connected')->color('gray')
                    ->action(fn () => $this->testNpm()),
                Action::make('test_port80')->label($t('test_port80'))->icon('tabler-world-www')->color('gray')
                    ->action(fn () => $this->testPort80()),
            ]),
        ];
    }

    /** @param array<string, mixed> $data */
    public function saveSettings(array $data): void
    {
        $values = [
            'BLUEMAP_NPM_URL' => rtrim(trim((string) ($data['npm_url'] ?? '')), '/'),
            'BLUEMAP_NPM_EMAIL' => trim((string) ($data['npm_email'] ?? '')),
            'BLUEMAP_BASE_DOMAIN' => strtolower(ltrim(trim((string) ($data['base_domain'] ?? '')), '.')),
            'BLUEMAP_LE_EMAIL' => trim((string) ($data['le_email'] ?? '')),
            'BLUEMAP_HSTS' => !empty($data['hsts']) ? 'true' : 'false',
            'BLUEMAP_FORWARD_HOST' => trim((string) ($data['forward_host'] ?? '')),
            'BLUEMAP_JDBC_HOST' => trim((string) ($data['jdbc_host'] ?? '')),
            'BLUEMAP_JDBC_PORT' => trim((string) ($data['jdbc_port'] ?? '')),
            'BLUEMAP_RESERVED' => implode(',', array_values(array_filter(array_map(
                static fn (string $s) => strtolower(trim($s)),
                explode(',', (string) ($data['reserved'] ?? ''))
            ), static fn (string $s) => $s !== ''))),
            'BLUEMAP_DEBUG' => !empty($data['debug']) ? 'true' : 'false',
        ];

        // A blank password keeps the stored one.
        $password = (string) ($data['npm_password'] ?? '');
        if ($password !== '') {
            $values['BLUEMAP_NPM_PASSWORD'] = Settings::encryptSecret($password);
        }

        $this->writeToEnvironment($values);

        // config:clear only drops the cache file: mirror the new values into this request so the test below
        // (and anything else in this request) sees them.
        foreach ($values as $envKey => $value) {
            $key = 'pelican-bluemap.' . strtolower(substr($envKey, strlen('BLUEMAP_')));
            config([$key => in_array($value, ['true', 'false'], true) ? $value === 'true' : $value]);
        }

        Notification::make()->title(trans('pelican-bluemap::strings.settings.saved'))->success()->send();

        // Settings forms can't show a test result inline, so check the connection right after saving.
        $this->testNpm();
    }

    /** Test the saved NPM connection. Never shows secrets. */
    public function testNpm(): void
    {
        try {
            $result = app(NpmClient::class)->preflight();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(trans('pelican-bluemap::strings.settings.npm_failed'))
                ->body(trans('pelican-bluemap::strings.settings.unexpected'))->danger()->send();

            return;
        }

        $lines = [];
        if (!empty($result['version'])) {
            $lines[] = trans('pelican-bluemap::strings.settings.npm_version', ['version' => $result['version']]);
        }
        if (!empty($result['email'])) {
            $lines[] = trans('pelican-bluemap::strings.settings.npm_user', ['email' => $result['email']]);
        }
        foreach ((array) ($result['permissions'] ?? []) as $name => $level) {
            $lines[] = $name . ': ' . $level;
        }
        foreach ((array) ($result['problems'] ?? []) as $problem) {
            $lines[] = '⚠ ' . $problem;
        }

        $notification = Notification::make()
            ->title(trans('pelican-bluemap::strings.settings.' . (!empty($result['ok']) ? 'npm_ok' : 'npm_failed')))
            ->body(implode('<br>', array_map(static fn ($l) => e((string) $l), $lines)) ?: null);

        (!empty($result['ok']) ? $notification->success() : $notification->danger())->send();
    }

    /** Ask NPM to probe port 80 from the internet for a throw-away name under the base domain. */
    public function testPort80(): void
    {
        try {
            $base = app(Settings::class)->baseDomain();
            $result = app(NpmClient::class)->testHttp('bluemap-probe-' . random_int(100000, 999999) . '.' . $base);
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(trans('pelican-bluemap::strings.settings.port80_failed'))
                ->body(trans('pelican-bluemap::strings.settings.unexpected'))->danger()->send();

            return;
        }

        $notification = Notification::make()
            ->title(trans('pelican-bluemap::strings.settings.' . (!empty($result['ok']) ? 'port80_ok' : 'port80_failed')))
            ->body($result['reason'] ?? null);

        (!empty($result['ok']) ? $notification->success() : $notification->danger())->send();
    }
}
