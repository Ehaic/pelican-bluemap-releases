<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Observers;

use App\Models\Server;
use Ehaic\PelicanBlueMap\Clients\NpmClient;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Support\Facades\DB;

/** Server deleted: remove its NPM host and certificate (best effort; the row cascades away with the server). */
class ServerObserver
{
    public function deleting(Server $server): void
    {
        try {
            $row = Installation::forServer($server);
        } catch (\Throwable) {
            return; // table missing (plugin not migrated): nothing to clean up
        }
        if ($row === null || ($row->npm_host_id === null && $row->npm_cert_id === null)) {
            return;
        }

        $hostId = $row->npm_host_id !== null ? (int) $row->npm_host_id : null;
        $certId = $row->npm_cert_id !== null ? (int) $row->npm_cert_id : null;
        $serverId = (int) $server->id;
        $fqdn = $row->fqdn;

        DB::afterCommit(function () use ($hostId, $certId, $serverId, $fqdn) {
            Trace::begin($serverId);
            try {
                $npm = app(NpmClient::class);
                if ($hostId !== null) {
                    try {
                        $npm->deleteHost($hostId);
                        Trace::info('server_deleted.host_removed', ['npm_host_id' => $hostId, 'fqdn' => $fqdn]);
                    } catch (\Throwable $e) {
                        Trace::warning('server_deleted.host_failed', ['npm_host_id' => $hostId, 'fqdn' => $fqdn, 'cause' => get_class($e)]);
                        // A cert still in use can't be deleted: leave it for manual cleanup.
                        $hostId = -1;
                    }
                }
                if ($certId !== null) {
                    if ($hostId === -1) {
                        Trace::warning('server_deleted.cert_left', ['npm_cert_id' => $certId, 'fqdn' => $fqdn]);
                    } else {
                        try {
                            $npm->deleteCertificate($certId);
                            Trace::info('server_deleted.cert_removed', ['npm_cert_id' => $certId]);
                        } catch (\Throwable $e) {
                            Trace::warning('server_deleted.cert_failed', ['npm_cert_id' => $certId, 'cause' => get_class($e)]);
                        }
                    }
                }
            } finally {
                Trace::end();
            }
        });
    }
}
