<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

use Illuminate\Support\Facades\Cache;

/** Marks an external service "down" for a while (shared across requests via the cache) so a dead service can't stall pages. */
class CircuitBreaker
{
    public function __construct(private readonly string $name, private readonly int $downSeconds = 60)
    {
    }

    private function key(): string
    {
        return 'pelican-bluemap:cb:' . $this->name;
    }

    /** True = "down", skip calls. */
    public function isOpen(): bool
    {
        try {
            return Cache::has($this->key());
        } catch (\Throwable) {
            return false;
        }
    }

    public function trip(): void
    {
        try {
            Cache::put($this->key(), 1, $this->downSeconds);
        } catch (\Throwable) {
        }
    }

    public function reset(): void
    {
        try {
            Cache::forget($this->key());
        } catch (\Throwable) {
        }
    }
}
