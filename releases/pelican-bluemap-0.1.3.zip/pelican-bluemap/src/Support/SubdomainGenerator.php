<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

/** Pure: server name → candidate DNS labels (docs/DESIGN.md §8.3). */
class SubdomainGenerator
{
    private const ALPHABET = 'abcdefghijklmnopqrstuvwxyz0123456789';
    private const MAX_LABEL = 40;

    /** @var \Closure(int): string */
    private \Closure $random;

    /** @param (\Closure(int): string)|null $random returns a string of [a-z0-9] with the given length */
    public function __construct(?\Closure $random = null)
    {
        $this->random = $random ?? static function (int $len): string {
            $s = '';
            for ($i = 0; $i < $len; $i++) {
                $s .= self::ALPHABET[random_int(0, strlen(self::ALPHABET) - 1)];
            }

            return $s;
        };
    }

    /** Lower-case ASCII [a-z0-9-], collapsed and trimmed, at most 40 characters. May be ''. */
    public function slug(string $serverName): string
    {
        $s = $serverName;
        if (class_exists(\Normalizer::class)) {
            $n = \Normalizer::normalize($s, \Normalizer::FORM_KD);
            if (is_string($n)) {
                $s = preg_replace('/\p{Mn}+/u', '', $n) ?? $n;
            }
        }
        $s = strtolower($s);
        $s = preg_replace('/[^a-z0-9]+/', '-', $s) ?? '';

        return $this->cut(trim($s, '-'), self::MAX_LABEL);
    }

    public function isValidLabel(string $label): bool
    {
        return preg_match('/^[a-z0-9](?:[a-z0-9-]{0,38}[a-z0-9])?$/D', $label) === 1;
    }

    /**
     * Ordered candidates: slug; slug-<4 random> ×2; map-<8 random> ×2. All valid, none reserved, no duplicates.
     *
     * @param list<string> $reserved
     * @return list<string>
     */
    public function candidates(string $serverName, array $reserved): array
    {
        $reserved = array_map('strtolower', $reserved);
        $slug = $this->slug($serverName);
        $out = [];
        $add = function (string $label) use (&$out, $reserved): bool {
            if ($this->isValidLabel($label) && ! in_array($label, $reserved, true) && ! in_array($label, $out, true)) {
                $out[] = $label;

                return true;
            }

            return false;
        };

        if ($slug !== '') {
            $add($slug);
            $base = $this->cut($slug, self::MAX_LABEL - 5); // room for "-xxxx"
            for ($n = 0, $tries = 0; $n < 2 && $tries < 20; $tries++) {
                $n += $add($base . '-' . $this->rand(4)) ? 1 : 0;
            }
        }
        for ($n = 0, $tries = 0; $n < 2 && $tries < 20; $tries++) {
            $n += $add('map-' . $this->rand(8)) ? 1 : 0;
        }

        return $out;
    }

    private function rand(int $len): string
    {
        return strtolower(preg_replace('/[^a-z0-9]/i', '', ($this->random)($len)) ?? '');
    }

    private function cut(string $s, int $max): string
    {
        return rtrim(substr($s, 0, $max), '-');
    }
}
