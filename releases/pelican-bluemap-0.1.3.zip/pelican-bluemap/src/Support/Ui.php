<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

/**
 * Small HTML helpers for the hand-built page fragments. Colours come from the Smoked Glass tokens (--sg-*) with
 * fallbacks, so the markup looks right with and without the theme and never carries a hard-coded palette.
 */
final class Ui
{
    /** Status glyph (plain text, coloured by token) in place of colour emoji, which clash with the line-icon set. */
    public static function mark(string $level): string
    {
        [$glyph, $token, $fallback] = match ($level) {
            'error' => ['✕', '--sg-red', '#fda4af'],
            'warning' => ['▲', '--sg-warn', '#f6b98a'],
            'ok' => ['✓', '--sg-ok', '#6ee7b7'],
            default => ['●', '--sg-accent', '#56c2ff'],
        };

        return '<span aria-hidden="true" style="display:inline-block;width:1.25em;color:var(' . $token . ',' . $fallback . ')">' . $glyph . '</span>';
    }

    /** Inline style for a diff line: '+' / '-' / header / context. */
    public static function diffStyle(string $kind): string
    {
        return match ($kind) {
            '+' => 'color:var(--sg-ok,#6ee7b7)',
            '-' => 'color:var(--sg-red,#fda4af)',
            'h' => 'font-weight:600;margin-top:.5rem;color:var(--sg-accent-2,inherit)',
            default => 'color:var(--sg-muted,inherit);opacity:.85',
        };
    }

    /** Escape $text and render `backtick spans` as code chips. Returns an HTML string (wrap in HtmlString). Safe to inject: only the chip markup is added. */
    public static function withCode(string $text): string
    {
        $chip = 'padding:.1em .4em;border-radius:var(--sg-radius-sm,6px);font-family:ui-monospace,monospace;font-size:.9em;'
            . 'background:rgba(var(--sg-text-rgb,238,238,245),.08);color:var(--sg-accent-2,inherit);overflow-wrap:anywhere';
        $html = preg_replace_callback('/`([^`]+)`/', static fn (array $m) => '<code style="' . $chip . '">' . $m[1] . '</code>', htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));

        return (string) $html;
    }
}
