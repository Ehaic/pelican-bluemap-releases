<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

use Illuminate\Support\Facades\Crypt;

/**
 * Typed access to config('pelican-bluemap.*'), which Admin -> Plugins -> BlueMap -> Settings writes to .env.
 * Reads config on every call (no caching), so a saved setting applies immediately. Secrets are stored as
 * "enc:" + Crypt::encryptString().
 */
class Settings
{
    public function npmUrl(): string
    {
        $url = rtrim(trim((string) config('pelican-bluemap.npm_url', '')), '/');
        $url = preg_replace('#/api$#i', '', $url) ?? $url;

        return rtrim($url, '/');
    }

    public function npmEmail(): string
    {
        return trim((string) config('pelican-bluemap.npm_email', ''));
    }

    /** Decrypted password; null if empty or undecryptable (APP_KEY changed). */
    public function npmPassword(): ?string
    {
        $stored = (string) config('pelican-bluemap.npm_password', '');
        if ($stored === '') {
            return null;
        }
        $plain = self::decryptSecret($stored);

        return ($plain === null || $plain === '') ? null : $plain;
    }

    public function baseDomain(): string
    {
        return strtolower(trim(trim((string) config('pelican-bluemap.base_domain', '')), '.'));
    }

    public function letsencryptEmail(): ?string
    {
        return $this->nullable('le_email');
    }

    public function hsts(): bool
    {
        return (bool) config('pelican-bluemap.hsts', true);
    }

    public function forwardHost(): ?string
    {
        return $this->nullable('forward_host');
    }

    public function jdbcHost(): ?string
    {
        return $this->nullable('jdbc_host');
    }

    public function jdbcPort(): ?int
    {
        $v = trim((string) config('pelican-bluemap.jdbc_port', ''));
        if ($v === '' || ! ctype_digit($v) || (int) $v < 1 || (int) $v > 65535) {
            return null;
        }

        return (int) $v;
    }

    /** @return list<string> */
    public function reservedSubdomains(): array
    {
        $parts = explode(',', strtolower((string) config('pelican-bluemap.reserved', '')));
        $out = [];
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p !== '' && ! in_array($p, $out, true)) {
                $out[] = $p;
            }
        }

        return $out;
    }

    public function debug(): bool
    {
        return (bool) config('pelican-bluemap.debug', false);
    }

    /** NPM url, e-mail, a readable password and the base domain are all present. */
    public function isConfigured(): bool
    {
        return $this->npmUrl() !== '' && $this->npmEmail() !== '' && $this->npmPassword() !== null && $this->baseDomain() !== '';
    }

    public static function encryptSecret(string $plain): string
    {
        return 'enc:' . Crypt::encryptString($plain);
    }

    /** Accepts "enc:…" (null on failure) and returns plain values as they are. */
    public static function decryptSecret(string $stored): ?string
    {
        if (! str_starts_with($stored, 'enc:')) {
            return $stored;
        }
        try {
            return Crypt::decryptString(substr($stored, 4));
        } catch (\Throwable) {
            return null;
        }
    }

    private function nullable(string $key): ?string
    {
        $v = trim((string) config('pelican-bluemap.' . $key, ''));

        return $v === '' ? null : $v;
    }
}
