<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

use Illuminate\Support\Facades\Log;

/**
 * One-line, grep-able log entries in the panel log:
 *
 *   pelican-bluemap: install.step op=a1b2c3 server=15 user=1 step=jars ms=840
 *
 * `op` ties together every line of one operation. Only ids, names, hosts and timings are logged. Context is
 * passed through redact(): keys matching /pass|secret|token|authorization|identity/i and any value equal to
 * the NPM password are masked. debug() lines need BLUEMAP_DEBUG=true.
 */
final class Trace
{
    public const PREFIX = 'pelican-bluemap: ';
    public const MASK = '***';

    private static ?string $op = null;

    private static ?int $server = null;

    /** @var list<string> extra values to mask (tests, runtime secrets) */
    private static array $secrets = [];

    private static ?string $npmPassword = null;

    private static bool $npmPasswordLoaded = false;

    /** Start a new operation: later lines carry its op id and server id. */
    public static function begin(?int $serverId): string
    {
        self::$op = substr(bin2hex(random_bytes(4)), 0, 6);
        self::$server = $serverId;

        return self::$op;
    }

    public static function end(): void
    {
        self::$op = null;
        self::$server = null;
    }

    /** Also mask this exact value in every later line. */
    public static function addSecret(string $value): void
    {
        if ($value !== '' && ! in_array($value, self::$secrets, true)) {
            self::$secrets[] = $value;
        }
    }

    public static function forgetSecrets(): void
    {
        self::$secrets = [];
        self::$npmPassword = null;
        self::$npmPasswordLoaded = false;
    }

    /** @param array<string, mixed> $ctx */
    public static function debug(string $event, array $ctx = []): void
    {
        $on = false;
        try {
            $on = (bool) config('pelican-bluemap.debug', false);
        } catch (\Throwable) {
        }
        if ($on) {
            self::write('debug', $event, $ctx);
        }
    }

    /** @param array<string, mixed> $ctx */
    public static function info(string $event, array $ctx = []): void
    {
        self::write('info', $event, $ctx);
    }

    /** @param array<string, mixed> $ctx */
    public static function warning(string $event, array $ctx = []): void
    {
        self::write('warning', $event, $ctx);
    }

    /** @param array<string, mixed> $ctx */
    public static function error(string $event, array $ctx = []): void
    {
        self::write('error', $event, $ctx);
    }

    /** scheme://host/path of a URL, without query or credentials. */
    public static function safeUrl(string $url): string
    {
        $p = parse_url($url);
        if (! is_array($p) || empty($p['host'])) {
            return '(unparseable)';
        }

        return ($p['scheme'] ?? 'https') . '://' . $p['host'] . (isset($p['port']) ? ':' . $p['port'] : '') . ($p['path'] ?? '');
    }

    /**
     * Mask secrets (recursively).
     *
     * @param array<string, mixed> $ctx
     * @return array<string, mixed>
     */
    public static function redact(array $ctx): array
    {
        $secrets = self::secrets();
        $out = [];
        foreach ($ctx as $k => $v) {
            if (is_string($k) && preg_match('/pass|secret|token|authorization|identity/i', $k)) {
                $out[$k] = self::MASK;
            } elseif (is_array($v)) {
                $out[$k] = self::redact($v);
            } elseif (is_string($v) && $v !== '' && in_array($v, $secrets, true)) {
                $out[$k] = self::MASK;
            } else {
                $out[$k] = $v;
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $ctx */
    public static function format(string $event, array $ctx, ?string $op = null, ?int $server = null, mixed $user = null): string
    {
        $head = ['op' => $op, 'server' => $server, 'user' => $user];
        $parts = [];
        foreach ([...$head, ...self::redact($ctx)] as $k => $v) {
            if ($v === null || $v === '') {
                continue;
            }
            if (is_array($v)) {
                $v = json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '[]';
            }
            $v = is_bool($v) ? ($v ? 'true' : 'false') : (string) $v;
            $v = mb_strimwidth(preg_replace('/\s+/', ' ', $v) ?? $v, 0, 400, '…');
            $parts[] = $k . '=' . (preg_match('/[\s"=]/', $v) ? json_encode($v, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) : $v);
        }

        return self::PREFIX . $event . ($parts ? ' ' . implode(' ', $parts) : '');
    }

    /** @return list<string> */
    private static function secrets(): array
    {
        if (! self::$npmPasswordLoaded) {
            self::$npmPasswordLoaded = true;
            try {
                self::$npmPassword = (new Settings())->npmPassword();
            } catch (\Throwable) {
                self::$npmPassword = null; // no Laravel (unit tests) or no config yet
            }
        }

        return self::$npmPassword !== null ? [...self::$secrets, self::$npmPassword] : self::$secrets;
    }

    /** @param array<string, mixed> $ctx */
    private static function write(string $level, string $event, array $ctx): void
    {
        try {
            $user = function_exists('auth') ? auth()->id() : null;
            Log::{$level}(self::format($event, $ctx, self::$op, self::$server, $user));
        } catch (\Throwable) {
            // logging must never break an operation
        }
    }
}
