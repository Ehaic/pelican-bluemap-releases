<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

use App\Models\Server;

/** Decides whether a server runs a Minecraft Java egg (docs/DESIGN.md §3). matchesEgg() is pure. */
final class MinecraftJavaGate
{
    private const EXCLUDE_TAGS = ['bedrock', 'proxy'];
    private const EXCLUDE_NAMES = ['bedrock', 'pocketmine', 'nukkit', 'velocity', 'bungee', 'waterfall', 'geyser'];
    private const INCLUDE_NAMES = ['minecraft', 'paper', 'purpur', 'folia', 'spigot', 'bukkit', 'forge', 'neoforge', 'fabric', 'sponge', 'ftb', 'curseforge', 'modpack'];

    /**
     * @param list<string> $features
     * @param list<string> $tags
     */
    public static function matchesEgg(array $features, array $tags, string $eggName, string $startup): bool
    {
        $features = array_map(static fn ($f) => strtolower((string) $f), $features);
        $tags = array_map(static fn ($t) => strtolower((string) $t), $tags);
        $name = strtolower($eggName);

        if (in_array('bluemap', $features, true)) {
            return true;
        }
        foreach (self::EXCLUDE_TAGS as $t) {
            if (in_array($t, $tags, true)) {
                return false;
            }
        }
        foreach (self::EXCLUDE_NAMES as $n) {
            if (str_contains($name, $n)) {
                return false;
            }
        }
        if (in_array('minecraft', $tags, true)) {
            return true;
        }
        foreach (self::INCLUDE_NAMES as $n) {
            if (str_contains($name, $n)) {
                return true;
            }
        }
        $cmd = strtolower($startup);

        return str_contains($cmd, 'java')
            && (str_contains($cmd, '.jar') || str_contains($cmd, ' -jar ') || str_contains($cmd, '@user_jvm_args.txt') || str_contains($cmd, 'unix_args.txt'));
    }

    public static function matches(Server $server): bool
    {
        $egg = $server->egg;
        if ($egg === null) {
            return false;
        }
        $inherited = $egg->inherit_features ?? $egg->features;
        $features = is_array($inherited) ? array_values($inherited) : [];
        $tags = is_array($egg->tags) ? array_values($egg->tags) : [];

        return self::matchesEgg($features, $tags, (string) $egg->name, (string) $server->startup);
    }
}
