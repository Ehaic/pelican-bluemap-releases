<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

/** Pure (no Laravel) decisions of the install pipeline, kept here so they can be unit tested. */
final class InstallPlan
{
    public const STEPS = ['database', 'jars', 'config', 'proxy_host', 'certificate'];

    public const MANAGED_MARKER = 'Managed by the Pelican BlueMap plugin';

    /** Seconds after which an "installing"/"uninstalling" row counts as interrupted (= the service lock TTL). */
    public const STALE_AFTER = 600;

    /** Files the plugin wrote from scratch (sql.conf, or core/webserver/file.conf created on install). */
    public static function isPluginFile(string $text): bool
    {
        return str_contains($text, self::MANAGED_MARKER) || str_starts_with($text, ConfigRenderer::CREATED_MARKER);
    }

    /**
     * Reason to refuse an install before any row or file exists (a database preflight result that is not ok), else null.
     *
     * @param array<string, mixed> $database result of DatabaseProvisioner::preflight()
     */
    public static function databaseBlocker(array $database): ?string
    {
        if (($database['ok'] ?? false) === true) {
            return null;
        }

        return (string) (($database['reason'] ?? '') !== '' ? $database['reason'] : 'The map database cannot be set up on this server.');
    }

    /** Prefix of the steps_done marker that says "the settings of the last jar update still have to be converted". */
    public const MIGRATE_MARKER = 'migrate:';

    /** steps_done marker for a settings conversion from $oldVersion that failed (docs/WIZARDS.md 8.3). */
    public static function migrationMarker(string $oldVersion): string
    {
        return self::MIGRATE_MARKER . $oldVersion;
    }

    /**
     * The BlueMap version a failed settings conversion started from, or null when none is pending. Resume retries it,
     * because a retried update sees the new jar already in place and would never convert again.
     *
     * @param array<int, mixed>|null $stepsDone
     */
    public static function pendingMigration(?array $stepsDone): ?string
    {
        foreach ($stepsDone ?? [] as $s) {
            if (is_string($s) && str_starts_with($s, self::MIGRATE_MARKER) && strlen($s) > strlen(self::MIGRATE_MARKER)) {
                return substr($s, strlen(self::MIGRATE_MARKER));
            }
        }

        return null;
    }

    /** The step after $step (the last step, or an unknown one, maps to itself). */
    public static function stepAfter(string $step): string
    {
        $pos = array_search($step, self::STEPS, true);

        return $pos === false ? $step : (self::STEPS[$pos + 1] ?? $step);
    }

    /**
     * Config files to back up before the config step writes: every file that exists, changed or not (Undo install
     * restores from the backup and deletes files without one), except files the plugin created itself (they
     * are deleted on undo; sql.conf also holds the password).
     *
     * @param array<string, ?string> $orig path => current content (null = missing)
     * @return list<string>
     */
    public static function configBackupPaths(array $orig): array
    {
        $out = [];
        foreach ($orig as $path => $text) {
            if ($text !== null && !self::isPluginFile($text)) {
                $out[] = (string) $path;
            }
        }

        return $out;
    }

    /**
     * Backup stamps in the order Undo install should try them: oldest first, because the first backup of a file
     * is its pre-install original (later stamps may hold the plugin's own edits).
     *
     * @param array<int, string>|null $stamps
     * @return list<string>
     */
    public static function restoreOrder(?array $stamps): array
    {
        $list = array_values(array_filter((array) $stamps, 'is_string'));
        sort($list, SORT_STRING); // stamps are Ymd-His: lexical = chronological

        return $list;
    }

    /** An in-progress row whose request died (PHP timeout, crash, restart). */
    public static function isStale(?string $status, ?int $updatedAt, int $now): bool
    {
        return in_array($status, ['installing', 'uninstalling'], true)
            && $updatedAt !== null
            && $now - $updatedAt > self::STALE_AFTER;
    }
}
