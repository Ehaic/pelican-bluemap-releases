<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

/**
 * Pure (no Laravel) HOCON text helpers for BlueMap's config files. See docs/DESIGN.md §6.
 *
 * Quoted strings in HOCON follow JSON escaping, so every string value is rendered with json_encode (panel
 * database passwords contain quotes, backslashes, `$`, ...). setTopLevelKey() edits one value in place and
 * leaves every other byte of the file untouched.
 */
final class ConfigRenderer
{
    public static function hoconString(string $s): string
    {
        return json_encode($s, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
    }

    /** "jdbc:mariadb://h:p/db"; a bare IPv6 address gets [ ]. */
    public static function jdbcUrl(string $host, int $port, string $database): string
    {
        if (str_contains($host, ':') && ! str_starts_with($host, '[')) {
            $host = '[' . $host . ']';
        }

        return 'jdbc:mariadb://' . $host . ':' . $port . '/' . $database;
    }

    /** Whole content of storages/sql.conf (the file is owned by the plugin). */
    public static function sqlConf(string $jdbcUrl, string $user, string $password, string $driverJar, string $driverClass, int $maxConnections = 8): string
    {
        return "# Managed by the Pelican BlueMap plugin. Changes are overwritten on update.\n"
            . "storage-type: sql\n"
            . 'connection-url: ' . self::hoconString($jdbcUrl) . "\n"
            . "connection-properties: {\n"
            . '  user: ' . self::hoconString($user) . "\n"
            . '  password: ' . self::hoconString($password) . "\n"
            . "}\n"
            . 'max-connections: ' . $maxConnections . "\n"
            . 'driver-jar: ' . self::hoconString($driverJar) . "\n"
            . 'driver-class: ' . self::hoconString($driverClass) . "\n"
            . "compression: gzip\n";
    }

    /**
     * First line of the config files the plugin creates from scratch (core.conf, webserver.conf, file.conf).
     * Undo install deletes such files instead of restoring them, and they are never copied to the backups.
     */
    public const CREATED_MARKER = '# Created by the Pelican BlueMap plugin.';

    /** core.conf for a server that has none. */
    public static function newCoreConf(): string
    {
        return self::CREATED_MARKER . "\n"
            . "accept-download: true\n"
            . "data: \"bluemap\"\n"
            . "render-thread-count: 1\n"
            . "metrics: false\n";
    }

    /** webserver.conf for a server that has none. */
    public static function newWebserverConf(int $port): string
    {
        return self::CREATED_MARKER . "\n"
            . "enabled: true\n"
            . "webroot: \"bluemap/web\"\n"
            . "ip: \"0.0.0.0\"\n"
            . 'port: ' . $port . "\n"
            . "additional-headers: {\n"
            . "  \"X-Accel-Buffering\": \"no\"\n"
            . "}\n";
    }

    /**
     * storages/file.conf with BlueMap's defaults. BlueMap only writes its default storage configs when the
     * storages folder does not exist; the plugin creates that folder for sql.conf, so without this file the
     * first start fails with "There is no storage-configuration for 'file'" (maps start on "file" storage).
     */
    public static function newFileStorageConf(): string
    {
        return self::CREATED_MARKER . "\n"
            . "storage-type: file\n"
            . "root: \"bluemap/web/maps\"\n"
            . "compression: gzip\n";
    }

    /**
     * Set a top-level scalar key. Replaces the value of the first uncommented `key: value` / `key = value`
     * line at brace depth 0 (keeping any trailing comment); appends `key: value` at the end when absent.
     */
    public static function setTopLevelKey(string $hocon, string $key, string|int|bool $value): string
    {
        $rendered = is_bool($value) ? ($value ? 'true' : 'false') : (is_int($value) ? (string) $value : self::hoconString($value));
        $hit = self::findTopLevel($hocon, $key);
        if ($hit !== null) {
            return substr($hocon, 0, $hit['start']) . $rendered . substr($hocon, $hit['end']);
        }
        $eol = str_contains($hocon, "\r\n") ? "\r\n" : "\n";
        $sep = ($hocon !== '' && ! str_ends_with($hocon, "\n")) ? $eol : '';

        return $hocon . $sep . $key . ': ' . $rendered . $eol;
    }

    /** Raw scalar value of a top-level key (quotes removed, JSON escapes decoded), or null. */
    public static function getTopLevelKey(string $hocon, string $key): ?string
    {
        $hit = self::findTopLevel($hocon, $key);
        if ($hit === null) {
            return null;
        }
        $raw = substr($hocon, $hit['start'], $hit['end'] - $hit['start']);
        if ($raw !== '' && $raw[0] === '"') {
            $decoded = json_decode($raw);

            return is_string($decoded) ? $decoded : substr($raw, 1, -1);
        }

        return $raw;
    }

    /**
     * Locate the value token of the first top-level scalar `key`.
     *
     * @return array{start: int, end: int}|null
     */
    private static function findTopLevel(string $hocon, string $key): ?array
    {
        if (preg_match('/^[A-Za-z0-9_.-]+$/', $key) !== 1) {
            throw new \InvalidArgumentException('Invalid HOCON key');
        }
        $pattern = '/^[ \t]*' . preg_quote($key, '/') . '[ \t]*[:=][ \t]*/';
        $depth = 0;
        $inTriple = false;
        $offset = 0;
        foreach (preg_split('/(?<=\n)/', $hocon, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $line) {
            if ($depth === 0 && ! $inTriple && preg_match($pattern, $line, $m) === 1) {
                $from = strlen($m[0]);
                $value = self::valueToken($line, $from);
                if ($value !== null) {
                    return ['start' => $offset + $from, 'end' => $offset + $from + $value];
                }
            }
            self::advance($line, $depth, $inTriple);
            $offset += strlen($line);
        }

        return null;
    }

    /** Length of the scalar token starting at $from, or null when the value is a block/array/empty/triple-quoted. */
    private static function valueToken(string $line, int $from): ?int
    {
        $rest = substr($line, $from);
        if ($rest === '' || $rest[0] === "\n" || $rest[0] === "\r" || $rest[0] === '#' || str_starts_with($rest, '//')) {
            return null;
        }
        if ($rest[0] === '{' || $rest[0] === '[' || str_starts_with($rest, '"""')) {
            return null;
        }
        if ($rest[0] === '"') {
            $n = strlen($rest);
            for ($i = 1; $i < $n; $i++) {
                if ($rest[$i] === '\\') {
                    $i++;
                } elseif ($rest[$i] === '"') {
                    return $i + 1;
                }
            }

            return null;
        }
        if (preg_match('/^(?:(?!\s|#|\/\/|,|\}).)+/', $rest, $m) !== 1) {
            return null;
        }

        return strlen($m[0]);
    }

    /** Update brace depth / triple-quote state after one line (strings and comments are skipped). */
    private static function advance(string $line, int &$depth, bool &$inTriple): void
    {
        $n = strlen($line);
        for ($i = 0; $i < $n; $i++) {
            $c = $line[$i];
            if ($inTriple) {
                $end = strpos($line, '"""', $i);
                if ($end === false) {
                    return;
                }
                $inTriple = false;
                $i = $end + 2;
                continue;
            }
            if ($c === '"') {
                if (substr($line, $i, 3) === '"""') {
                    $inTriple = true;
                    $i += 2;
                    continue;
                }
                for ($i++; $i < $n; $i++) {
                    if ($line[$i] === '\\') {
                        $i++;
                    } elseif ($line[$i] === '"') {
                        break;
                    }
                }
            } elseif ($c === '#' || ($c === '/' && ($line[$i + 1] ?? '') === '/')) {
                return;
            } elseif ($c === '{' || $c === '[') {
                $depth++;
            } elseif (($c === '}' || $c === ']') && $depth > 0) {
                $depth--;
            }
        }
    }
}
