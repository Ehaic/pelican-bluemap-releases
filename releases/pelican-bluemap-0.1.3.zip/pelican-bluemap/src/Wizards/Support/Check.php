<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

/** Pure input coercion for form values (Livewire sends strings and numbers mixed). */
final class Check
{
    /** Integer in [min, max] or null. Accepts ints, integral floats and numeric strings like "12". */
    public static function int(mixed $v, int $min, int $max): ?int
    {
        if (is_string($v)) {
            $v = trim($v);
            if (preg_match('/^-?\d{1,15}$/', $v) !== 1) {
                return null;
            }
            $v = (int) $v;
        } elseif (is_float($v)) {
            if (!is_finite($v) || floor($v) !== $v) {
                return null;
            }
            $v = (int) $v;
        } elseif (!is_int($v)) {
            return null;
        }

        return ($v >= $min && $v <= $max) ? $v : null;
    }

    public static function float(mixed $v, float $min, float $max): ?float
    {
        if (is_string($v)) {
            $v = trim($v);
            if (preg_match('/^-?\d+(\.\d+)?$/', $v) !== 1) {
                return null;
            }
        } elseif (!is_int($v) && !is_float($v)) {
            return null;
        }
        $f = (float) $v;

        return ($f >= $min && $f <= $max) ? $f : null;
    }

    public static function blank(mixed $v): bool
    {
        return $v === null || (is_string($v) && trim($v) === '');
    }

    public static function bool(mixed $v, bool $default = false): bool
    {
        if (is_bool($v)) {
            return $v;
        }
        if ($v === null || $v === '') {
            return $default;
        }

        return in_array($v, [1, '1', 'true', 'on', 'yes'], true);
    }

    /** "#rgb" / "#rrggbb" in any case -> "#rrggbb" lower-case, else null. */
    public static function color(mixed $v): ?string
    {
        if (!is_string($v) || preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', trim($v), $m) !== 1) {
            return null;
        }
        $h = strtolower($m[1]);
        if (strlen($h) === 3) {
            $h = $h[0] . $h[0] . $h[1] . $h[1] . $h[2] . $h[2];
        }

        return '#' . $h;
    }

    /** 1..$max chars, no control characters. */
    public static function text(mixed $v, int $max = 64, int $min = 1): ?string
    {
        if (!is_string($v)) {
            return null;
        }
        $v = trim($v);
        $len = mb_strlen($v);

        return ($len >= $min && $len <= $max && preg_match('/[\x00-\x1F\x7F]/', $v) !== 1) ? $v : null;
    }
}
