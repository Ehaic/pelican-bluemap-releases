<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

use Ehaic\PelicanBlueMap\Wizards\BlueMapVersion;

/**
 * Pure: the render area of a map. 5.11+ = a managed `render-mask: [...]` block, older = top-level min-x/max-x/...
 * scalars (docs/WIZARDS.md 4.2).
 *
 * Area shape: array{mode: 'whole'|'square'|'circle'|'box', cx?: float, cz?: float, size?: float, radius?: float,
 *   min_x?: ?int, max_x?: ?int, min_z?: ?int, max_z?: ?int, min_y?: ?int, max_y?: ?int, nether_ceiling?: bool,
 *   hide?: list<array{label?: string, min_x: int, max_x: int, min_z: int, max_z: int, min_y?: ?int, max_y?: ?int}>}
 */
final class MaskRenderer
{
    public const MANAGED_NOTE = '# Managed by Pelican BlueMap (render area wizard). Manual edits here are replaced by the wizard.';

    /**
     * @param array<string, mixed> $area
     * @param array{raw: string, major: int, minor: int} $version
     * @return array{block?: ?string, scalars?: array<string, ?int>}
     */
    public static function renderMask(array $area, array $version): array
    {
        $mode = (string) ($area['mode'] ?? 'whole');
        $ceiling = (bool) ($area['nether_ceiling'] ?? false);

        if (!BlueMapVersion::atLeast($version, 11)) {
            $s = ['min-x' => null, 'max-x' => null, 'min-z' => null, 'max-z' => null, 'min-y' => null, 'max-y' => null];
            if ($mode === 'square') {
                [$s['min-x'], $s['max-x'], $s['min-z'], $s['max-z']] = self::squareToBox((float) $area['cx'], (float) $area['cz'], (float) $area['size']);
            } elseif ($mode === 'circle') {
                [$s['min-x'], $s['max-x'], $s['min-z'], $s['max-z']] = self::squareToBox((float) $area['cx'], (float) $area['cz'], 2 * (float) $area['radius']);
            } elseif ($mode === 'box') {
                foreach (['min-x' => 'min_x', 'max-x' => 'max_x', 'min-z' => 'min_z', 'max-z' => 'max_z', 'min-y' => 'min_y', 'max-y' => 'max_y'] as $k => $f) {
                    $s[$k] = isset($area[$f]) ? (int) $area[$f] : null;
                }
            }
            if ($ceiling) {
                $s['max-y'] = 90;
            }

            return ['scalars' => $s];
        }

        $lines = [];
        $lines[] = match ($mode) {
            'square' => self::box(self::squareToBox((float) $area['cx'], (float) $area['cz'], (float) $area['size']), null, null, false),
            'circle' => '{ type: circle, center-x: ' . self::num((float) $area['cx']) . ', center-z: ' . self::num((float) $area['cz']) . ', radius: ' . self::num((float) $area['radius']) . ' }',
            'box' => self::box([$area['min_x'] ?? null, $area['max_x'] ?? null, $area['min_z'] ?? null, $area['max_z'] ?? null], $area['min_y'] ?? null, $area['max_y'] ?? null, false),
            default => '{}',
        };
        if ($ceiling) {
            $lines[] = '{ subtract: true, min-y: 90, max-y: 127 }   # nether ceiling';
        }
        foreach ((array) ($area['hide'] ?? []) as $h) {
            $label = trim((string) preg_replace('/[\x00-\x1F\x7F]+/', ' ', (string) ($h['label'] ?? '')));
            $lines[] = self::box([$h['min_x'] ?? null, $h['max_x'] ?? null, $h['min_z'] ?? null, $h['max_z'] ?? null], $h['min_y'] ?? null, $h['max_y'] ?? null, true)
                . ($label === '' ? '' : '   # ' . $label);
        }

        return ['block' => "[\n  " . self::MANAGED_NOTE . "\n  " . implode("\n  ", $lines) . "\n]"];
    }

    /**
     * Is $raw (the current render-mask value) BlueMap's generated one: only comments, an empty box and/or the
     * nether-ceiling box?
     */
    public static function isTemplateMask(string $raw): bool
    {
        $a = self::parseMask($raw);

        return $a !== null && $a['mode'] === 'whole' && $a['hide'] === [];
    }

    /**
     * Read a render-mask value we understand (a single include box/circle, the nether ceiling, hide boxes).
     * Null = anything else (nested objects, other keys, several includes...): a "custom" mask.
     *
     * @return array{mode: string, nether_ceiling: bool, hide: list<array<string, mixed>>, cx?: float, cz?: float, radius?: float, min_x?: int, max_x?: int, min_z?: int, max_z?: int}|null
     */
    public static function parseMask(string $raw): ?array
    {
        $raw = trim($raw);
        if ($raw === '' || $raw[0] !== '[' || !str_ends_with($raw, ']')) {
            return null;
        }
        $s = substr($raw, 1, -1);
        $n = strlen($s);
        $elements = [];   // [pairs, label]
        $i = 0;
        while ($i < $n) {
            $c = $s[$i];
            if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n" || $c === ',') {
                $i++;
            } elseif ($c === '#' || ($c === '/' && ($s[$i + 1] ?? '') === '/')) {
                $e = strpos($s, "\n", $i);
                $e = $e === false ? $n : $e;
                $before = substr($s, 0, $i);
                $nl = strrpos($before, "\n");
                $sameLine = trim(substr($before, $nl === false ? 0 : $nl + 1)) !== '';
                if ($sameLine && $elements !== [] && $elements[count($elements) - 1]['label'] === '' && $elements[count($elements) - 1]['closedOnLine'] === substr_count($before, "\n")) {
                    $elements[count($elements) - 1]['label'] = trim(ltrim(substr($s, $i, $e - $i), '#/ '));
                }
                $i = $e;
            } elseif ($c === '{') {
                $j = $i + 1;
                $body = '';
                while ($j < $n && $s[$j] !== '}') {
                    if ($s[$j] === '{' || $s[$j] === '[') {
                        return null;
                    }
                    if ($s[$j] === '#' || ($s[$j] === '/' && ($s[$j + 1] ?? '') === '/')) {
                        $e = strpos($s, "\n", $j);
                        $j = $e === false ? $n : $e;
                        continue;
                    }
                    $body .= $s[$j++];
                }
                if ($j >= $n) {
                    return null;
                }
                $pairs = [];
                $rest = trim((string) preg_replace_callback('/([A-Za-z-]+)\s*[:=]\s*("[^"]*"|[^\s,]+)/', function (array $m) use (&$pairs): string {
                    $pairs[$m[1]] = trim($m[2], '"');

                    return '';
                }, $body), " \t\r\n,");
                if ($rest !== '') {
                    return null;
                }
                $elements[] = ['pairs' => $pairs, 'label' => '', 'closedOnLine' => substr_count($s, "\n", 0, $j)];
                $i = $j + 1;
            } else {
                return null;
            }
        }

        $area = ['mode' => 'whole', 'nether_ceiling' => false, 'hide' => []];
        $included = false;
        foreach ($elements as $el) {
            $p = $el['pairs'];
            $subtract = ($p['subtract'] ?? 'false') === 'true';
            unset($p['subtract']);
            $type = $p['type'] ?? 'box';
            unset($p['type']);
            foreach ($p as $v) {
                if (!is_numeric($v)) {
                    return null;
                }
            }
            if ($type === 'circle' && !$subtract) {
                if ($included || array_diff(array_keys($p), ['center-x', 'center-z', 'radius']) !== [] || count($p) !== 3) {
                    return null;
                }
                $included = true;
                $area['mode'] = 'circle';
                $area['cx'] = (float) $p['center-x'];
                $area['cz'] = (float) $p['center-z'];
                $area['radius'] = (float) $p['radius'];
                continue;
            }
            if ($type !== 'box' || array_diff(array_keys($p), ['min-x', 'max-x', 'min-z', 'max-z', 'min-y', 'max-y']) !== []) {
                return null;
            }
            $xz = isset($p['min-x'], $p['max-x'], $p['min-z'], $p['max-z']);
            if (!$subtract) {
                if ($p === []) {
                    $included = $included || false;
                    continue;
                }
                if ($included || !$xz || isset($p['min-y']) || isset($p['max-y'])) {
                    return null;
                }
                $included = true;
                $area['mode'] = 'box';
                $area['min_x'] = (int) $p['min-x'];
                $area['max_x'] = (int) $p['max-x'];
                $area['min_z'] = (int) $p['min-z'];
                $area['max_z'] = (int) $p['max-z'];
                continue;
            }
            if (!$xz && count($p) === 2 && ($p['min-y'] ?? null) !== null && (int) $p['min-y'] === 90 && (int) ($p['max-y'] ?? -1) === 127) {
                $area['nether_ceiling'] = true;
                continue;
            }
            if (!$xz) {
                return null;
            }
            $h = ['label' => $el['label'], 'min_x' => (int) $p['min-x'], 'max_x' => (int) $p['max-x'], 'min_z' => (int) $p['min-z'], 'max_z' => (int) $p['max-z']];
            $h['min_y'] = isset($p['min-y']) ? (int) $p['min-y'] : null;
            $h['max_y'] = isset($p['max-y']) ? (int) $p['max-y'] : null;
            $area['hide'][] = $h;
        }

        return $area;
    }

    /** @return array{0: int, 1: int, 2: int, 3: int} [minX, maxX, minZ, maxZ] */
    public static function squareToBox(float $cx, float $cz, float $size): array
    {
        return [(int) floor($cx - $size / 2), (int) ceil($cx + $size / 2), (int) floor($cz - $size / 2), (int) ceil($cz + $size / 2)];
    }

    /** @param array<int, mixed> $xz [minX, maxX, minZ, maxZ] */
    private static function box(array $xz, mixed $minY, mixed $maxY, bool $subtract): string
    {
        $parts = $subtract ? ['subtract: true'] : [];
        foreach ([['min-x', $xz[0]], ['max-x', $xz[1]], ['min-z', $xz[2]], ['max-z', $xz[3]], ['min-y', $minY], ['max-y', $maxY]] as [$k, $v]) {
            if ($v !== null && $v !== '') {
                $parts[] = $k . ': ' . (int) $v;
            }
        }

        return $parts === [] ? '{}' : '{ ' . implode(', ', $parts) . ' }';
    }

    private static function num(float $v): string
    {
        return rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.') ?: '0';
    }
}
