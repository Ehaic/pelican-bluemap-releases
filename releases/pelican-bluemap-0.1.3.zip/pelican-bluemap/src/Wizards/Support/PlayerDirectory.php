<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

/** Pure: the players the server has seen (usercache.json), for the "hide specific players" picker. */
final class PlayerDirectory
{
    public const UUID_PATTERN = '/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/D';
    public const MAX_PLAYERS = 500;

    /** @return list<array{name: string, uuid: string}> sorted by name, unique by uuid, at most 500 */
    public static function parseUserCache(string $json): array
    {
        $data = json_decode($json, true);
        if (!is_array($data)) {
            return [];
        }
        $seen = [];
        foreach ($data as $e) {
            if (!is_array($e) || !is_string($e['name'] ?? null) || !is_string($e['uuid'] ?? null)) {
                continue;
            }
            $uuid = strtolower($e['uuid']);
            $name = trim((string) preg_replace('/[\x00-\x1F\x7F]+/', '', $e['name']));
            if ($name === '' || strlen($name) > 64 || preg_match(self::UUID_PATTERN, $uuid) !== 1) {
                continue;
            }
            $seen[$uuid] = ['name' => $name, 'uuid' => $uuid];
        }
        $list = array_values($seen);
        usort($list, fn (array $a, array $b) => strcasecmp($a['name'], $b['name']) ?: strcmp($a['uuid'], $b['uuid']));

        return array_slice($list, 0, self::MAX_PLAYERS);
    }
}
