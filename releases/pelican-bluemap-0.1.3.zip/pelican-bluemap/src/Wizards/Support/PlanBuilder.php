<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconRaw;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconValue;

/**
 * Pure: collects the edits of one wizard run into a ChangePlan. Texts are edited in memory with HoconDocument; the
 * plan carries the full before/after content of every changed file (for the diff, the hash and the apply step).
 */
final class PlanBuilder
{
    /** @var array<string, ?string> original content of every touched path (null = missing) */
    private array $before = [];
    /** @var array<string, ?string> */
    private array $after = [];
    /** @var list<array<string, mixed>> */
    private array $ops = [];
    /** @var list<string> */
    private array $warnings = [];
    /** @var list<string> */
    private array $blockers = [];
    /** @var list<string> */
    private array $acks = [];
    /** @var list<array<string, mixed>> */
    private array $post = [];

    /** @param array<string, mixed> $ctx */
    public function __construct(private array $ctx, private string $wizard)
    {
    }

    public function exists(string $file): bool
    {
        return $this->text($file) !== null;
    }

    /** The working (edited so far) content, null = missing. */
    public function text(string $file): ?string
    {
        if (!array_key_exists($file, $this->after)) {
            $this->before[$file] = $this->ctx['files'][$file] ?? null;
            $this->after[$file] = $this->before[$file];
        }

        return $this->after[$file];
    }

    public function doc(string $file): HoconDocument
    {
        $t = $this->text($file);
        if ($t === null) {
            throw new BlueMapException("{$file} does not exist on this server.");
        }

        return HoconDocument::parse($t);
    }

    public function warn(string $w): void
    {
        if (!in_array($w, $this->warnings, true)) {
            $this->warnings[] = $w;
        }
    }

    public function block(string $b): void
    {
        if (!in_array($b, $this->blockers, true)) {
            $this->blockers[] = $b;
        }
    }

    /** Overwrite acknowledgement: listed always; blocks Apply until it is in $acks. */
    public function requireAck(string $ack, array $given): void
    {
        if (!in_array($ack, $this->acks, true)) {
            $this->acks[] = $ack;
        }
        if (!in_array($ack, $given, true)) {
            $this->block('Tick "Replace it" to overwrite: ' . $ack);
        }
    }

    /** @param array<string, mixed> $a a PendingAction without id */
    public function post(array $a): void
    {
        foreach ($this->post as $p) {
            if ($p['action'] === $a['action'] && $p['map'] === $a['map'] && $p['storage'] === ($a['storage'] ?? null)) {
                return;
            }
        }
        $this->post[] = array_merge(['id' => '', 'map' => null, 'storage' => null, 'required' => false, 'wizard' => $this->wizard, 'created_at' => gmdate('c')], $a);
    }

    // ------------------------------------------------------------------ edits

    public function upsert(string $file, string $path, mixed $value, string $label): void
    {
        $doc = $this->doc($file);
        $had = $doc->has($path);
        $before = $doc->raw($path);
        $new = $doc->upsert($path, $value);
        $this->commit($file, $new->text(), [
            'file' => $file, 'op' => $had ? (($value instanceof HoconRaw && $doc->kind($path) !== 'scalar') ? 'set_block' : 'set') : 'insert',
            'path' => $path, 'value' => $value instanceof HoconRaw ? $value->text : $value, 'to' => null, 'label' => $label,
            'before' => $before === null ? null : self::display($before), 'after' => self::display(HoconValue::render($value)),
        ]);
    }

    public function commentOut(string $file, string $path, string $note, string $label): void
    {
        $doc = $this->doc($file);
        if (!$doc->has($path)) {
            return;
        }
        $before = $doc->raw($path);
        $this->commit($file, $doc->commentOut($path, $note)->text(), [
            'file' => $file, 'op' => 'comment_out', 'path' => $path, 'value' => null, 'to' => null, 'label' => $label,
            'before' => self::display((string) $before), 'after' => '(commented out)',
        ]);
    }

    public function remove(string $file, string $path, string $label): void
    {
        $doc = $this->doc($file);
        if (!$doc->has($path)) {
            return;
        }
        $before = $doc->raw($path);
        $this->commit($file, $doc->remove($path)->text(), [
            'file' => $file, 'op' => 'set_block', 'path' => $path, 'value' => null, 'to' => null, 'label' => $label,
            'before' => self::display((string) $before), 'after' => '(removed)',
        ]);
    }

    /** Whole-file replacement (JSON files and new files). */
    public function replaceText(string $file, string $text, string $op, ?string $path, mixed $value, string $label, ?string $before, ?string $after): void
    {
        $this->commit($file, $text, [
            'file' => $file, 'op' => $op, 'path' => $path, 'value' => $value, 'to' => null, 'label' => $label,
            'before' => $before, 'after' => $after,
        ]);
    }

    public function create(string $file, string $content, string $label): void
    {
        if ($this->text($file) !== null) {
            throw new BlueMapException("{$file} already exists.");
        }
        $this->after[$file] = $content;
        $this->ops[] = ['file' => $file, 'op' => 'create', 'path' => null, 'value' => null, 'to' => null, 'label' => $label, 'before' => null, 'after' => '(new file)'];
    }

    /** Moves the working content to $to (an existing $to is refused). */
    public function rename(string $from, string $to, string $label): void
    {
        $t = $this->text($from);
        if ($t === null) {
            throw new BlueMapException("{$from} does not exist on this server.");
        }
        if ($this->text($to) !== null) {
            throw new BlueMapException("{$to} already exists.");
        }
        $this->after[$to] = $t;
        $this->after[$from] = null;
        $this->ops[] = ['file' => $from, 'op' => 'rename', 'path' => null, 'value' => null, 'to' => $to, 'label' => $label, 'before' => basename($from), 'after' => basename($to)];
    }

    /** @return array<string, mixed> ChangePlan */
    public function build(): array
    {
        $files = [];
        $renamedFrom = [];
        foreach ($this->ops as $op) {
            if ($op['op'] === 'rename') {
                $renamedFrom[$op['file']] = $op['to'];
            }
        }
        foreach ($this->after as $path => $after) {
            $before = $this->before[$path] ?? null;
            if ($before !== $after) {
                $files[$path] = ['before' => $before, 'after' => $after];
            }
        }
        ksort($files);
        $hash = sha1((string) json_encode($files, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PARTIAL_OUTPUT_ON_ERROR));

        return [
            'wizard' => $this->wizard, 'ops' => $this->ops, 'files' => $files, 'plan_hash' => $hash,
            'warnings' => $this->warnings, 'blockers' => $this->blockers, 'requires_overwrite_ack' => $this->acks,
            'post_actions' => $this->post,
        ];
    }

    // ------------------------------------------------------------------ internals

    /** @param array<string, mixed> $op */
    private function commit(string $file, string $newText, array $op): void
    {
        $old = $this->text($file);
        if ($old === $newText) {
            return;
        }
        $this->after[$file] = $newText;
        $this->ops[] = $op;
    }

    private static function display(string $raw): string
    {
        $one = trim((string) preg_replace('/\s+/', ' ', $raw));
        if (strlen($raw) > 120 || substr_count($raw, "\n") > 1) {
            return '(block, ' . (substr_count($raw, "\n") + 1) . ' lines)';
        }

        return $one;
    }
}
