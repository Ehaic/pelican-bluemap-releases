<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

/** Pure: reads the world border out of a gzip-compressed level.dat (best effort; null when not readable). */
final class NbtWorldBorder
{
    private const MAX_DECOMPRESSED = 16 * 1024 * 1024;
    private const MAX_DEPTH = 32;

    /** @return array{center_x: float, center_z: float, size: float}|null */
    public static function read(string $gzippedLevelDat): ?array
    {
        try {
            $raw = @gzdecode($gzippedLevelDat, self::MAX_DECOMPRESSED);
            if ($raw === false || $raw === '') {
                return null;
            }
            $pos = 0;
            $type = self::byte($raw, $pos);
            if ($type !== 10) {
                return null;
            }
            self::skipString($raw, $pos);   // root name
            $root = self::compound($raw, $pos, 0);
            $data = $root['Data'] ?? null;
            if (!is_array($data)) {
                return null;
            }
            foreach (['BorderCenterX', 'BorderCenterZ', 'BorderSize'] as $k) {
                if (!isset($data[$k]) || !is_float($data[$k])) {
                    return null;
                }
            }

            return ['center_x' => $data['BorderCenterX'], 'center_z' => $data['BorderCenterZ'], 'size' => $data['BorderSize']];
        } catch (\Throwable) {
            return null;
        }
    }

    /**
     * Compound -> assoc array. Only doubles and nested compounds are kept (everything else is skipped).
     *
     * @return array<string, mixed>
     */
    private static function compound(string $b, int &$pos, int $depth): array
    {
        if ($depth > self::MAX_DEPTH) {
            throw new \RuntimeException('too deep');
        }
        $out = [];
        while (true) {
            $t = self::byte($b, $pos);
            if ($t === 0) {
                return $out;
            }
            $name = self::string($b, $pos);
            if ($t === 6) {
                $out[$name] = self::double($b, $pos);
            } elseif ($t === 10) {
                $out[$name] = self::compound($b, $pos, $depth + 1);
            } else {
                self::skip($b, $pos, $t, $depth + 1);
            }
        }
    }

    private static function skip(string $b, int &$pos, int $t, int $depth): void
    {
        if ($depth > self::MAX_DEPTH) {
            throw new \RuntimeException('too deep');
        }
        switch ($t) {
            case 1: self::need($b, $pos, 1); $pos += 1; return;
            case 2: self::need($b, $pos, 2); $pos += 2; return;
            case 3: case 5: self::need($b, $pos, 4); $pos += 4; return;
            case 4: case 6: self::need($b, $pos, 8); $pos += 8; return;
            case 7: $len = self::int($b, $pos); self::need($b, $pos, $len); $pos += $len; return;
            case 8: self::skipString($b, $pos); return;
            case 9:
                $et = self::byte($b, $pos);
                $len = self::int($b, $pos);
                for ($i = 0; $i < $len; $i++) {
                    self::skip($b, $pos, $et, $depth + 1);
                }

                return;
            case 10:
                while (true) {
                    $ct = self::byte($b, $pos);
                    if ($ct === 0) {
                        return;
                    }
                    self::skipString($b, $pos);
                    self::skip($b, $pos, $ct, $depth + 1);
                }
            case 11: $len = self::int($b, $pos); self::need($b, $pos, $len * 4); $pos += $len * 4; return;
            case 12: $len = self::int($b, $pos); self::need($b, $pos, $len * 8); $pos += $len * 8; return;
        }
        throw new \RuntimeException('unknown tag');
    }

    private static function need(string $b, int $pos, int $n): void
    {
        if ($n < 0 || $pos + $n > strlen($b)) {
            throw new \RuntimeException('truncated');
        }
    }

    private static function byte(string $b, int &$pos): int
    {
        self::need($b, $pos, 1);

        return ord($b[$pos++]);
    }

    private static function int(string $b, int &$pos): int
    {
        self::need($b, $pos, 4);
        $v = unpack('N', substr($b, $pos, 4))[1];
        $pos += 4;

        return $v >= 0x80000000 ? $v - 0x100000000 : $v;
    }

    private static function double(string $b, int &$pos): float
    {
        self::need($b, $pos, 8);
        $v = unpack('E', substr($b, $pos, 8))[1];
        $pos += 8;

        return (float) $v;
    }

    private static function string(string $b, int &$pos): string
    {
        self::need($b, $pos, 2);
        $len = unpack('n', substr($b, $pos, 2))[1];
        $pos += 2;
        self::need($b, $pos, $len);
        $s = substr($b, $pos, $len);
        $pos += $len;

        return $s;
    }

    private static function skipString(string $b, int &$pos): void
    {
        self::string($b, $pos);
    }
}
