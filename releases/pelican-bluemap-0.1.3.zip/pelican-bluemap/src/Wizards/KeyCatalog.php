<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;

/**
 * Pure version catalog (docs/WIZARDS.md section 3). Unknown HOCON keys are silently ignored by BlueMap, so a key
 * written for the wrong version would do nothing and say nothing: every wizard asks this class first.
 *
 * file kinds: core|plugin|webapp|map = HOCON files in the config dir, lang = <webroot>/lang/settings.conf,
 * state = <data>/pluginState.json. 'moved' = the key lived in that file up to and including minor 'until'.
 */
final class KeyCatalog
{
    public const KEYS = [
        'render-thread-count' => ['file' => 'core', 'path' => 'render-thread-count', 'type' => 'int', 'default' => 1, 'since' => 0, 'until' => null, 'moved' => null],
        'update-cooldown' => ['file' => 'core', 'path' => 'update-cooldown', 'type' => 'int', 'default' => 60, 'since' => 13, 'until' => null, 'moved' => ['until' => 20, 'file' => 'plugin']],
        'full-update-interval' => ['file' => 'core', 'path' => 'full-update-interval', 'type' => 'int', 'default' => 1440, 'since' => 0, 'until' => null, 'moved' => ['until' => 20, 'file' => 'plugin']],
        'region-file-check-interval' => ['file' => 'core', 'path' => 'region-file-check-interval', 'type' => 'int', 'default' => 5, 'since' => 29, 'until' => null, 'moved' => null],
        'player-render-limit' => ['file' => 'plugin', 'path' => 'player-render-limit', 'type' => 'int', 'default' => -1, 'since' => 0, 'until' => null, 'moved' => null],
        'live-player-markers' => ['file' => 'plugin', 'path' => 'live-player-markers', 'type' => 'bool', 'default' => true, 'since' => 0, 'until' => null, 'moved' => null],
        'hidden-game-modes' => ['file' => 'plugin', 'path' => 'hidden-game-modes', 'type' => 'list', 'default' => [], 'since' => 0, 'until' => null, 'moved' => null],
        'hide-vanished' => ['file' => 'plugin', 'path' => 'hide-vanished', 'type' => 'bool', 'default' => true, 'since' => 0, 'until' => null, 'moved' => null],
        'hide-invisible' => ['file' => 'plugin', 'path' => 'hide-invisible', 'type' => 'bool', 'default' => true, 'since' => 0, 'until' => null, 'moved' => null],
        'hide-sneaking' => ['file' => 'plugin', 'path' => 'hide-sneaking', 'type' => 'bool', 'default' => false, 'since' => 0, 'until' => null, 'moved' => null],
        'hide-different-world' => ['file' => 'plugin', 'path' => 'hide-different-world', 'type' => 'bool', 'default' => false, 'since' => 0, 'until' => null, 'moved' => null],
        'hide-below-sky-light' => ['file' => 'plugin', 'path' => 'hide-below-sky-light', 'type' => 'int', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        'hide-below-block-light' => ['file' => 'plugin', 'path' => 'hide-below-block-light', 'type' => 'int', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        // the key exists from 5.0 but BlueMap only honours it from 5.21
        'skin-download' => ['file' => 'plugin', 'path' => 'skin-download', 'type' => 'bool', 'default' => true, 'since' => 21, 'until' => null, 'moved' => null],
        'hidden-players' => ['file' => 'state', 'path' => 'hidden-players', 'type' => 'list', 'default' => [], 'since' => 0, 'until' => null, 'moved' => null],
        'default-to-flat-view' => ['file' => 'webapp', 'path' => 'default-to-flat-view', 'type' => 'bool', 'default' => false, 'since' => 0, 'until' => null, 'moved' => null],
        'start-location' => ['file' => 'webapp', 'path' => 'start-location', 'type' => 'string', 'default' => null, 'since' => 0, 'until' => null, 'moved' => null],
        'resolution-default' => ['file' => 'webapp', 'path' => 'resolution-default', 'type' => 'float', 'default' => 1, 'since' => 0, 'until' => null, 'moved' => null],
        'min-zoom-distance' => ['file' => 'webapp', 'path' => 'min-zoom-distance', 'type' => 'int', 'default' => 5, 'since' => 0, 'until' => null, 'moved' => null],
        'max-zoom-distance' => ['file' => 'webapp', 'path' => 'max-zoom-distance', 'type' => 'int', 'default' => 100000, 'since' => 0, 'until' => null, 'moved' => null],
        'hires-slider-min' => ['file' => 'webapp', 'path' => 'hires-slider-min', 'type' => 'int', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        'hires-slider-default' => ['file' => 'webapp', 'path' => 'hires-slider-default', 'type' => 'int', 'default' => 100, 'since' => 0, 'until' => null, 'moved' => null],
        'hires-slider-max' => ['file' => 'webapp', 'path' => 'hires-slider-max', 'type' => 'int', 'default' => 500, 'since' => 0, 'until' => null, 'moved' => null],
        'lowres-slider-min' => ['file' => 'webapp', 'path' => 'lowres-slider-min', 'type' => 'int', 'default' => 500, 'since' => 0, 'until' => null, 'moved' => null],
        'lowres-slider-default' => ['file' => 'webapp', 'path' => 'lowres-slider-default', 'type' => 'int', 'default' => 2000, 'since' => 0, 'until' => null, 'moved' => null],
        'lowres-slider-max' => ['file' => 'webapp', 'path' => 'lowres-slider-max', 'type' => 'int', 'default' => 7000, 'since' => 0, 'until' => null, 'moved' => null],
        'use-cookies' => ['file' => 'webapp', 'path' => 'use-cookies', 'type' => 'bool', 'default' => true, 'since' => 0, 'until' => null, 'moved' => null],
        'lang-default' => ['file' => 'lang', 'path' => 'default', 'type' => 'string', 'default' => 'en', 'since' => 0, 'until' => null, 'moved' => null],
        'lang-use-browser-language' => ['file' => 'lang', 'path' => 'useBrowserLanguage', 'type' => 'bool', 'default' => true, 'since' => 5, 'until' => null, 'moved' => null],
        'name' => ['file' => 'map', 'path' => 'name', 'type' => 'string', 'default' => null, 'since' => 0, 'until' => null, 'moved' => null],
        'sorting' => ['file' => 'map', 'path' => 'sorting', 'type' => 'int', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        'start-pos' => ['file' => 'map', 'path' => 'start-pos', 'type' => 'object', 'default' => null, 'since' => 0, 'until' => null, 'moved' => null],
        'sky-color' => ['file' => 'map', 'path' => 'sky-color', 'type' => 'color', 'default' => '#7dabff', 'since' => 0, 'until' => null, 'moved' => null],
        'void-color' => ['file' => 'map', 'path' => 'void-color', 'type' => 'color', 'default' => '#000000', 'since' => 0, 'until' => null, 'moved' => null],
        'ambient-light' => ['file' => 'map', 'path' => 'ambient-light', 'type' => 'float', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        'sky-light' => ['file' => 'map', 'path' => 'sky-light', 'type' => 'float', 'default' => 1, 'since' => 5, 'until' => null, 'moved' => null],
        'remove-caves-below-y' => ['file' => 'map', 'path' => 'remove-caves-below-y', 'type' => 'int', 'default' => 55, 'since' => 0, 'until' => null, 'moved' => null],
        'cave-detection-ocean-floor' => ['file' => 'map', 'path' => 'cave-detection-ocean-floor', 'type' => 'int', 'default' => 10000, 'since' => 0, 'until' => null, 'moved' => null],
        'cave-detection-uses-block-light' => ['file' => 'map', 'path' => 'cave-detection-uses-block-light', 'type' => 'bool', 'default' => false, 'since' => 0, 'until' => null, 'moved' => null],
        'min-inhabited-time' => ['file' => 'map', 'path' => 'min-inhabited-time', 'type' => 'int', 'default' => 0, 'since' => 0, 'until' => null, 'moved' => null],
        'render-mask' => ['file' => 'map', 'path' => 'render-mask', 'type' => 'list', 'default' => null, 'since' => 11, 'until' => null, 'moved' => null],
        'min-x' => ['file' => 'map', 'path' => 'min-x', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'max-x' => ['file' => 'map', 'path' => 'max-x', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'min-z' => ['file' => 'map', 'path' => 'min-z', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'max-z' => ['file' => 'map', 'path' => 'max-z', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'min-y' => ['file' => 'map', 'path' => 'min-y', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'max-y' => ['file' => 'map', 'path' => 'max-y', 'type' => 'int', 'default' => null, 'since' => 0, 'until' => 10, 'moved' => null],
        'render-edges' => ['file' => 'map', 'path' => 'render-edges', 'type' => 'bool', 'default' => true, 'since' => 0, 'until' => null, 'moved' => null],
        'edge-light-strength' => ['file' => 'map', 'path' => 'edge-light-strength', 'type' => 'int', 'default' => 15, 'since' => 11, 'until' => null, 'moved' => null],
        'enable-hires' => ['file' => 'map', 'path' => 'enable-hires', 'type' => 'bool', 'default' => true, 'since' => 5, 'until' => null, 'moved' => null],
        'enable-perspective-view' => ['file' => 'map', 'path' => 'enable-perspective-view', 'type' => 'bool', 'default' => true, 'since' => 5, 'until' => null, 'moved' => null],
        'enable-flat-view' => ['file' => 'map', 'path' => 'enable-flat-view', 'type' => 'bool', 'default' => true, 'since' => 5, 'until' => null, 'moved' => null],
        'enable-free-flight-view' => ['file' => 'map', 'path' => 'enable-free-flight-view', 'type' => 'bool', 'default' => true, 'since' => 5, 'until' => null, 'moved' => null],
        'marker-sets.pelican-pois' => ['file' => 'map', 'path' => 'marker-sets.pelican-pois', 'type' => 'object', 'default' => null, 'since' => 0, 'until' => null, 'moved' => null],
    ];

    /** @param array{raw: string, major: int, minor: int} $version */
    public static function supports(string $key, array $version): bool
    {
        $k = self::KEYS[$key] ?? null;
        if ($k === null || ($version['major'] ?? 0) !== 5) {
            return false;
        }

        return $version['minor'] >= $k['since'] && ($k['until'] === null || $version['minor'] <= $k['until']);
    }

    /** The file kind ('core'|'plugin'|...) the installed version reads this key from, or null when unsupported. */
    public static function fileKind(string $key, array $version): ?string
    {
        if (!self::supports($key, $version)) {
            return null;
        }
        $k = self::KEYS[$key];

        return ($k['moved'] !== null && $version['minor'] <= $k['moved']['until']) ? $k['moved']['file'] : $k['file'];
    }

    /**
     * File path holding the key. For 'map' keys $mapId is the map id (C/maps/<id>.conf); for 'state' and 'lang'
     * keys the fourth argument is the <data> / <webroot> directory (the catalog does not know those paths).
     *
     * @param array{raw: string, major: int, minor: int} $version
     */
    public static function locate(string $key, array $version, string $configDir, ?string $mapId = null): ?string
    {
        $kind = self::fileKind($key, $version);
        if ($kind === null) {
            return null;
        }
        $c = rtrim($configDir, '/');
        switch ($kind) {
            case 'core':
            case 'plugin':
            case 'webapp':
                return $c . '/' . $kind . '.conf';
            case 'map':
                return $mapId === null ? null : $c . '/maps/' . $mapId . '.conf';
            case 'lang':
                return $mapId === null ? null : rtrim($mapId, '/') . '/lang/settings.conf';
            case 'state':
                return $mapId === null ? null : rtrim($mapId, '/') . '/pluginState.json';
        }

        return null;
    }

    /**
     * Keys present in a file where the installed version ignores them (or, for render-mask / legacy area keys,
     * where they are harmful). $files = path => content (null = missing); config-dir files are told apart by name.
     *
     * @param array{raw: string, major: int, minor: int} $version
     * @return list<array{key: string, file: string}>
     */
    public static function deadCopies(array $version, array $files): array
    {
        $out = [];
        foreach ($files as $path => $content) {
            $kind = self::kindOfPath((string) $path);
            if ($content === null || $kind === null) {
                continue;
            }
            try {
                $doc = HoconDocument::parse($content);
            } catch (\Throwable) {
                continue;
            }
            foreach (self::KEYS as $key => $k) {
                if (!in_array($k['file'], ['core', 'plugin', 'webapp', 'map'], true) || !$doc->has($k['path'])) {
                    continue;
                }
                $expected = self::fileKind($key, $version);
                $own = $k['moved'] !== null ? [$k['file'], $k['moved']['file']] : [$k['file']];
                if (in_array($kind, $own, true) && $kind !== $expected) {
                    $out[] = ['key' => $key, 'file' => (string) $path];
                }
            }
        }

        return $out;
    }

    private static function kindOfPath(string $path): ?string
    {
        $base = basename($path);
        if (in_array($base, ['core.conf', 'plugin.conf', 'webapp.conf'], true)) {
            return substr($base, 0, -5);
        }
        if (basename(dirname($path)) === 'maps' && (str_ends_with($base, '.conf') || str_ends_with($base, '.conf.disabled'))) {
            return 'map';
        }

        return null;
    }
}
