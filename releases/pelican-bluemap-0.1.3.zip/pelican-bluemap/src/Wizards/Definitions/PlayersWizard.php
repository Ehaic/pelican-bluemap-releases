<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\PlayerDirectory;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.4 Players & privacy. The per-player part edits <data>/pluginState.json (stopped server only). */
final class PlayersWizard extends BaseWizard
{
    public const MODES = ['survival' => 'Survival', 'creative' => 'Creative', 'adventure' => 'Adventure', 'spectator' => 'Spectator'];
    private const LIGHT = ['never' => [0, 0], 'dark' => [1, 1], 'underground' => [4, 16]];
    private const BOOLS = [
        'live_player_markers' => 'live-player-markers', 'hide_vanished' => 'hide-vanished', 'hide_invisible' => 'hide-invisible',
        'hide_sneaking' => 'hide-sneaking', 'hide_different_world' => 'hide-different-world',
    ];

    public function id(): string
    {
        return 'players';
    }

    protected function title(): string
    {
        return 'Players & privacy';
    }

    protected function description(): string
    {
        return 'Choose which players show up as live markers on the public map.';
    }

    protected function icon(): string
    {
        return 'tabler-users';
    }

    public function files(array $ctx): array
    {
        return [$this->configFile($ctx, 'plugin.conf'), $this->statePath($ctx), 'usercache.json'];
    }

    private function statePath(array $ctx): string
    {
        return rtrim((string) $ctx['data_dir'], '/') . '/pluginState.json';
    }

    /** @return array{0: ?array<string, mixed>, 1: ?string} [decoded state object as array of top-level members, error] */
    private function state(array $ctx): array
    {
        $t = $ctx['files'][$this->statePath($ctx)] ?? null;
        if ($t === null) {
            return [[], null];
        }
        $d = json_decode($t);
        if (!is_object($d)) {
            return [null, 'pluginState.json is not valid JSON; BlueMap would reset it. Fix or delete it first.'];
        }

        return [(array) $d, null];
    }

    /** @return list<string> */
    private function hiddenFrom(?array $state): array
    {
        $h = $state['hidden-players'] ?? [];
        $out = [];
        foreach (is_array($h) ? $h : [] as $u) {
            if (is_string($u) && preg_match(PlayerDirectory::UUID_PATTERN, strtolower($u)) === 1) {
                $out[] = strtolower($u);
            }
        }
        sort($out);

        return array_values(array_unique($out));
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $v = [];
        foreach (self::BOOLS as $f => $key) {
            $v[$f] = (bool) $this->keyValue($ctx, $key);
        }
        $modes = $this->keyValue($ctx, 'hidden-game-modes');
        $v['hidden_game_modes'] = is_array($modes) ? array_values(array_filter($modes, fn ($m) => isset(self::MODES[$m]))) : [];
        $sky = (int) $this->keyValue($ctx, 'hide-below-sky-light');
        $blk = (int) $this->keyValue($ctx, 'hide-below-block-light');
        $v['light_preset'] = 'custom';
        foreach (self::LIGHT as $name => [$s, $b]) {
            if ($s === $sky && $b === $blk) {
                $v['light_preset'] = $name;
            }
        }
        $v['sky_light'] = $sky;
        $v['block_light'] = $blk;
        $v['skin_download'] = $this->supports($ctx, 'skin-download') ? (bool) $this->keyValue($ctx, 'skin-download') : null;
        [$state, $err] = $this->state($ctx);
        $v['hidden_players'] = $this->hiddenFrom($state);
        $v['state_error'] = $err;
        $v['known_players'] = PlayerDirectory::parseUserCache((string) ($ctx['files']['usercache.json'] ?? ''));
        $v['manual_uuids'] = '';

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $rules = [
            Spec::field('live_player_markers', 'toggle', 'Show players on the map', ['default' => true, 'help' => 'The master switch. Off hides every player.']),
            Spec::field('hidden_game_modes', 'multiselect', 'Hide players in these game modes', ['options' => self::MODES, 'default' => []]),
            Spec::field('hide_vanished', 'toggle', 'Hide vanished players', ['default' => true]),
            Spec::field('hide_invisible', 'toggle', 'Hide invisible players', ['default' => true]),
            Spec::field('hide_sneaking', 'toggle', 'Hide sneaking players', ['default' => false]),
            Spec::field('hide_different_world', 'toggle', 'Hide players in other worlds than the map', ['default' => false]),
            Spec::field('light_preset', 'radio', 'Hide players by light', ['default' => 'never', 'options' => [
                'never' => 'Never', 'dark' => 'In complete darkness', 'underground' => 'Underground (surface only)', 'custom' => 'Custom',
            ]]),
            Spec::field('sky_light', 'int', 'Hide below sky light', ['min' => 0, 'max' => 16, 'default' => 0, 'visible_if' => Spec::visibleIf('light_preset', ['custom'])]),
            Spec::field('block_light', 'int', 'Hide below block light', ['min' => 0, 'max' => 16, 'default' => 0, 'visible_if' => Spec::visibleIf('light_preset', ['custom'])]),
        ];
        if ($this->supports($ctx, 'skin-download')) {
            $rules[] = Spec::field('skin_download', 'toggle', 'Download player skins', ['default' => true, 'help' => 'Shows skins on the markers.']);
        }
        $err = $current['state_error'] ?? null;
        $hide = [
            Spec::field('hidden_players', 'players', 'Hide these players', [
                'default' => [], 'options' => array_column((array) ($current['known_players'] ?? []), 'name', 'uuid'),
                'max_items' => 500, 'disabled_reason' => $err,
                'help' => 'Players the server has seen. They never appear on the map, whatever their game mode. Applies on the next start.',
            ]),
            Spec::field('manual_uuids', 'textarea', 'More player UUIDs', ['max_items' => 100, 'disabled_reason' => $err, 'help' => 'One UUID per line, for players the server has not seen.']),
        ];

        return [Spec::step('rules', 'Rules', null, $rules), Spec::step('hide', 'Hide specific players', 'Written to pluginState.json, which BlueMap rewrites on shutdown, so this only works while the server is stopped.', $hide)];
    }

    /** @return list<string>|null null = invalid input */
    private function uuids(array $input, array &$e): ?array
    {
        $out = [];
        $bad = false;
        foreach ((array) ($input['hidden_players'] ?? []) as $u) {
            $u = strtolower(trim((string) $u));
            if (preg_match(PlayerDirectory::UUID_PATTERN, $u) !== 1) {
                $bad = true;
                continue;
            }
            $out[$u] = true;
        }
        $manual = (string) ($input['manual_uuids'] ?? '');
        $lines = preg_split('/[\s,;]+/', trim($manual)) ?: [];
        foreach ($lines as $l) {
            if ($l === '') {
                continue;
            }
            $l = strtolower($l);
            if (preg_match(PlayerDirectory::UUID_PATTERN, $l) !== 1) {
                self::err($e, 'manual_uuids', 'Not a valid UUID: ' . mb_substr($l, 0, 40));
                $bad = true;
                continue;
            }
            $out[$l] = true;
        }
        if ($bad) {
            self::err($e, 'hidden_players', 'Contains an invalid player id.');
        }
        if (count($out) > 500) {
            self::err($e, 'hidden_players', 'At most 500 hidden players.');
        }
        $list = array_keys($out);
        sort($list);

        return $list;
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        foreach ((array) ($input['hidden_game_modes'] ?? []) as $m) {
            if (!isset(self::MODES[(string) $m])) {
                self::err($e, 'hidden_game_modes', 'Unknown game mode.');
            }
        }
        $lp = (string) ($input['light_preset'] ?? 'never');
        if (!in_array($lp, ['never', 'dark', 'underground', 'custom'], true)) {
            self::err($e, 'light_preset', 'Unknown preset.');
        }
        if ($lp === 'custom') {
            foreach (['sky_light', 'block_light'] as $f) {
                if (Check::int($input[$f] ?? null, 0, 16) === null) {
                    self::err($e, $f, 'Use 0 to 16.');
                }
            }
        }
        $this->uuids($input, $e);

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $file = $this->configFile($ctx, 'plugin.conf');
        if ($this->doc($ctx, $file) === null) {
            $b->block('plugin.conf can not be read or edited safely.');

            return $b->build();
        }
        $want = [];
        foreach (self::BOOLS as $f => $key) {
            if (array_key_exists($f, $input)) {
                $want[$key] = Check::bool($input[$f]);
            }
        }
        $modes = array_values(array_unique(array_map('strval', (array) ($input['hidden_game_modes'] ?? []))));
        $order = array_keys(self::MODES);
        usort($modes, fn ($a, $c) => array_search($a, $order, true) <=> array_search($c, $order, true));
        $want['hidden-game-modes'] = $modes;
        $lp = (string) ($input['light_preset'] ?? 'never');
        [$sky, $blk] = $lp === 'custom' ? [(int) ($input['sky_light'] ?? 0), (int) ($input['block_light'] ?? 0)] : (self::LIGHT[$lp] ?? [0, 0]);
        $want['hide-below-sky-light'] = $sky;
        $want['hide-below-block-light'] = $blk;
        if ($this->supports($ctx, 'skin-download') && array_key_exists('skin_download', $input)) {
            $want['skin-download'] = Check::bool($input['skin_download'], true);
        }

        foreach ($want as $key => $val) {
            $d = $b->doc($file);
            $k = KeyCatalog::KEYS[$key];
            $cur = $d->has($k['path']) ? $d->get($k['path']) : $k['default'];
            if (!self::same($cur, $val) && !($cur === null && $val === [])) {
                $b->upsert($file, $k['path'], $val, 'plugin.conf · ' . $key);
            }
        }

        // pluginState.json
        $path = $this->statePath($ctx);
        [$state, $err] = $this->state($ctx);
        $e = [];
        $hidden = $this->uuids($input, $e) ?? [];
        if ($err !== null) {
            if ($hidden !== []) {
                $b->block($err);
            } else {
                $b->warn($err . ' The per-player step was skipped.');
            }

            return $b->build();
        }
        if ($hidden !== $this->hiddenFrom($state) || ($b->text($path) === null && $hidden !== [])) {
            $raw = $b->text($path);
            if ($raw === null) {
                $new = json_encode(['hidden-players' => $hidden], JSON_UNESCAPED_SLASHES);
            } else {
                $obj = json_decode($raw);
                $obj->{'hidden-players'} = $hidden;
                $new = json_encode($obj, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION);
            }
            $cur = $this->hiddenFrom($state);
            $b->replaceText($path, (string) $new, 'json_set', 'hidden-players', $hidden, 'pluginState.json · hidden-players', count($cur) . ' hidden', count($hidden) . ' hidden');
            if ($raw === null) {
                $b->warn('pluginState.json does not exist yet; it is created with just the hidden players and BlueMap fills in the rest.');
            }
        }

        return $b->build();
    }
}
