<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\BlueMapVersion;
use Ehaic\PelicanBlueMap\Wizards\Contracts\Wizard;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;

/** Shared helpers of the wizard definitions. Pure: everything comes from the WizardContext. */
abstract class BaseWizard implements Wizard
{
    /** @var array<string, ?HoconDocument> */
    private array $docCache = [];

    abstract protected function title(): string;

    abstract protected function description(): string;

    abstract protected function icon(): string;

    protected function kind(): string
    {
        return 'config';
    }

    /** Extra availability rule on top of "BlueMap 5.x known". */
    protected function unavailableReason(array $ctx): ?string
    {
        return null;
    }

    public function files(array $ctx): array
    {
        return [];
    }

    public function meta(array $ctx): array
    {
        $reason = $this->versionReason($ctx) ?? $this->unavailableReason($ctx);
        $state = $ctx['state'] ?? null;
        $drift = false;
        if (is_array($state)) {
            foreach ((array) ($state['files'] ?? []) as $path => $sha) {
                if (array_key_exists($path, $ctx['files'] ?? []) && ($ctx['files'][$path] === null || sha1((string) $ctx['files'][$path]) !== $sha)) {
                    $drift = true;
                }
            }
        }

        return [
            'id' => $this->id(), 'title' => $this->title(), 'description' => $this->description(), 'icon' => $this->icon(),
            'kind' => $this->kind(), 'available' => $reason === null, 'unavailable_reason' => $reason,
            'last_applied_at' => is_array($state) ? ($state['applied_at'] ?? null) : null, 'drift' => $drift, 'pending' => 0,
        ];
    }

    protected function versionReason(array $ctx): ?string
    {
        $v = $ctx['version'] ?? null;
        if (!is_array($v) || ($v['major'] ?? 0) !== 5) {
            return 'Unknown BlueMap version, run Update first.';
        }

        return null;
    }

    // ------------------------------------------------------------------ context helpers

    /** @return array{raw: string, major: int, minor: int} */
    protected function ver(array $ctx): array
    {
        return $ctx['version'];
    }

    protected function atLeast(array $ctx, int $minor): bool
    {
        return BlueMapVersion::atLeast($ctx['version'], $minor);
    }

    protected function configFile(array $ctx, string $name): string
    {
        return rtrim((string) $ctx['config_dir'], '/') . '/' . $name;
    }

    /** Parsed document of a loaded file, null when missing or unparseable. */
    protected function doc(array $ctx, string $path): ?HoconDocument
    {
        $t = $ctx['files'][$path] ?? null;
        if ($t === null) {
            return null;
        }
        // Keyed by content: one wizard instance serves many contexts (registry is reused), so a path alone would go stale.
        $key = $path . "\0" . md5($t);
        if (!array_key_exists($key, $this->docCache)) {
            if (count($this->docCache) > 64) {
                $this->docCache = [];
            }
            try {
                $this->docCache[$key] = HoconDocument::parse($t);
            } catch (\Throwable) {
                $this->docCache[$key] = null;
            }
        }

        return $this->docCache[$key];
    }

    /** Path of the file a catalog key lives in for this version (null = unsupported / needs a map id). */
    protected function pathOf(array $ctx, string $key, ?string $mapId = null): ?string
    {
        $kind = KeyCatalog::fileKind($key, $ctx['version']);
        if ($kind === null) {
            return null;
        }
        if ($kind === 'lang') {
            return rtrim((string) $ctx['webroot'], '/') . '/lang/settings.conf';
        }
        if ($kind === 'state') {
            return rtrim((string) $ctx['data_dir'], '/') . '/pluginState.json';
        }

        return KeyCatalog::locate($key, $ctx['version'], (string) $ctx['config_dir'], $mapId === null ? null : $mapId);
    }

    /** Current value of a catalog key (HOCON files only) or the BlueMap default. */
    protected function keyValue(array $ctx, string $key, ?string $mapId = null): mixed
    {
        $k = KeyCatalog::KEYS[$key];
        $file = $this->pathOf($ctx, $key, $mapId);
        $doc = $file === null ? null : $this->doc($ctx, $file);
        if ($doc !== null && $doc->has($k['path'])) {
            return $doc->get($k['path']);
        }

        return $k['default'];
    }

    protected function supports(array $ctx, string $key): bool
    {
        return KeyCatalog::supports($key, $ctx['version']);
    }

    /** @return list<array<string, mixed>> MapInfo */
    protected function maps(array $ctx): array
    {
        return (array) ($ctx['maps'] ?? []);
    }

    /** @return list<array<string, mixed>> */
    protected function enabledMaps(array $ctx): array
    {
        return array_values(array_filter($this->maps($ctx), fn (array $m) => $m['enabled']));
    }

    /** @return array<string, mixed>|null */
    protected function mapById(array $ctx, ?string $id): ?array
    {
        foreach ($this->maps($ctx) as $m) {
            if ($m['id'] === $id) {
                return $m;
            }
        }

        return null;
    }

    /** The map a one-map wizard works on: the asked one, else the first enabled. */
    protected function pickMap(array $ctx, ?string $mapId): ?array
    {
        return $this->mapById($ctx, $mapId) ?? ($this->enabledMaps($ctx)[0] ?? null);
    }

    /** @return array<string, string> id => "Name (dimension)" for the map select */
    protected function mapOptions(array $ctx, bool $enabledOnly = true): array
    {
        $o = [];
        foreach ($enabledOnly ? $this->enabledMaps($ctx) : $this->maps($ctx) as $m) {
            $o[$m['id']] = ($m['name'] ?? $m['id']) . ($m['dimension'] !== null ? ' (' . $m['dimension'] . ')' : '');
        }

        return $o;
    }

    /** "minecraft:the_nether" -> "the_nether". */
    protected static function dimKey(?string $dimension): string
    {
        $d = (string) $dimension;

        return str_starts_with($d, 'minecraft:') ? substr($d, 10) : $d;
    }

    // ------------------------------------------------------------------ per-map wizards (one collapsed row per map)

    /**
     * Single-map values of a per-map wizard (the map's own settings, no row id). Per-map wizards implement this; their
     * `current()` returns these for every enabled map as rows, or just this map's values when a map id is asked for.
     *
     * @return array<string, mixed>
     */
    protected function currentFor(array $ctx, string $mapId): array
    {
        return [];
    }

    /** @return array<string, mixed> single-map input problems keyed by field */
    protected function validateOne(array $ctx, array $input): array
    {
        return [];
    }

    /** Plans one map's input into the shared builder. */
    protected function planOne(PlanBuilder $b, array $ctx, array $input, array $acks): void
    {
    }

    /** Rows of the per-map form: id + dimension + the map's own values, for every enabled map. @return list<array<string, mixed>> */
    protected function mapRows(array $ctx): array
    {
        $rows = [];
        foreach ($this->enabledMaps($ctx) as $m) {
            $rows[] = ['id' => $m['id'], 'dimension' => (string) ($m['dimension'] ?? '')] + array_diff_key($this->currentFor($ctx, (string) $m['id']), ['map' => 1]);
        }

        return $rows;
    }

    protected static function isRowInput(array $input): bool
    {
        return array_key_exists('maps', $input) && is_array($input['maps']);
    }

    /**
     * True when the row differs from what the map has now: untouched rows are never validated, planned or acknowledged.
     *
     * Fields the row hides (visible_if, e.g. the centre of a "whole world" area) are not compared: the browser does not
     * submit hidden fields, so they arrive empty and would make every untouched row look edited (and rewrite its file).
     * The dimension used for that visibility is the map's real one, never the posted one.
     */
    protected function rowChanged(array $ctx, array $row): bool
    {
        $id = (string) ($row['id'] ?? '');
        $cur = $this->currentFor($ctx, $id);
        $specs = [];
        foreach ($this->steps($ctx, []) as $step) {
            foreach ((array) ($step['fields'] ?? []) as $f) {
                if (!empty($f['per_map'])) {
                    foreach ((array) ($f['children'] ?? []) as $c) {
                        $specs[(string) $c['name']] = $c;
                    }
                }
            }
        }
        $vis = $row;
        $vis['dimension'] = (string) ($this->mapById($ctx, $id)['dimension'] ?? '');
        foreach ($row as $k => $v) {
            if (in_array($k, ['id', 'dimension', 'map'], true)) {
                continue;
            }
            $rule = $specs[$k]['visible_if'] ?? null;
            if (is_array($rule) && !in_array((string) ($vis[(string) $rule['field']] ?? ''), array_map('strval', (array) ($rule['in'] ?? [])), true)) {
                continue;
            }
            if (!self::looseEqual($v, $cur[$k] ?? null)) {
                return true;
            }
        }

        return false;
    }

    /** Equal the way the browser round trip sees it: '' = null, "5" = 5, rows compared by the keys of the left side. */
    protected static function looseEqual(mixed $a, mixed $b): bool
    {
        if (is_array($a) || is_array($b)) {
            $a = $a ?? [];
            $b = $b ?? [];
            if (!is_array($a) || !is_array($b)) {
                return false;
            }
            if (array_is_list($a) && array_is_list($b)) {
                if (count($a) !== count($b)) {
                    return false;
                }
                foreach ($a as $i => $v) {
                    if (!self::looseEqual($v, $b[$i])) {
                        return false;
                    }
                }

                return true;
            }
            foreach ($a as $k => $v) {
                if (!self::looseEqual($v, $b[$k] ?? null)) {
                    return false;
                }
            }

            return true;
        }
        if ($a === null || $a === '') {
            return $b === null || $b === '';
        }
        if ($b === null || $b === '') {
            return false;
        }
        if (is_bool($a) || is_bool($b)) {
            return (bool) $a === (bool) $b;
        }
        if (is_numeric($a) && is_numeric($b)) {
            return (float) $a === (float) $b;
        }

        return (string) $a === (string) $b;
    }

    /**
     * Validation of a per-map wizard: row input is checked per changed row (error keys `maps.N.field`); a plain
     * single-map input (`map` + fields) still works.
     *
     * @return array<string, string>
     */
    protected function validateMaps(array $ctx, array $input): array
    {
        if (!self::isRowInput($input)) {
            return $this->validateOne($ctx, $input);
        }
        $e = [];
        $known = array_column($this->enabledMaps($ctx), 'id');
        $seen = [];
        foreach (self::rows($input['maps']) as $i => $row) {
            $id = (string) ($row['id'] ?? '');
            if (!in_array($id, $known, true) || isset($seen[$id])) {
                self::err($e, "maps.$i.id", 'Unknown map.');
                continue;
            }
            $seen[$id] = true;
            if (!$this->rowChanged($ctx, $row)) {
                continue;
            }
            foreach ($this->validateOne($ctx, ['map' => $id] + $row) as $field => $msg) {
                self::err($e, "maps.$i.$field", $id . ': ' . $msg);
            }
        }

        return $e;
    }

    /** Plan of a per-map wizard: only the rows that changed produce operations. */
    protected function planMaps(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        if (!self::isRowInput($input)) {
            $this->planOne($b, $ctx, $input, $acks);

            return $b->build();
        }
        $known = array_column($this->enabledMaps($ctx), 'id');
        $seen = [];
        foreach (self::rows($input['maps']) as $row) {
            $id = (string) ($row['id'] ?? '');
            if (!in_array($id, $known, true) || isset($seen[$id])) {
                $b->block('Unknown map ' . $id . '.');
                continue;
            }
            $seen[$id] = true;
            if ($this->rowChanged($ctx, $row)) {
                $this->planOne($b, $ctx, ['map' => $id] + $row, $acks);
            }
        }

        return $b->build();
    }

    protected function builder(array $ctx): PlanBuilder
    {
        return new PlanBuilder($ctx, $this->id());
    }

    /** @param array<string, string> $errors */
    protected static function err(array &$errors, string $field, string $msg): void
    {
        if (!isset($errors[$field])) {
            $errors[$field] = $msg;
        }
    }

    /** Compare for "did this change" without float/int/string noise. */
    protected static function same(mixed $a, mixed $b): bool
    {
        if (is_numeric($a) && is_numeric($b)) {
            return (float) $a === (float) $b;
        }
        if (is_array($a) && is_array($b)) {
            $a = array_map('strval', $a);
            $b = array_map('strval', $b);
            sort($a);
            sort($b);

            return $a === $b;
        }

        return $a === $b;
    }

    /** Rows of a repeater input as list of arrays. */
    protected static function rows(mixed $v): array
    {
        return is_array($v) ? array_values(array_filter($v, 'is_array')) : [];
    }
}
