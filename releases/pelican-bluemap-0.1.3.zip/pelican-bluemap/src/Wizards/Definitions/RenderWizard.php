<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.8 First render & maintenance: console only, no file writes. */
final class RenderWizard extends BaseWizard
{
    public const ACTIONS = [
        'update' => ['Render missing/changed parts', false, false],
        'fix_edges' => ['Re-render edges', true, false],
        'purge' => ['Purge and re-render', true, true],
        'force_update' => ['Force full re-render', false, true],
        'freeze' => ['Pause one map', true, false],
        'unfreeze' => ['Resume one map', true, false],
        'storage_delete' => ['Delete the data of a disabled map', true, true],
        'resume' => ['Resume rendering', false, false],
    ];

    public function id(): string
    {
        return 'render';
    }

    protected function title(): string
    {
        return 'First render & maintenance';
    }

    protected function description(): string
    {
        return 'Start the first render, fix maps after config changes and watch progress. Needs the server running.';
    }

    protected function icon(): string
    {
        return 'tabler-refresh';
    }

    protected function kind(): string
    {
        return 'console';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        return empty($ctx['server_running']) ? 'Start the server to send render commands.' : null;
    }

    public function files(array $ctx): array
    {
        return [rtrim((string) $ctx['data_dir'], '/') . '/pluginState.json'];
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $t = $ctx['files'][$this->files($ctx)[0]] ?? null;
        $d = $t === null ? null : json_decode($t, true);
        $paused = is_array($d) && array_key_exists('render-threads-enabled', $d) ? !$d['render-threads-enabled'] : null;

        return ['action' => 'update', 'map' => $mapId, 'paused' => $paused, 'running' => !empty($ctx['server_running']), 'maps' => array_column($this->maps($ctx), 'id')];
    }

    public function steps(array $ctx, array $current): array
    {
        $opts = [];
        foreach (self::ACTIONS as $k => [$l]) {
            $opts[$k] = $l;
        }
        $disabled = array_values(array_filter($this->maps($ctx), fn ($m) => !$m['enabled'] && !empty($m['storage'])));
        if ($disabled === []) {
            unset($opts['storage_delete']);
        }
        $checks = Spec::field('checks', 'text', 'Checks', ['disabled_reason' => 'Read only', 'help' => 'Server running, render threads not paused, maps and pending actions are shown here.']);
        $action = [
            Spec::field('action', 'radio', 'Action', ['options' => $opts, 'default' => 'update', 'required' => true]),
            Spec::field('map', 'select', 'Map', ['options' => $this->mapOptions($ctx, false), 'visible_if' => Spec::visibleIf('action', ['update', 'fix_edges', 'purge', 'force_update', 'freeze', 'unfreeze', 'storage_delete'])]),
        ];

        return [Spec::step('checks', 'Checks', null, [$checks]), Spec::step('action', 'Action', 'Purge, force re-render and delete ask for confirmation.', $action), Spec::step('progress', 'Progress', 'Estimated from the saved tiles; refreshed every 15 seconds.', [])];
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        $a = (string) ($input['action'] ?? '');
        if (!isset(self::ACTIONS[$a])) {
            self::err($e, 'action', 'Unknown action.');

            return $e;
        }
        $map = (string) ($input['map'] ?? '');
        if (self::ACTIONS[$a][1] && $this->mapById($ctx, $map) === null) {
            self::err($e, 'map', 'Pick a map.');
        } elseif ($map !== '' && $this->mapById($ctx, $map) === null) {
            self::err($e, 'map', 'Unknown map.');
        }
        if ($a === 'storage_delete' && ($this->mapById($ctx, $map)['enabled'] ?? true)) {
            self::err($e, 'map', 'Only disabled maps can have their data deleted.');
        }

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $b->block('This wizard sends console commands; it has nothing to apply.');

        return $b->build();
    }
}
