<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.6 Web app: what visitors see first. */
final class WebappWizard extends BaseWizard
{
    public const EXACT = '/^[A-Za-z0-9_-]{1,64}(:-?\d+(\.\d+)?){8}:(flat|perspective|free)$/D';
    private const SLIDERS = [
        'hires_min' => ['hires-slider-min', 0, 2000], 'hires_default' => ['hires-slider-default', 0, 2000], 'hires_max' => ['hires-slider-max', 0, 2000],
        'lowres_min' => ['lowres-slider-min', 100, 20000], 'lowres_default' => ['lowres-slider-default', 100, 20000], 'lowres_max' => ['lowres-slider-max', 100, 20000],
    ];

    public function id(): string
    {
        return 'webapp';
    }

    protected function title(): string
    {
        return 'Web app';
    }

    protected function description(): string
    {
        return 'What visitors see first: start view, language, quality and zoom distances.';
    }

    protected function icon(): string
    {
        return 'tabler-browser';
    }

    private function langPath(array $ctx): string
    {
        return rtrim((string) $ctx['webroot'], '/') . '/lang/settings.conf';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        foreach (['data_dir' => 'data folder', 'webroot' => 'web folder'] as $k => $l) {
            if (!self::safePath((string) ($ctx[$k] ?? ''))) {
                return "The $l path in the BlueMap config is not a plain relative path.";
            }
        }

        return null;
    }

    public static function safePath(string $p): bool
    {
        return preg_match('#^[A-Za-z0-9_./ -]{1,128}$#D', $p) === 1 && !str_starts_with($p, '/') && !in_array('..', explode('/', $p), true);
    }

    public function files(array $ctx): array
    {
        return [$this->configFile($ctx, 'webapp.conf'), $this->langPath($ctx)];
    }

    /** @return array<string, string> locale => name from the languages list of lang/settings.conf */
    private function locales(array $ctx): array
    {
        $doc = $this->doc($ctx, $this->langPath($ctx));
        $out = [];
        if ($doc !== null && $doc->has('languages')) {
            if (preg_match_all('/locale\s*[:=]\s*"([A-Za-z0-9_-]{1,16})"\s*,?\s*name\s*[:=]\s*"([^"]*)"/', (string) $doc->raw('languages'), $m, PREG_SET_ORDER) > 0) {
                foreach ($m as $x) {
                    $out[$x[1]] = $x[2];
                }
            }
        }

        return $out;
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $v = ['default_to_flat_view' => (bool) $this->keyValue($ctx, 'default-to-flat-view')];
        $sl = $this->keyValue($ctx, 'start-location');
        $v['start_mode'] = 'none';
        $v['start_map'] = null;
        $v['start_exact'] = '';
        if (is_string($sl) && $sl !== '') {
            if (preg_match(self::EXACT, $sl) === 1) {
                $v['start_mode'] = 'exact';
                $v['start_exact'] = $sl;
            } elseif ($this->mapById($ctx, $sl) !== null) {
                $v['start_mode'] = 'map';
                $v['start_map'] = $sl;
            }
        }
        $res = $this->keyValue($ctx, 'resolution-default');
        $v['resolution_default'] = is_numeric($res) ? (string) (0 + $res) : '1';
        $v['min_zoom'] = (int) $this->keyValue($ctx, 'min-zoom-distance');
        $v['max_zoom'] = (int) $this->keyValue($ctx, 'max-zoom-distance');
        foreach (self::SLIDERS as $f => [$key]) {
            $v[$f] = (int) $this->keyValue($ctx, $key);
        }
        $v['use_cookies'] = (bool) $this->keyValue($ctx, 'use-cookies');
        $lang = $this->doc($ctx, $this->langPath($ctx));
        $v['lang_default'] = $lang !== null && $lang->has('default') ? (string) $lang->get('default') : 'en';
        $v['lang_browser'] = $lang !== null && $lang->has('useBrowserLanguage') ? (bool) $lang->get('useBrowserLanguage') : true;

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $loc = $this->locales($ctx);
        $start = [
            Spec::field('default_to_flat_view', 'toggle', 'Open in flat (2D) view', ['default' => false]),
            Spec::field('start_mode', 'radio', 'Where the map opens', ['default' => $current['start_mode'] ?? 'none', 'options' => ['none' => 'First map, default view', 'map' => 'A specific map', 'exact' => 'An exact view']]),
            Spec::field('start_map', 'select', 'Map', ['options' => $this->mapOptions($ctx), 'visible_if' => Spec::visibleIf('start_mode', ['map']), 'help' => 'Needs BlueMap 5.4+.']),
            Spec::field('start_exact', 'text', 'Exact view', ['max' => 200, 'visible_if' => Spec::visibleIf('start_mode', ['exact']), 'help' => 'Paste the part after the # in the map address.']),
        ];
        if ($loc !== []) {
            $start[] = Spec::field('lang_default', 'select', 'Default language', ['options' => $loc, 'default' => $current['lang_default'] ?? 'en', 'help' => 'Stored in the web folder, so a web app refresh resets it.']);
        }
        if ($this->supports($ctx, 'lang-use-browser-language') && $loc !== []) {
            $start[] = Spec::field('lang_browser', 'toggle', 'Use the visitor\'s browser language', ['default' => true]);
        }
        $q = [
            Spec::field('resolution_default', 'select', 'Default resolution', ['options' => ['0.5' => '0.5 (sharper on small screens, slower)', '1' => '1', '2' => '2'], 'default' => '1']),
            Spec::field('min_zoom', 'int', 'Closest zoom distance', ['min' => 1, 'max' => 1000, 'default' => 5]),
            Spec::field('max_zoom', 'int', 'Farthest zoom distance', ['min' => 100, 'max' => 1000000, 'default' => 100000]),
        ];
        foreach (['hires_min' => ['High-res slider min', 0, 2000, 0], 'hires_default' => ['High-res slider default', 0, 2000, 100], 'hires_max' => ['High-res slider max', 0, 2000, 500],
            'lowres_min' => ['Low-res slider min', 100, 20000, 500], 'lowres_default' => ['Low-res slider default', 100, 20000, 2000], 'lowres_max' => ['Low-res slider max', 100, 20000, 7000]] as $f => [$l, $mn, $mx, $d]) {
            $q[] = Spec::field($f, 'int', $l, ['min' => $mn, 'max' => $mx, 'default' => $d, 'help' => $f === 'hires_min' ? 'How far, in blocks, full 3D detail loads.' : null]);
        }
        $q[] = Spec::field('use_cookies', 'toggle', 'Remember visitor settings in cookies', ['default' => true]);
        if ($this->doc($ctx, $this->configFile($ctx, 'webapp.conf'))?->get('update-settings-file') === false) {
            $q[0]['warning'] = 'update-settings-file is off: BlueMap will not apply these webapp settings.';
        }

        return [Spec::step('start', 'Start view', null, $start), Spec::step('quality', 'Quality & distances', null, $q)];
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        $mode = (string) ($input['start_mode'] ?? 'none');
        if (!in_array($mode, ['none', 'map', 'exact'], true)) {
            self::err($e, 'start_mode', 'Unknown start type.');
        }
        if ($mode === 'map' && ($this->mapById($ctx, (string) ($input['start_map'] ?? '')) === null || !$this->atLeast($ctx, 4))) {
            self::err($e, 'start_map', $this->atLeast($ctx, 4) ? 'Pick one of the maps.' : 'Starting on a map needs BlueMap 5.4+.');
        }
        if ($mode === 'exact') {
            $x = (string) ($input['start_exact'] ?? '');
            if (preg_match(self::EXACT, $x) !== 1) {
                self::err($e, 'start_exact', 'Expected map:x:y:z:distance:rotation:tilt:angle:ortho:view (10 values separated by ":").');
            } elseif ($this->mapById($ctx, explode(':', $x)[0]) === null) {
                self::err($e, 'start_exact', 'That map id does not exist.');
            }
        }
        if (!in_array((string) ($input['resolution_default'] ?? '1'), ['0.5', '1', '2'], true)) {
            self::err($e, 'resolution_default', 'Pick 0.5, 1 or 2.');
        }
        $min = Check::int($input['min_zoom'] ?? null, 1, 1000);
        $max = Check::int($input['max_zoom'] ?? null, 100, 1000000);
        if ($min === null) {
            self::err($e, 'min_zoom', 'Use 1 to 1000.');
        }
        if ($max === null) {
            self::err($e, 'max_zoom', 'Use 100 to 1 000 000.');
        }
        if ($min !== null && $max !== null && $min >= $max) {
            self::err($e, 'max_zoom', 'The farthest distance has to be larger than the closest.');
        }
        $s = [];
        foreach (self::SLIDERS as $f => [, $lo, $hi]) {
            $s[$f] = Check::int($input[$f] ?? null, $lo, $hi);
            if ($s[$f] === null) {
                self::err($e, $f, "Use $lo to $hi.");
            }
        }
        foreach (['hires', 'lowres'] as $g) {
            [$a, $b, $c] = [$s[$g . '_min'], $s[$g . '_default'], $s[$g . '_max']];
            if ($a !== null && $b !== null && $a > $b) {
                self::err($e, $g . '_default', 'Has to be at least the minimum.');
            }
            if ($b !== null && $c !== null && $b > $c) {
                self::err($e, $g . '_max', 'Has to be at least the default.');
            }
        }
        $loc = $this->locales($ctx);
        if (isset($input['lang_default']) && $loc !== [] && !isset($loc[(string) $input['lang_default']])) {
            self::err($e, 'lang_default', 'Pick one of the available languages.');
        }

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $file = $this->configFile($ctx, 'webapp.conf');
        if ($this->doc($ctx, $file) === null) {
            $b->block('webapp.conf can not be read or edited safely.');

            return $b->build();
        }
        if ($b->doc($file)->get('update-settings-file') === false) {
            $b->warn("BlueMap won't apply these webapp settings (update-settings-file is off).");
        }
        $mode = (string) ($input['start_mode'] ?? 'none');
        $want = [
            'default-to-flat-view' => Check::bool($input['default_to_flat_view'] ?? false),
            'resolution-default' => (float) ($input['resolution_default'] ?? 1),
            'min-zoom-distance' => (int) $input['min_zoom'], 'max-zoom-distance' => (int) $input['max_zoom'],
            'use-cookies' => Check::bool($input['use_cookies'] ?? true, true),
        ];
        foreach (self::SLIDERS as $f => [$key]) {
            $want[$key] = (int) $input[$f];
        }
        foreach ($want as $key => $val) {
            $d = $b->doc($file);
            $cur = $d->has($key) ? $d->get($key) : KeyCatalog::KEYS[$key]['default'];
            if (!self::same($cur, $val)) {
                $b->upsert($file, $key, $val, 'webapp.conf · ' . $key);
            }
        }
        $d = $b->doc($file);
        $curStart = $d->has('start-location') ? $d->get('start-location') : null;
        $newStart = $mode === 'map' ? (string) $input['start_map'] : ($mode === 'exact' ? (string) $input['start_exact'] : null);
        if ($newStart === null) {
            if ($d->has('start-location')) {
                $b->commentOut($file, 'start-location', 'removed by Pelican BlueMap', 'webapp.conf · start-location');
            }
        } elseif ($curStart !== $newStart) {
            $b->upsert($file, 'start-location', $newStart, 'webapp.conf · start-location');
        }

        $lp = $this->langPath($ctx);
        if (($ctx['files'][$lp] ?? null) !== null && $this->locales($ctx) !== []) {
            if ($this->doc($ctx, $lp) === null) {
                $b->warn('lang/settings.conf can not be edited safely; language was left alone.');
            } else {
                $ld = $b->doc($lp);
                if (isset($input['lang_default']) && $ld->get('default') !== (string) $input['lang_default']) {
                    $b->upsert($lp, 'default', (string) $input['lang_default'], 'lang/settings.conf · default');
                }
                $ld = $b->doc($lp);
                if ($this->supports($ctx, 'lang-use-browser-language') && array_key_exists('lang_browser', $input)) {
                    $v = Check::bool($input['lang_browser'], true);
                    if ((bool) ($ld->has('useBrowserLanguage') ? $ld->get('useBrowserLanguage') : true) !== $v) {
                        $b->upsert($lp, 'useBrowserLanguage', $v, 'lang/settings.conf · useBrowserLanguage');
                    }
                }
                if ($b->text($lp) !== $ctx['files'][$lp]) {
                    $b->warn('The language is stored in the web folder; a web app refresh resets it.');
                }
            }
        }

        return $b->build();
    }
}
