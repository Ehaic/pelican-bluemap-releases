<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.5 Performance: render speed versus server load. */
final class PerformanceWizard extends BaseWizard
{
    private const KEYS = [
        'threads' => 'render-thread-count', 'player_limit' => 'player-render-limit', 'cooldown' => 'update-cooldown',
        'full_interval' => 'full-update-interval', 'region_check' => 'region-file-check-interval',
    ];

    public function id(): string
    {
        return 'performance';
    }

    protected function title(): string
    {
        return 'Performance';
    }

    protected function description(): string
    {
        return 'Balance render speed against server load: threads, update delay and how often BlueMap re-checks.';
    }

    protected function icon(): string
    {
        return 'tabler-gauge';
    }

    public function files(array $ctx): array
    {
        return [$this->configFile($ctx, 'core.conf'), $this->configFile($ctx, 'plugin.conf')];
    }

    /** clamp(floor(cpu / 100) - 1, 1, 8); unlimited CPU = 8; root admins up to 16. */
    public static function maxThreads(array $ctx): int
    {
        if (!empty($ctx['is_root_admin'])) {
            return 16;
        }
        $cpu = (int) ($ctx['cpu_limit'] ?? 0);

        return $cpu <= 0 ? 8 : max(1, min(8, intdiv($cpu, 100) - 1));
    }

    /** @return array<string, array<string, int>> */
    public function presets(array $ctx): array
    {
        $max = (int) min(self::maxThreads($ctx), 8);

        return [
            'gentle' => ['threads' => 1, 'player_limit' => 1, 'cooldown' => 300, 'full_interval' => 2880, 'region_check' => 15],
            'balanced' => ['threads' => 1, 'player_limit' => -1, 'cooldown' => 60, 'full_interval' => 1440, 'region_check' => 5],
            'fast' => ['threads' => $max, 'player_limit' => -1, 'cooldown' => 30, 'full_interval' => 1440, 'region_check' => 5],
        ];
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $v = [];
        foreach (self::KEYS as $f => $key) {
            $v[$f] = $this->supports($ctx, $key) ? (int) $this->keyValue($ctx, $key) : null;
        }
        $v['threads'] = max(1, (int) ($v['threads'] ?? 1));
        $v['preset'] = 'custom';
        foreach ($this->presets($ctx) as $name => $set) {
            $same = true;
            foreach ($set as $f => $val) {
                if ($v[$f] !== null && $v[$f] !== $val) {
                    $same = false;
                }
            }
            if ($same) {
                $v['preset'] = $name;
                break;
            }
        }

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $max = self::maxThreads($ctx);
        $cpu = (int) ($ctx['cpu_limit'] ?? 0);
        $presetField = Spec::field('preset', 'radio', 'Preset', ['default' => $current['preset'] ?? 'balanced', 'options' => [
            'gentle' => 'Gentle (least load on the game)', 'balanced' => 'Balanced (BlueMap defaults)', 'fast' => 'Fast first render', 'custom' => 'Custom',
        ], 'help' => 'BlueMap already renders only the regions that changed. These settings decide how soon it renders and how often it re-checks everything.', 'presets' => $this->presets($ctx)]);
        $threads = Spec::field('threads', 'int', 'Render threads', ['min' => 1, 'max' => $max, 'default' => 1, 'help' => 'More threads render faster but compete with the game for CPU. Your limit allows up to ' . $max . '.']);
        if ($cpu <= 0 && empty($ctx['is_root_admin'])) {
            $threads['warning'] = 'This server has no CPU limit; BlueMap could compete with the game.';
        }
        $fields = [
            $threads,
            Spec::field('player_limit', 'int', 'Pause while this many players are online', ['min' => -1, 'max' => 500, 'default' => -1, 'help' => '-1 = never pause.']),
        ];
        if ($this->supports($ctx, 'update-cooldown')) {
            $fields[] = Spec::field('cooldown', 'int', 'Re-render delay after a change (seconds)', ['min' => 5, 'max' => 3600, 'default' => 60]);
        }
        $fields[] = Spec::field('full_interval', 'int', 'Full re-check every (minutes)', ['min' => 60, 'max' => 10080, 'default' => 1440]);
        if ($this->supports($ctx, 'region-file-check-interval')) {
            $fields[] = Spec::field('region_check', 'int', 'Region file check every (minutes)', ['min' => 0, 'max' => 1440, 'default' => 5, 'help' => '0 = off.']);
        }

        return [Spec::step('preset', 'Preset', null, [$presetField]), Spec::step('values', 'Details', null, $fields)];
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        $max = self::maxThreads($ctx);
        if (!in_array((string) ($input['preset'] ?? 'custom'), ['gentle', 'balanced', 'fast', 'custom'], true)) {
            self::err($e, 'preset', 'Unknown preset.');
        }
        if (Check::int($input['threads'] ?? null, 1, $max) === null) {
            self::err($e, 'threads', "Use 1 to $max threads.");
        }
        $pl = $input['player_limit'] ?? -1;
        if (Check::int($pl, -1, 500) === null || Check::int($pl, -1, 500) === 0) {
            self::err($e, 'player_limit', 'Use -1 (never pause) or 1 to 500.');
        }
        if ($this->supports($ctx, 'update-cooldown') && Check::int($input['cooldown'] ?? null, 5, 3600) === null) {
            self::err($e, 'cooldown', 'Use 5 to 3600 seconds.');
        }
        if (Check::int($input['full_interval'] ?? null, 60, 10080) === null) {
            self::err($e, 'full_interval', 'Use 60 to 10080 minutes.');
        }
        if ($this->supports($ctx, 'region-file-check-interval') && Check::int($input['region_check'] ?? null, 0, 1440) === null) {
            self::err($e, 'region_check', 'Use 0 to 1440 minutes.');
        }

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $max = self::maxThreads($ctx);
        $preset = (string) ($input['preset'] ?? 'custom');
        $vals = $preset !== 'custom' && isset($this->presets($ctx)[$preset]) && !isset($input['threads']) ? $this->presets($ctx)[$preset] : [];
        foreach (self::KEYS as $f => $key) {
            if (isset($input[$f]) && !Check::blank($input[$f])) {
                $vals[$f] = (int) $input[$f];
            }
        }
        if ($vals === [] && isset($this->presets($ctx)[$preset])) {
            $vals = $this->presets($ctx)[$preset];
        }
        if (($vals['threads'] ?? 1) > $max) {
            $b->block("Render threads are limited to $max on this server.");
        }
        if ((int) ($ctx['cpu_limit'] ?? 0) <= 0 && empty($ctx['is_root_admin'])) {
            $b->warn('No CPU limit on this server; BlueMap could compete with the game.');
        }

        foreach (self::KEYS as $f => $key) {
            if (!isset($vals[$f]) || !$this->supports($ctx, $key)) {
                continue;
            }
            $file = $this->pathOf($ctx, $key);
            if ($file === null || $this->doc($ctx, $file) === null) {
                $b->block(($file === null ? $key : basename($file)) . ' can not be read or edited safely.');
                continue;
            }
            $d = $b->doc($file);
            $cur = $d->has($key) ? $d->get($key) : KeyCatalog::KEYS[$key]['default'];
            if (!self::same($cur, $vals[$f])) {
                $b->upsert($file, $key, $vals[$f], basename($file) . ' · ' . $key);
            }
        }

        // Dead copies: keys of this version that still sit in the other file.
        $files = [];
        foreach ($this->files($ctx) as $p) {
            $files[$p] = $b->text($p);
        }
        foreach (KeyCatalog::deadCopies($ctx['version'], $files) as $dead) {
            if (!in_array($dead['key'], self::KEYS, true)) {
                continue;
            }
            $k = KeyCatalog::KEYS[$dead['key']];
            $d = $b->doc($dead['file']);
            $to = basename((string) $this->pathOf($ctx, $dead['key']));
            $b->commentOut($dead['file'], $k['path'], 'moved to ' . $to . ' by Pelican BlueMap: ' . $k['path'] . ': ' . $d->raw($k['path']), basename($dead['file']) . ' · ' . $k['path'] . ' (old copy)');
        }

        return $b->build();
    }
}
