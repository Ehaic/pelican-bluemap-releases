<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.3 Caves & detail: one collapsed row per map. Re-render is queued, never automatic. */
final class DetailWizard extends BaseWizard
{
    private const CAVES = [
        'hide' => [55, 10000],
        'hide_deep' => [55, -5],
        'show' => [-10000, 10000],
    ];
    private const VIEWS = ['enable_hires' => 'enable-hires', 'enable_perspective' => 'enable-perspective-view', 'enable_flat' => 'enable-flat-view', 'enable_free' => 'enable-free-flight-view'];
    private const DETAIL = [
        'full' => ['enable_hires' => true, 'enable_perspective' => true, 'enable_flat' => true, 'enable_free' => true],
        'light' => ['enable_hires' => false, 'enable_perspective' => false, 'enable_flat' => true, 'enable_free' => false],
    ];

    public function id(): string
    {
        return 'detail';
    }

    protected function title(): string
    {
        return 'Caves & detail';
    }

    protected function description(): string
    {
        return 'Hide caves underground and trade 3D detail against render time and database size.';
    }

    protected function icon(): string
    {
        return 'tabler-mountain';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        return $this->enabledMaps($ctx) === [] ? 'No enabled map exists yet.' : null;
    }

    public function files(array $ctx): array
    {
        return array_column($this->maps($ctx), 'file');
    }

    /** One row per enabled map; with a map id, just that map's own values (flat). */
    public function current(array $ctx, ?string $mapId): array
    {
        return $mapId === null ? ['maps' => $this->mapRows($ctx)] : $this->currentFor($ctx, $mapId);
    }

    protected function currentFor(array $ctx, string $mapId): array
    {
        $m = $this->pickMap($ctx, $mapId);
        $id = $m['id'] ?? null;
        $y = (int) $this->keyValue($ctx, 'remove-caves-below-y', $id);
        $o = (int) $this->keyValue($ctx, 'cave-detection-ocean-floor', $id);
        $cp = 'custom';
        foreach (self::CAVES as $name => [$cy, $co]) {
            if ($y === $cy && $o === $co) {
                $cp = $name;
            }
        }
        $v = [
            'map' => $id, 'caves_preset' => $cp, 'cave_y' => $y, 'ocean_floor' => $o,
            'block_light' => (bool) $this->keyValue($ctx, 'cave-detection-uses-block-light', $id),
            'detail_preset' => 'full',
        ];
        if ($this->atLeast($ctx, 5)) {
            $views = [];
            foreach (self::VIEWS as $f => $key) {
                $views[$f] = (bool) $this->keyValue($ctx, $key, $id);
            }
            $v += $views;
            $v['detail_preset'] = 'custom';
            foreach (self::DETAIL as $name => $set) {
                if ($set === $views) {
                    $v['detail_preset'] = $name;
                }
            }
        }

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $children = [
            Spec::mapIdField(),
            Spec::field('dimension', 'text', 'Dimension', ['disabled_reason' => 'Read only']),
            Spec::field('caves_preset', 'radio', 'Caves', ['default' => 'hide', 'options' => [
                'hide' => 'Hide caves', 'hide_deep' => 'Hide caves, also under oceans and mountains', 'show' => 'Show everything', 'custom' => 'Custom',
            ], 'help' => 'Underground areas below the limit are cut away, so the map shows the surface. Needs a re-render.']),
            Spec::field('cave_y', 'int', 'Hide below Y', ['min' => -10000, 'max' => 10000, 'default' => 55, 'visible_if' => Spec::visibleIf('caves_preset', ['custom'])]),
            Spec::field('ocean_floor', 'int', 'Ocean floor offset', ['min' => -10000, 'max' => 10000, 'default' => 10000, 'visible_if' => Spec::visibleIf('caves_preset', ['custom']), 'help' => '10000 turns the ocean/mountain rule off.']),
            Spec::field('block_light', 'toggle', 'Torch-lit caves count as caves', ['default' => false]),
        ];
        if ($this->atLeast($ctx, 5)) {
            $vi = Spec::visibleIf('detail_preset', ['custom']);
            $children[] = Spec::field('detail_preset', 'radio', 'Detail', ['default' => 'full', 'options' => ['full' => 'Full 3D', 'light' => 'Lightweight (flat view only)', 'custom' => 'Custom'],
                'help' => 'Lightweight renders much faster and uses a smaller database, but has no 3D models when zoomed in.']);
            $children[] = Spec::field('enable_hires', 'toggle', 'High-resolution tiles', ['default' => true, 'visible_if' => $vi]);
            $children[] = Spec::field('enable_perspective', 'toggle', 'Perspective view', ['default' => true, 'visible_if' => $vi]);
            $children[] = Spec::field('enable_flat', 'toggle', 'Flat view', ['default' => true, 'visible_if' => $vi]);
            $children[] = Spec::field('enable_free', 'toggle', 'Free-flight view', ['default' => true, 'visible_if' => $vi]);
        }
        $rows = Spec::perMap('maps', 'Maps', $children, ['max_items' => count($this->enabledMaps($ctx)),
            'help' => 'One row per map, all collapsed. Open a map to change its caves or detail; maps you leave alone are not touched.']);

        return [Spec::step('maps', 'Caves & detail', null, [$rows])];
    }

    public function validate(array $ctx, array $input): array
    {
        return $this->validateMaps($ctx, $input);
    }

    protected function validateOne(array $ctx, array $input): array
    {
        $e = [];
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled']) {
            self::err($e, 'map', 'Pick one of the enabled maps.');
        }
        $cp = (string) ($input['caves_preset'] ?? 'hide');
        if (!in_array($cp, ['hide', 'hide_deep', 'show', 'custom'], true)) {
            self::err($e, 'caves_preset', 'Unknown caves preset.');
        }
        if ($cp === 'custom') {
            if (Check::int($input['cave_y'] ?? null, -10000, 10000) === null) {
                self::err($e, 'cave_y', 'Use a whole number from -10000 to 10000.');
            }
            if (Check::int($input['ocean_floor'] ?? null, -10000, 10000) === null) {
                self::err($e, 'ocean_floor', 'Use a whole number from -10000 to 10000.');
            }
        }
        if ($this->atLeast($ctx, 5)) {
            $dp = (string) ($input['detail_preset'] ?? 'full');
            if (!in_array($dp, ['full', 'light', 'custom'], true)) {
                self::err($e, 'detail_preset', 'Unknown detail preset.');
            }
            if ($dp === 'custom' && !Check::bool($input['enable_perspective'] ?? true, true) && !Check::bool($input['enable_flat'] ?? true, true) && !Check::bool($input['enable_free'] ?? true, true)) {
                self::err($e, 'enable_flat', 'Keep at least one view on.');
            }
        }

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        return $this->planMaps($ctx, $input, $acks);
    }

    protected function planOne(PlanBuilder $b, array $ctx, array $input, array $acks): void
    {
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled'] || $this->doc($ctx, $m['file']) === null) {
            $b->block('Pick an enabled map whose file can be edited.');

            return;
        }
        $file = $m['file'];
        $label = fn (string $k) => basename($file) . ' · ' . $k;
        $cp = (string) ($input['caves_preset'] ?? 'hide');
        [$y, $o] = $cp === 'custom' ? [(int) $input['cave_y'], (int) $input['ocean_floor']] : self::CAVES[$cp];
        $want = [
            'remove-caves-below-y' => $y, 'cave-detection-ocean-floor' => $o,
            'cave-detection-uses-block-light' => Check::bool($input['block_light'] ?? false),
        ];
        $hiresOff = false;
        if ($this->atLeast($ctx, 5)) {
            $dp = (string) ($input['detail_preset'] ?? 'full');
            $set = $dp === 'custom' ? [] : self::DETAIL[$dp];
            if ($dp === 'custom') {
                foreach (array_keys(self::VIEWS) as $f) {
                    $set[$f] = Check::bool($input[$f] ?? true, true);
                }
            }
            foreach (self::VIEWS as $f => $key) {
                $want[$key] = $set[$f];
            }
            $hiresOff = !$set['enable_hires'];
        }

        $changed = [];
        foreach ($want as $key => $val) {
            $cur = $this->doc($ctx, $file)->has($key) ? $this->doc($ctx, $file)->get($key) : \Ehaic\PelicanBlueMap\Wizards\KeyCatalog::KEYS[$key]['default'];
            if (!self::same($cur, $val) && $cur !== $val) {
                $b->upsert($file, $key, $val, $label($key));
                $changed[] = $key;
            }
        }
        if ($changed !== []) {
            $onlyHiresOff = $changed === ['enable-hires'] && $hiresOff;
            $b->post([
                'action' => 'purge', 'map' => $m['id'], 'required' => !$onlyHiresOff,
                'reason' => $onlyHiresOff
                    ? 'Optional: delete the old high-resolution tiles of ' . $m['id'] . ' (they just stop updating otherwise).'
                    : 'Cave and detail changes need a purge and full re-render of ' . $m['id'] . '.',
            ]);
            $b->warn('Purging deletes and re-renders ' . $m['id'] . '; large worlds take hours. It is queued, not started automatically.');
        }
    }
}
