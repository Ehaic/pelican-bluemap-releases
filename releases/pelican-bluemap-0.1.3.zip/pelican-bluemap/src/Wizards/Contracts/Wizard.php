<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Contracts;

/**
 * One configuration wizard. Every method is pure given $ctx (a WizardContext, docs/WIZARDS.md 7.2): the files
 * the wizard needs are already loaded into $ctx['files'].
 */
interface Wizard
{
    public function id(): string;

    /** @return array<string, mixed> WizardMeta */
    public function meta(array $ctx): array;

    /** @return list<string> paths this wizard needs in $ctx['files'] (a trailing "/" = directory existence probe) */
    public function files(array $ctx): array;

    /** @return array<string, mixed> values for the form prefill, read from the files */
    public function current(array $ctx, ?string $mapId): array;

    /** @return list<array<string, mixed>> StepSpec list */
    public function steps(array $ctx, array $current): array;

    /** @return array<string, string> field => message, [] = ok */
    public function validate(array $ctx, array $input): array;

    /**
     * @param list<string> $acks
     * @return array<string, mixed> ChangePlan
     */
    public function plan(array $ctx, array $input, array $acks): array;
}
