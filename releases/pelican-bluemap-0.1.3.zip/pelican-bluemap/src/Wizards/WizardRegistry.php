<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Wizards\Contracts\Wizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\AreaWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\DetailWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\MapsWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\MarkersWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\PerformanceWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\PlayersWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\RenderWizard;
use Ehaic\PelicanBlueMap\Wizards\Definitions\WebappWizard;

final class WizardRegistry
{
    /** @var array<string, Wizard>|null */
    private ?array $all = null;

    /** @return array<string, Wizard> keyed by id, fixed order */
    public function all(): array
    {
        if ($this->all === null) {
            $this->all = [];
            foreach ([new MapsWizard(), new AreaWizard(), new DetailWizard(), new PlayersWizard(), new PerformanceWizard(), new WebappWizard(), new MarkersWizard(), new RenderWizard()] as $w) {
                $this->all[$w->id()] = $w;
            }
        }

        return $this->all;
    }

    public function get(string $id): Wizard
    {
        return $this->all()[$id] ?? throw new BlueMapException('Unknown wizard.');
    }
}
