<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use App\Models\Server;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Support\Facades\Cache;

/** Render progress hints: hires tiles in MariaDB versus an estimate from the region files. Never throws. */
class RenderProgress
{
    private ?Server $server = null;

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;

        return $new;
    }

    /** Pure: regions x (512 / tile size)^2. */
    public static function estimate(int $regionFiles, int $hiresTileSize = 32): int
    {
        $size = max(1, $hiresTileSize);

        return max(0, $regionFiles) * (int) (intdiv(512, $size) ** 2);
    }

    /** Pure: percent shown; capped at 99 until the count stopped growing for two polls. */
    public static function percent(?int $tiles, ?int $estimate, bool $stable): ?int
    {
        if ($tiles === null || $estimate === null || $estimate <= 0) {
            return null;
        }
        $p = (int) floor($tiles * 100 / $estimate);

        return $stable ? min(100, $p) : min(99, $p);
    }

    /** @param list<array<string, mixed>> $maps MapInfo @return array<string, mixed> RenderProgressInfo */
    public function snapshot(Installation $i, array $maps): array
    {
        $now = gmdate('c');
        $out = ['available' => false, 'error' => null, 'maps' => [], 'paused' => null, 'checked_at' => $now];
        try {
            $db = $i->database;
            if ($db === null) {
                $out['error'] = 'BlueMap has no database set up yet.';

                return $out;
            }
            $tiles = $this->tileCounts($db);
            $files = app(ServerFiles::class)->forServer($this->server ?? throw new \LogicException('Call forServer() first.'));
            $sid = (int) $i->server_id;
            foreach ($maps as $m) {
                if (!$m['enabled']) {
                    continue;
                }
                $id = (string) $m['id'];
                $count = $tiles[$id] ?? 0;
                $est = Cache::remember("pelican-bluemap:regions:$sid:$id", 600, fn () => $this->regionEstimate($files, (string) ($m['world'] ?? ''), (string) ($m['dimension'] ?? '')));
                $key = "pelican-bluemap:progress:$sid:$id";
                $prev = Cache::get($key);
                $stableCount = is_array($prev) && ($prev['tiles'] ?? null) === $count ? (int) ($prev['stable'] ?? 0) + 1 : 0;
                $growing = is_array($prev) ? $count > (int) ($prev['tiles'] ?? 0) : null;
                Cache::put($key, ['tiles' => $count, 'stable' => $stableCount], 3600);
                $out['maps'][] = ['id' => $id, 'tiles' => $count, 'estimate' => $est > 0 ? $est : null, 'percent' => self::percent($count, $est > 0 ? $est : null, $stableCount >= 2), 'growing' => $growing];
            }
            $out['available'] = true;
            $data = 'bluemap';
            $core = $files->read(rtrim((string) $i->config_dir, '/') . '/core.conf', 1024 * 1024);
            if ($core !== null) {
                $dv = \Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument::parse($core)->get('data');
                if (is_string($dv) && \Ehaic\PelicanBlueMap\Wizards\Definitions\WebappWizard::safePath($dv)) {
                    $data = rtrim($dv, '/');
                }
            }
            $state = $files->read($data . '/pluginState.json', 64 * 1024);
            $d = $state === null ? null : json_decode($state, true);
            if (is_array($d) && array_key_exists('render-threads-enabled', $d)) {
                $out['paused'] = $d['render-threads-enabled'] === false;
            }
        } catch (\Throwable $e) {
            Trace::warning('progress.failed', ['cause' => get_class($e)]);
            $out['error'] = 'Could not read the render progress (the database may be unreachable).';
        }

        return $out;
    }

    /** @return array<string, int> map id => hires tile count */
    private function tileCounts(\App\Models\Database $db): array
    {
        $host = $db->host;
        $pdo = new \PDO(
            'mysql:host=' . $host->host . ';port=' . (int) $host->port . ';dbname=' . $db->database . ';charset=utf8mb4',
            (string) $db->username,
            (string) $db->password,
            [\PDO::ATTR_TIMEOUT => 3, \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION],
        );
        $rows = $pdo->query('SELECT m.map_id AS map_id, COUNT(*) AS n FROM bluemap_grid_storage_data d JOIN bluemap_map m ON m.id = d.map JOIN bluemap_grid_storage s ON s.id = d.storage WHERE s.`key` LIKE \'%hires\' GROUP BY m.map_id')?->fetchAll(\PDO::FETCH_ASSOC) ?: [];
        $out = [];
        foreach ($rows as $r) {
            $out[(string) $r['map_id']] = (int) $r['n'];
        }

        return $out;
    }

    private function regionEstimate(ServerFiles $files, string $world, string $dimension): int
    {
        if ($world === '' || !preg_match('#^[A-Za-z0-9 _./-]{1,128}$#', $world) || str_contains($world, '..')) {
            return 0;
        }
        $dim = str_starts_with($dimension, 'minecraft:') ? substr($dimension, 10) : $dimension;
        $dirs = match ($dim) {
            'the_nether' => [$world . '/DIM-1/region', $world . '/dimensions/minecraft/the_nether/region'],
            'the_end' => [$world . '/DIM1/region', $world . '/dimensions/minecraft/the_end/region'],
            default => [$world . '/region', $world . '/dimensions/minecraft/overworld/region'],
        };
        foreach ($dirs as $d) {
            $n = 0;
            foreach ($files->list($d) as $e) {
                if ($e['is_file'] && str_ends_with($e['name'], '.mca')) {
                    $n++;
                }
            }
            if ($n > 0) {
                return self::estimate($n);
            }
        }

        return 0;
    }
}
