<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use Ehaic\PelicanBlueMap\Models\Installation;

/**
 * The two JSON columns added by migration 002. Installation is not edited: the columns are read as raw
 * attributes and written with forceFill() + save(). The array logic is static and pure (unit tested).
 */
final class WizardStateStore
{
    public const MAX_PENDING = 50;

    /** @return array<string, array<string, mixed>> WizardState */
    public function get(Installation $i): array
    {
        return self::decode($i->getAttribute('wizard_state'));
    }

    public function put(Installation $i, string $wizard, array $entry): void
    {
        $i->forceFill(['wizard_state' => json_encode(self::withEntry($this->get($i), $wizard, $entry), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)])->save();
    }

    /** @return list<array<string, mixed>> */
    public function pending(Installation $i): array
    {
        return self::decodePending($i->getAttribute('wizard_pending'));
    }

    /** @param list<array<string, mixed>> $actions */
    public function addPending(Installation $i, array $actions): void
    {
        $i->forceFill(['wizard_pending' => json_encode(self::mergePending(self::decodePending($i->getAttribute('wizard_pending')), $actions), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)])->save();
    }

    /** @return ?array<string, mixed> the removed action */
    public function removePending(Installation $i, string $id): ?array
    {
        [$list, $removed] = self::withoutPending(self::decodePending($i->getAttribute('wizard_pending')), $id);
        if ($removed !== null) {
            $i->forceFill(['wizard_pending' => json_encode($list, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)])->save();
        }

        return $removed;
    }

    // ------------------------------------------------------------------ pure

    /** @return array<string, array<string, mixed>> */
    public static function decode(mixed $raw): array
    {
        $a = is_array($raw) ? $raw : (is_string($raw) && $raw !== '' ? json_decode($raw, true) : []);

        return is_array($a) ? $a : [];
    }

    /** @return list<array<string, mixed>> */
    public static function decodePending(mixed $raw): array
    {
        $a = self::decode($raw);

        return array_values(array_filter($a, fn ($x) => is_array($x) && isset($x['id'], $x['action'])));
    }

    /** @return array<string, array<string, mixed>> */
    public static function withEntry(array $state, string $wizard, array $entry): array
    {
        $state[$wizard] = $entry;

        return $state;
    }

    /**
     * An action for the same map + action (+ storage) replaces the older entry. New ones get a ULID.
     *
     * @param list<array<string, mixed>> $existing
     * @param list<array<string, mixed>> $new
     * @return list<array<string, mixed>>
     */
    public static function mergePending(array $existing, array $new): array
    {
        foreach ($new as $a) {
            $existing = array_values(array_filter($existing, fn ($e) => !($e['action'] === $a['action'] && ($e['map'] ?? null) === ($a['map'] ?? null) && ($e['storage'] ?? null) === ($a['storage'] ?? null))));
            $a['id'] = ($a['id'] ?? '') !== '' ? $a['id'] : self::ulid();
            $existing[] = $a;
        }

        return array_slice($existing, -self::MAX_PENDING);
    }

    /** @return array{0: list<array<string, mixed>>, 1: ?array<string, mixed>} */
    public static function withoutPending(array $list, string $id): array
    {
        $removed = null;
        $out = [];
        foreach ($list as $a) {
            if ($a['id'] === $id) {
                $removed = $a;
            } else {
                $out[] = $a;
            }
        }

        return [$out, $removed];
    }

    public static function ulid(): string
    {
        $alphabet = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';
        $t = (int) floor(microtime(true) * 1000);
        $s = '';
        for ($i = 0; $i < 10; $i++) {
            $s = $alphabet[$t % 32] . $s;
            $t = intdiv($t, 32);
        }
        $r = random_bytes(10);
        $bits = '';
        foreach (str_split($r) as $c) {
            $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
        }
        foreach (str_split($bits, 5) as $chunk) {
            $s .= $alphabet[bindec($chunk)];
        }

        return $s;
    }
}
