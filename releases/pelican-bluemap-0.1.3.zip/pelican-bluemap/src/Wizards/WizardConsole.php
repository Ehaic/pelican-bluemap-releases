<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Models\User;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Services\RenderControl;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Services\ServerGuard;
use Ehaic\PelicanBlueMap\Support\Trace;

/** The render wizard's console whitelist. Every command is a fixed string plus whitelist-validated ids. */
class WizardConsole
{
    public const COMMANDS = [
        'update' => 'bluemap update', 'fix_edges' => 'bluemap fix-edges', 'purge' => 'bluemap purge',
        'force_update' => 'bluemap force-update', 'freeze' => 'bluemap freeze', 'unfreeze' => 'bluemap unfreeze',
        'storage_delete' => 'bluemap storages', 'resume' => 'bluemap start',
    ];

    private const ID = '/^[A-Za-z0-9_-]{1,64}$/D';

    private ?Server $server = null;
    private ?User $user = null;

    public function forServer(Server $server, ?User $user): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->user = $user;

        return $new;
    }

    /**
     * Pure: the console lines for an action.
     *
     * @param list<string> $mapIds enabled map ids (for per-map update commands)
     * @param list<string> $allMapIds every map id of the server
     * @param list<string> $storageIds ids of storages/*.conf
     * @return list<string>
     * @throws BlueMapException
     */
    public static function commands(string $action, ?string $mapId, ?string $storage, array $mapIds, array $allMapIds, array $storageIds): array
    {
        if (!isset(self::COMMANDS[$action])) {
            throw new BlueMapException('Unknown action.');
        }
        $base = self::COMMANDS[$action];
        if ($mapId !== null && (preg_match(self::ID, $mapId) !== 1 || !in_array($mapId, $allMapIds, true))) {
            throw new BlueMapException('That map does not exist on this server.');
        }

        switch ($action) {
            case 'resume':
                return [$base];
            case 'update':
            case 'force_update':
                // From the console BlueMap needs a target: a bare "bluemap update" says "Not enough arguments!".
                $cmds = $mapId !== null ? [$base . ' ' . $mapId] : RenderControl::perMapCommands($base, $mapIds);
                if ($cmds === []) {
                    throw new BlueMapException('BlueMap has no maps yet. Start the server once and wait for BlueMap to load.');
                }

                return $cmds;
            case 'storage_delete':
                if ($mapId === null) {
                    throw new BlueMapException('Pick a map.');
                }
                if ($storage === null || preg_match(self::ID, $storage) !== 1 || !in_array($storage, $storageIds, true)) {
                    throw new BlueMapException('That storage does not exist on this server.');
                }

                return [$base . ' ' . $storage . ' delete ' . $mapId];
            default:
                if ($mapId === null) {
                    throw new BlueMapException('Pick a map.');
                }

                return [$base . ' ' . $mapId];
        }
    }

    /** @return array{ok: bool, status: string, step: ?string, message: string, next: ?string} OperationResult */
    public function send(string $action, ?string $mapId, ?string $storage): array
    {
        $server = $this->server ?? throw new \LogicException('Call forServer() first.');
        Trace::begin((int) $server->id);
        $status = 'none';
        try {
            $guard = app(ServerGuard::class)->forServer($server);
            $guard->assertCan($this->user, SubuserPermission::ControlConsole);
            $row = Installation::forServer($server) ?? throw new BlueMapException('BlueMap is not installed on this server.');
            $status = (string) $row->status;

            $edit = app(ConfigEditService::class)->forServer($server);
            $maps = $edit->listMaps($row);
            $storageIds = [];
            foreach (app(ServerFiles::class)->forServer($server)->list(rtrim((string) $row->config_dir, '/') . '/storages') as $e) {
                if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                    $storageIds[] = substr($e['name'], 0, -5);
                }
            }
            $cmds = self::commands(
                $action, $mapId, $storage,
                array_column(array_filter($maps, fn ($m) => $m['enabled']), 'id'), array_column($maps, 'id'), $storageIds,
            );

            if ($action === 'storage_delete') {
                // A pending action can outlive the change that queued it: never delete the data of a map that is enabled again.
                foreach ($maps as $m) {
                    if ($m['id'] === $mapId && ($m['enabled'] || (string) ($m['storage'] ?? '') !== (string) $storage)) {
                        throw new BlueMapException('Only the data of a disabled map can be deleted, from the storage it was rendered to.');
                    }
                }
            }
            if ($guard->state() !== 'running') {
                throw new BlueMapException('The server must be running to send BlueMap commands.');
            }
            foreach ($cmds as $c) {
                $server->send($c);
            }
            Trace::info('wizard.console', ['action' => $action, 'map' => $mapId, 'storage' => $storage]);

            return ['ok' => true, 'status' => $status, 'step' => null, 'message' => 'Sent. See the console for output.', 'next' => null];
        } catch (BlueMapException $e) {
            return ['ok' => false, 'status' => $status, 'step' => null, 'message' => $e->getMessage(), 'next' => null];
        } catch (\Throwable $e) {
            report($e);
            Trace::error('wizard.console_failed', ['action' => $action, 'cause' => get_class($e)]);

            return ['ok' => false, 'status' => $status, 'step' => null, 'message' => 'Could not send the command to the server (it may be offline).', 'next' => null];
        } finally {
            Trace::end();
        }
    }
}
