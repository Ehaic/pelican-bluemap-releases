<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

/** Pure: the BlueMap release a managed install runs ("5.12-mc1.20-6-forge" -> 5.12). Wizards need major 5. */
final class BlueMapVersion
{
    /** @return array{raw: string, major: int, minor: int}|null null when unknown or not a 5.x release */
    public static function parse(?string $versionNumber): ?array
    {
        if ($versionNumber === null || preg_match('/^(\d+)\.(\d+)/', trim($versionNumber), $m) !== 1) {
            return null;
        }
        if ((int) $m[1] !== 5) {
            return null;
        }

        return ['raw' => $versionNumber, 'major' => 5, 'minor' => (int) $m[2]];
    }

    /** @param array{raw: string, major: int, minor: int} $v */
    public static function atLeast(array $v, int $minor): bool
    {
        return $v['minor'] >= $minor;
    }
}
