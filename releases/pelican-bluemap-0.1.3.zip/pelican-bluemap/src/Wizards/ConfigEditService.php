<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use App\Models\Server;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Services\ServerGuard;
use Ehaic\PelicanBlueMap\Support\Trace;
use Ehaic\PelicanBlueMap\Wizards\Definitions\WebappWizard;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconValue;

/**
 * Reads the files a wizard needs and applies a ChangePlan as one transaction (docs/WIZARDS.md 5.2): backup, write
 * each file verified, semantic re-check, restore everything on any failure. The caller holds the server lock and
 * has checked permissions and the plan hash.
 */
class ConfigEditService
{
    public const BACKUP_ROOT = '.pelican-bluemap/wizard-backups';
    public const KEEP = 10;
    public const MAX_FILE = 1048576;

    private ?Server $server = null;

    public function __construct(private ?ServerFiles $files = null, private ?ServerGuard $guard = null)
    {
    }

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->files = ($this->files ?? app(ServerFiles::class))->forServer($server);
        $new->guard = ($this->guard ?? app(ServerGuard::class))->forServer($server);

        return $new;
    }

    /** Same service with cached file reads: for the wizard's read side only (spec, catalog, review); apply never uses it. */
    public function withReadCache(): static
    {
        $new = clone $this;
        $new->files = $this->files()->withReadCache();

        return $new;
    }

    // ------------------------------------------------------------------ context

    /**
     * WizardContext. is_root_admin / server_running / state are filled in by WizardService.
     *
     * @param list<string> $paths a trailing "/" asks for a directory probe (value '' = exists, null = missing)
     * @return array<string, mixed>
     */
    public function loadContext(Installation $i, array $paths): array
    {
        $files = $this->files();
        $version = BlueMapVersion::parse($i->bluemap_version_number);
        $config = rtrim((string) $i->config_dir, '/');

        $core = $this->readText($config . '/core.conf');
        $webapp = $this->readText($config . '/webapp.conf');
        $data = $this->pathKey($core, 'data', 'bluemap');
        $webroot = $this->pathKey($webapp, 'webroot', 'bluemap/web');

        $props = $files->read('server.properties', 256 * 1024);
        $level = 'world';
        if ($props !== null && preg_match('/^level-name=(.*)$/m', $props, $m) === 1 && preg_match('/^[A-Za-z0-9 _.-]{1,64}$/', trim($m[1])) === 1) {
            $level = trim($m[1]);
        }

        $ctx = [
            'server_id' => (int) $i->server_id, 'loader' => (string) $i->loader, 'config_dir' => $config, 'data_dir' => $data, 'webroot' => $webroot,
            'version' => $version ?? ['raw' => (string) $i->bluemap_version_number, 'major' => 0, 'minor' => 0],
            'maps' => $this->listMaps($i), 'level_name' => $level,
            'cpu_limit' => (int) ($this->server?->cpu ?? 0), 'is_root_admin' => false, 'server_running' => false,
            'files' => [], 'state' => null,
        ];

        return $this->withFiles($ctx, $paths);
    }

    /**
     * @param array<string, mixed> $ctx
     * @param list<string> $paths
     * @return array<string, mixed>
     */
    public function withFiles(array $ctx, array $paths): array
    {
        $files = $this->files();
        foreach (array_values(array_unique($paths)) as $p) {
            if (array_key_exists($p, $ctx['files'])) {
                continue;
            }
            if (str_ends_with($p, '/')) {
                $ctx['files'][$p] = $files->exists($p) ? '' : null;
                continue;
            }
            $ctx['files'][$p] = $this->readText($p);
        }

        return $ctx;
    }

    /** @return list<array<string, mixed>> MapInfo for every maps/*.conf and *.conf.disabled */
    public function listMaps(Installation $i): array
    {
        $dir = rtrim((string) $i->config_dir, '/') . '/maps';
        $maps = [];
        $seen = [];
        $entries = $this->files()->list($dir);
        usort($entries, fn ($a, $b) => strcmp($a['name'], $b['name']));
        foreach ($entries as $e) {
            if (!$e['is_file']) {
                continue;
            }
            $enabled = str_ends_with($e['name'], '.conf');
            if (!$enabled && !str_ends_with($e['name'], '.conf.disabled')) {
                continue;
            }
            $id = substr($e['name'], 0, $enabled ? -5 : -14);
            if ($id === '' || isset($seen[$id]) || preg_match('/^[A-Za-z0-9_-]{1,64}$/D', $id) !== 1) {
                continue;
            }
            $seen[$id] = true;
            $text = $e['size'] <= self::MAX_FILE ? $this->files()->read($dir . '/' . $e['name'], self::MAX_FILE) : null;
            $info = ['id' => $id, 'file' => $dir . '/' . $e['name'], 'enabled' => $enabled, 'world' => null, 'dimension' => null, 'name' => null, 'storage' => null];
            if ($text !== null) {
                try {
                    $d = HoconDocument::parse($text);
                    foreach (['world', 'dimension', 'name', 'storage'] as $k) {
                        $v = $d->get($k);
                        $info[$k] = is_string($v) ? $v : null;
                    }
                } catch (\Throwable) {
                    // unreadable file: listed with no details; wizards refuse to edit it
                }
            }
            $maps[] = $info;
        }

        return $maps;
    }

    private function pathKey(?string $text, string $key, string $default): string
    {
        if ($text === null) {
            return $default;
        }
        try {
            $v = HoconDocument::parse($text)->get($key);
        } catch (\Throwable) {
            return '';
        }
        if ($v === null) {
            return $default;
        }

        return is_string($v) && WebappWizard::safePath($v) ? rtrim($v, '/') : '';
    }

    private function readText(string $path): ?string
    {
        $t = $this->files()->read($path, self::MAX_FILE);
        if ($t === null && $this->files()->exists($path)) {
            throw new BlueMapException(basename($path) . ' is larger than 1 MiB or can not be read, so the wizard will not touch it.');
        }

        return $t;
    }

    // ------------------------------------------------------------------ apply

    /**
     * @param array<string, mixed> $plan ChangePlan
     * @return array<string, mixed> WizardResult
     */
    public function apply(Installation $i, array $plan): array
    {
        return $this->applyPlan($plan);
    }

    /** Test seam: the same service over in-memory backends. */
    public function withBackends(ServerFiles $files, ServerGuard $guard): static
    {
        $new = clone $this;
        $new->files = $files;
        $new->guard = $guard;

        return $new;
    }

    /**
     * @param array<string, mixed> $plan ChangePlan
     * @return array<string, mixed> WizardResult
     */
    public function applyPlan(array $plan): array
    {
        $wizard = (string) $plan['wizard'];
        $files = $this->files();
        $guard = $this->guard();
        $written = [];
        $log = [];          // restore log, in order
        $backup = null;

        try {
            $guard->assertStopped();
            if (($plan['blockers'] ?? []) !== []) {
                throw new BlueMapException('This change has blockers: ' . implode(' ', $plan['blockers']));
            }
            if (($plan['files'] ?? []) === []) {
                return $this->result(true, 'Nothing to change.', $wizard, null, [], false, $plan);
            }
            if (preg_match('/^[a-z][a-z-]{0,30}$/D', $wizard) !== 1) {
                throw new BlueMapException('Unknown wizard.');
            }
            foreach (array_keys($plan['files']) as $p) {
                self::assertPath((string) $p);
            }

            // The files must still be exactly what the plan started from.
            foreach ($plan['files'] as $path => $c) {
                $now = $files->read($path, self::MAX_FILE);
                if ($now !== $c['before']) {
                    throw new BlueMapException('Files changed since you reviewed; review again.');
                }
            }

            // 3. Backup of every existing target file.
            $stamp = gmdate('Ymd-His') . '-' . $wizard;
            $backup = self::BACKUP_ROOT . '/' . $stamp;
            $files->ensureDir($backup);
            foreach ($plan['files'] as $path => $c) {
                if ($c['before'] !== null) {
                    $dest = $backup . '/' . $path;
                    $files->ensureDir(dirname($dest));
                    $files->writeVerified($dest, (string) $c['before']);
                }
            }
            $this->pruneBackups();

            // 4. Renames first (in plan order), then the content writes.
            $renamed = [];
            foreach ($plan['ops'] as $op) {
                if ($op['op'] !== 'rename') {
                    continue;
                }
                $guard->assertStopped();
                self::assertPath((string) $op['file']);
                self::assertPath((string) $op['to']);
                $this->failHook((string) $op['to']);
                $files->move($op['file'], (string) $op['to']);
                $log[] = ['rename', $op['file'], (string) $op['to']];
                if ($files->exists($op['file']) || !$files->exists((string) $op['to'])) {
                    throw new BlueMapException('Renaming ' . basename($op['file']) . ' did not work.');
                }
                $renamed[$op['file']] = (string) $op['to'];
                $written[] = (string) $op['to'];
            }
            foreach ($plan['files'] as $path => $c) {
                if ($c['after'] === null) {
                    continue;                       // rename source
                }
                if (isset($renamed[$path])) {
                    continue;
                }
                $isRenameTarget = in_array($path, $renamed, true);
                $src = $isRenameTarget ? (string) array_search($path, $renamed, true) : null;
                $already = $isRenameTarget ? ($plan['files'][$src]['before'] ?? null) : $c['before'];
                if ($c['after'] === $already) {
                    continue;
                }
                $guard->assertStopped();
                $this->failHook($path);
                if ($c['before'] === null && !$isRenameTarget) {
                    $files->ensureDir(dirname($path) === '.' ? '' : dirname($path));
                }
                // Logged BEFORE the write: a write that fails its read-back may still have changed the file.
                $log[] = ['write', $path, $isRenameTarget ? null : $c['before'], $isRenameTarget ? $already : null];
                $files->writeVerified($path, (string) $c['after']);
                if (!in_array($path, $written, true)) {
                    $written[] = $path;
                }
            }

            // 5. Semantic verify against what is now on disk.
            $disk = [];
            foreach ($plan['files'] as $path => $c) {
                $disk[$path] = $c['after'] === null ? null : $files->read($path, self::MAX_FILE);
            }
            $problems = self::verifySemantics($plan, $disk);
            if ($problems !== []) {
                throw new BlueMapException('The written files did not pass the check (' . $problems[0] . ').');
            }
            foreach ($written as $p) {
                Trace::info('wizard.written', ['wizard' => $wizard, 'file' => $p]);
            }

            return $this->result(true, 'Saved. The changes load the next time the server starts.', $wizard, $backup, $written, false, $plan);
        } catch (\Throwable $e) {
            $msg = $e instanceof BlueMapException ? $e->getMessage() : 'Writing the files failed.';
            if (!$e instanceof BlueMapException) {
                Trace::error('wizard.apply_failed', ['wizard' => $wizard, 'cause' => get_class($e)]);
            }
            if ($log === [] && $backup === null) {
                return $this->result(false, $msg, $wizard, null, [], false, $plan);
            }
            $restored = $this->restore($plan, $log, $backup);
            if ($restored) {
                return $this->result(false, $msg . ' Nothing changed; your files were restored.', $wizard, $backup, [], true, $plan);
            }

            return $this->result(false, $msg . ' Restoring the old files failed too; copies are in ' . $backup . '.', $wizard, $backup, $written, false, $plan);
        }
    }

    /**
     * Every planned key must read back as planned and every other key must be unchanged.
     *
     * @param array<string, mixed> $plan
     * @param array<string, ?string> $disk path => content as read back (null = absent)
     * @return list<string> problems, [] = ok
     */
    public static function verifySemantics(array $plan, array $disk): array
    {
        $problems = [];
        $touched = [];
        foreach ($plan['ops'] as $op) {
            if (in_array($op['op'], ['rename', 'create'], true) || $op['path'] === null) {
                continue;
            }
            $touched[$op['file']][$op['path']] = $op;
        }
        foreach ($plan['files'] as $path => $c) {
            $after = $disk[$path] ?? null;
            if ($c['after'] === null) {
                if ($after !== null) {
                    $problems[] = basename($path) . ' should be gone';
                }
                continue;
            }
            if ($after === null) {
                $problems[] = basename($path) . ' is missing';
                continue;
            }
            if (str_ends_with($path, '.json')) {
                $new = json_decode($after);
                $old = $c['before'] === null ? null : json_decode($c['before']);
                if (!is_object($new)) {
                    $problems[] = basename($path) . ' is not valid JSON';
                    continue;
                }
                foreach ($touched[$path] ?? [] as $p => $op) {
                    if (($new->{$p} ?? null) !== $op['value'] && json_encode($new->{$p} ?? null) !== json_encode($op['value'])) {
                        $problems[] = $p . ' in ' . basename($path) . ' has the wrong value';
                    }
                }
                if (is_object($old)) {
                    foreach ((array) $old as $k => $v) {
                        if (!isset($touched[$path][$k]) && json_encode($new->{$k} ?? null) !== json_encode($v)) {
                            $problems[] = $k . ' in ' . basename($path) . ' changed unexpectedly';
                        }
                    }
                }
                continue;
            }
            if (!str_ends_with($path, '.conf')) {
                continue;
            }
            try {
                $doc = HoconDocument::parse($after);
                $old = $c['before'] === null ? null : HoconDocument::parse($c['before']);
            } catch (\Throwable $e) {
                $problems[] = basename($path) . ' can not be read back: ' . $e->getMessage();
                continue;
            }
            foreach ($touched[$path] ?? [] as $p => $op) {
                if (in_array($op['op'], ['comment_out'], true) || $op['after'] === '(removed)') {
                    if ($doc->has($p)) {
                        $problems[] = $p . ' is still set in ' . basename($path);
                    }
                    continue;
                }
                if (!$doc->has($p)) {
                    $problems[] = $p . ' is missing in ' . basename($path);
                    continue;
                }
                $want = $op['value'];
                if ($doc->kind($p) === 'scalar' && !is_array($want)) {
                    $got = $doc->get($p);
                    if (!(is_numeric($got) && is_numeric($want) ? (float) $got === (float) $want : $got === $want)) {
                        $problems[] = $p . ' in ' . basename($path) . ' has the wrong value';
                    }
                } elseif (is_string($want) && $doc->kind($p) !== 'scalar') {
                    if (trim((string) $doc->raw($p)) !== trim($want) && !str_contains(preg_replace('/\s+/', '', (string) $doc->raw($p)) ?? '', preg_replace('/\s+/', '', $want) ?? '')) {
                        $problems[] = $p . ' in ' . basename($path) . ' has the wrong value';
                    }
                } elseif (is_array($want) && !array_is_list($want)) {
                    if (HoconDocument::parse('x: ' . HoconValue::render($want))->get('x') !== HoconValue::decode((string) $doc->raw($p)) && !is_string($doc->get($p))) {
                        $problems[] = $p . ' in ' . basename($path) . ' has the wrong value';
                    }
                } elseif (is_array($want)) {
                    $got = $doc->get($p);
                    $norm = fn ($a) => is_array($a) ? array_map('strval', $a) : $a;
                    if ($norm($got) !== $norm($want)) {
                        $problems[] = $p . ' in ' . basename($path) . ' has the wrong value';
                    }
                }
            }
            if ($old !== null) {
                foreach ($old->paths() as $p) {
                    if (isset($touched[$path][$p]) || self::underTouched($p, array_keys($touched[$path] ?? []))) {
                        continue;
                    }
                    if ($old->kind($p) === 'object') {
                        continue;                   // its members are compared one by one
                    }
                    if ($doc->raw($p) !== $old->raw($p)) {
                        $problems[] = $p . ' in ' . basename($path) . ' changed unexpectedly';
                    }
                }
            }
        }

        return $problems;
    }

    /** @param list<string> $touchedPaths */
    private static function underTouched(string $p, array $touchedPaths): bool
    {
        foreach ($touchedPaths as $t) {
            if (str_starts_with($p, $t . '.') || str_starts_with($t, $p . '.')) {
                return true;
            }
        }

        return false;
    }

    /** @param list<array<int, mixed>> $log */
    private function restore(array $plan, array $log, ?string $backup): bool
    {
        $files = $this->files();
        $ok = true;
        foreach (array_reverse($log) as $a) {
            try {
                if ($a[0] === 'write') {
                    [, $path, $before] = $a;
                    $target = $before ?? ($a[3] ?? null);       // content as moved, before the rename is undone
                    // Entries are logged before their write, so the last one may never have changed anything.
                    $now = $files->read($path, self::MAX_FILE);
                    if ($target === null) {
                        if ($now !== null) {
                            $files->delete(dirname($path) === '.' ? '' : dirname($path), [basename($path)]);
                        }
                    } elseif ($now !== $target) {
                        $files->writeVerified($path, (string) $target);
                    }
                } else {
                    [, $from, $to] = $a;
                    if ($files->exists($to) && !$files->exists($from)) {
                        $files->move($to, $from);
                    }
                }
            } catch (\Throwable) {
                $ok = false;
            }
        }
        // Verify: every file the plan touched is as it was.
        foreach ($plan['files'] as $path => $c) {
            try {
                $now = $files->read($path, self::MAX_FILE);
                if ($now !== $c['before']) {
                    $ok = false;
                }
            } catch (\Throwable) {
                $ok = false;
            }
        }

        return $ok;
    }

    private function pruneBackups(): void
    {
        try {
            $names = array_map(fn ($e) => $e['name'], array_filter($this->files()->list(self::BACKUP_ROOT), fn ($e) => !$e['is_file']));
            sort($names);
            $old = array_slice($names, 0, max(0, count($names) - self::KEEP));
            if ($old !== []) {
                $this->files()->delete(self::BACKUP_ROOT, $old);
            }
        } catch (\Throwable) {
            // Pruning is housekeeping; never fail an apply over it.
        }
    }

    private function failHook(string $path): void
    {
        $target = getenv('BLUEMAP_TEST_FAIL_WRITE');
        if (is_string($target) && $target !== '' && $target === $path) {
            throw new BlueMapException('Test write failure for ' . basename($path) . '.');
        }
    }

    // ------------------------------------------------------------------ backups

    /** @return list<string> newest first */
    public function listBackups(): array
    {
        $names = array_map(fn ($e) => $e['name'], array_filter($this->files()->list(self::BACKUP_ROOT), fn ($e) => !$e['is_file']));
        $names = array_values(array_filter($names, fn ($n) => preg_match('/^\d{8}-\d{6}-[a-z][a-z-]*$/D', $n) === 1));
        rsort($names);

        return $names;
    }

    /** @return array<string, mixed> WizardResult */
    public function restoreBackup(string $stamp): array
    {
        $plan = ['wizard' => 'restore', 'post_actions' => [], 'ops' => [], 'files' => [], 'blockers' => []];
        try {
            if (preg_match('/^\d{8}-\d{6}-[a-z][a-z-]*$/D', $stamp) !== 1) {
                throw new BlueMapException('Invalid backup name.');
            }
            $guard = $this->guard();
            $files = $this->files();
            $guard->assertStopped();
            $root = self::BACKUP_ROOT . '/' . $stamp;
            $entries = $this->collect($root, '');
            if ($entries === []) {
                throw new BlueMapException('That backup is empty or does not exist.');
            }
            $newStamp = gmdate('Ymd-His') . '-restore';
            $safety = self::BACKUP_ROOT . '/' . $newStamp;
            $files->ensureDir($safety);
            $log = [];
            $written = [];
            try {
                foreach ($entries as $rel) {
                    self::assertPath($rel);
                    $content = $files->read($root . '/' . $rel, self::MAX_FILE);
                    if ($content === null) {
                        throw new BlueMapException('Could not read ' . $rel . ' from the backup.');
                    }
                    $cur = $files->read($rel, self::MAX_FILE);
                    if ($cur !== null) {
                        $files->ensureDir(dirname($safety . '/' . $rel));
                        $files->writeVerified($safety . '/' . $rel, $cur);
                    }
                    $guard->assertStopped();
                    $files->ensureDir(dirname($rel) === '.' ? '' : dirname($rel));
                    // Recorded BEFORE the write: a write that fails its read-back may still have changed the file.
                    $log[] = ['write', $rel, $cur];
                    $plan['files'][$rel] = ['before' => $cur, 'after' => $content];
                    $files->writeVerified($rel, $content);
                    $written[] = $rel;
                }
            } catch (\Throwable $e) {
                $restored = $this->restore($plan, $log, $safety);
                $m = $e instanceof BlueMapException ? $e->getMessage() : 'Restoring the backup failed.';

                return $this->result(false, $m . ($restored ? ' Nothing changed.' : ' Some files may be half restored; copies are in ' . $safety . '.'), 'restore', $safety, [], $restored, $plan);
            }

            return $this->result(true, 'Restored ' . count($written) . ' file(s) from ' . $stamp . '. Files created by the wizard were left in place.', 'restore', $safety, $written, false, $plan);
        } catch (BlueMapException $e) {
            return $this->result(false, $e->getMessage(), 'restore', null, [], false, $plan);
        }
    }

    /** @return list<string> paths below $root/$rel, relative to $root */
    private function collect(string $root, string $rel, int $depth = 0): array
    {
        if ($depth > 8) {
            return [];
        }
        $out = [];
        foreach ($this->files()->list($rel === '' ? $root : $root . '/' . $rel) as $e) {
            $r = ($rel === '' ? '' : $rel . '/') . $e['name'];
            if ($e['is_file']) {
                $out[] = $r;
            } else {
                array_push($out, ...$this->collect($root, $r, $depth + 1));
            }
        }

        return $out;
    }

    // ------------------------------------------------------------------ helpers

    private static function assertPath(string $p): void
    {
        ServerFiles::clean($p);
        if (str_starts_with($p, '/') || str_contains($p, '..') || str_starts_with(trim($p, '/'), '.pelican-bluemap')) {
            throw new BlueMapException('Refusing a path outside the BlueMap files.');
        }
    }

    /** @return array<string, mixed> */
    private function result(bool $ok, string $message, string $wizard, ?string $backup, array $written, bool $restored, array $plan): array
    {
        return ['ok' => $ok, 'message' => $message, 'wizard' => $wizard, 'backup' => $backup, 'written' => $written, 'restored' => $restored, 'post_actions' => $ok ? ($plan['post_actions'] ?? []) : []];
    }

    private function files(): ServerFiles
    {
        return $this->files ?? throw new \LogicException('Call forServer() first.');
    }

    private function guard(): ServerGuard
    {
        return $this->guard ?? throw new \LogicException('Call forServer() first.');
    }
}
