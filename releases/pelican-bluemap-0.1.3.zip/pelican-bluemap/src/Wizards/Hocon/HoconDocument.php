<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Hocon;

use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;

/**
 * Pure comment-preserving HOCON editor (docs/WIZARDS.md 5.1). A scanner, not a full parser: it indexes every
 * key occurrence of the object tree (array elements are not addressable) and edits value spans in place, so
 * every byte outside the edited span stays as it was. Immutable: each edit returns a new, re-validated document.
 * Anything it cannot edit safely is refused with a BlueMapException instead of being guessed at.
 */
final class HoconDocument
{
    public const MAX_BYTES = 1048576;

    private string $bom = '';
    private string $eol = "\n";
    private string $s = '';
    private int $n = 0;
    private int $i = 0;
    private ?int $rootClose = null;

    /** @var array<string, array{path: string, line: int, keyStart: int, valueStart: int, valueEnd: int, kind: string, raw: string, close: ?int, indent: ?string}> */
    private array $entries = [];

    /** @var array<string, array{lineStart: int, lineEnd: int, indent: string}> */
    private array $placeholders = [];

    private function __construct()
    {
    }

    public static function parse(string $text): self
    {
        if (strlen($text) > self::MAX_BYTES) {
            throw new BlueMapException('This config file is larger than 1 MiB, so the wizard will not edit it.');
        }
        $d = new self();
        if (str_starts_with($text, "\xEF\xBB\xBF")) {
            $d->bom = "\xEF\xBB\xBF";
            $text = substr($text, 3);
        }
        $d->s = $text;
        $d->n = strlen($text);
        $d->eol = str_contains($text, "\r\n") ? "\r\n" : "\n";
        $d->scanRoot();

        return $d;
    }

    // ------------------------------------------------------------------ reading

    public function text(): string
    {
        return $this->bom . $this->s;
    }

    public function has(string $path): bool
    {
        return isset($this->entries[$path]);
    }

    public function raw(string $path): ?string
    {
        return $this->entries[$path]['raw'] ?? null;
    }

    public function kind(string $path): ?string
    {
        return $this->entries[$path]['kind'] ?? null;
    }

    public function get(string $path): mixed
    {
        $e = $this->entries[$path] ?? null;

        return $e === null ? null : HoconValue::decode($e['raw']);
    }

    /** @return list<string> */
    public function paths(): array
    {
        return array_keys($this->entries);
    }

    // ------------------------------------------------------------------ editing

    public function set(string $path, mixed $value): self
    {
        $e = $this->entry($path);
        if ($e['kind'] === 'scalar' && $e['raw'][0] !== '"' && str_contains($e['raw'], '${')) {
            throw new BlueMapException("{$path} is set through a substitution (\${...}) in this file; the wizard will not replace it.");
        }

        return $this->splice($e['valueStart'], $e['valueEnd'], $this->reindent(HoconValue::render($value), $e['indent'] ?? ''));
    }

    /** Replace an object/array value with already rendered HOCON. Continuation lines get the key line's indent. */
    public function setBlock(string $path, string $hocon): self
    {
        $e = $this->entry($path);
        if ($e['kind'] === 'scalar') {
            throw new BlueMapException("{$path} is not a block in this file.");
        }

        return $this->splice($e['valueStart'], $e['valueEnd'], $this->reindent($hocon, $e['indent'] ?? ''));
    }

    public function insert(string $path, mixed $value): self
    {
        if (isset($this->entries[$path])) {
            throw new BlueMapException("{$path} is already set in this file.");
        }
        [$parent, $leaf] = self::split($path);
        $rendered = HoconValue::render($value);
        $eol = $this->eol;

        $ph = $this->placeholders[$parent . "\0" . $leaf] ?? null;
        if ($ph !== null) {
            $at = $ph['lineEnd'];
            $lead = ($at > 0 && $this->s[$at - 1] !== "\n") ? $eol : '';

            return $this->splice($at, $at, $lead . $ph['indent'] . $leaf . ': ' . $this->reindent($rendered, $ph['indent']) . $eol);
        }

        if ($parent === '' && $this->rootClose === null) {
            $b = $this->s;
            $sep = '';
            if ($b !== '') {
                if (!str_ends_with($b, "\n")) {
                    $sep .= $eol;
                }
                if (preg_match('/\n[ \t]*\r?\n$/', $b) !== 1) {
                    $sep .= $eol;
                }
            }

            return $this->splice($this->n, $this->n, $sep . $leaf . ': ' . $rendered . $eol);
        }

        if ($parent === '') {
            $open = $this->rootOpen();
            $close = (int) $this->rootClose;
            $keyIndent = '';
        } else {
            $p = $this->entries[$parent] ?? throw new BlueMapException("Can't add {$leaf}: {$parent} is missing in this file.");
            if ($p['kind'] !== 'object') {
                throw new BlueMapException("Can't add {$leaf}: {$parent} is not a block in this file.");
            }
            $open = $p['valueStart'];
            $close = (int) $p['close'];
            $keyIndent = $p['indent'] ?? '';
        }

        $ls = strrpos(substr($this->s, 0, $close), "\n");
        $ls = $ls === false ? 0 : $ls + 1;
        if (trim(substr($this->s, $ls, $close - $ls)) === '') {
            $indent = $this->childIndent($parent) ?? ($keyIndent . '  ');

            return $this->splice($ls, $ls, $indent . $leaf . ': ' . $this->reindent($rendered, $indent) . $eol);
        }

        // The block is written on one line: "{ }" or "{ a: 1 }".
        $inner = trim(substr($this->s, $open + 1, $close - $open - 1));
        if ($inner === '') {
            return $this->splice($open, $close + 1, '{ ' . $leaf . ': ' . $rendered . ' }');
        }
        $k = $close;
        while ($k > $open + 1 && in_array($this->s[$k - 1], [' ', "\t"], true)) {
            $k--;
        }

        return $this->splice($k, $k, ', ' . $leaf . ': ' . $rendered);
    }

    public function upsert(string $path, mixed $value): self
    {
        if (!$this->has($path)) {
            return $this->insert($path, $value);
        }
        if ($value instanceof HoconRaw && $this->kind($path) !== 'scalar') {
            return $this->setBlock($path, $value->text);
        }

        return $this->set($path, $value);
    }

    /** Single-line entries only: "key: v" becomes "# key: v  # note". */
    public function commentOut(string $path, string $note): self
    {
        $e = $this->entry($path);
        $ls = $this->lineStart($e['keyStart']);
        if (trim(substr($this->s, $ls, $e['keyStart'] - $ls)) !== '' || str_contains(substr($this->s, $e['keyStart'], $e['valueEnd'] - $e['keyStart']), "\n")) {
            throw new BlueMapException("{$path} is not on a line of its own, so the wizard can't comment it out.");
        }
        $le = strpos($this->s, "\n", $e['valueEnd']);
        $le = $le === false ? $this->n : $le;
        if ($le > 0 && $this->s[$le - 1] === "\r") {
            $le--;
        }
        $note = trim(str_replace(["\r", "\n"], ' ', $note));

        return $this->splice($le, $le, $note === '' ? '' : '  # ' . $note)->spliceAt($e['keyStart'], '# ');
    }

    /** Delete an entry (any size). The whole line(s) go when the entry is alone on them. */
    public function remove(string $path): self
    {
        $e = $this->entry($path);
        $ls = $this->lineStart($e['keyStart']);
        $start = $e['keyStart'];
        $end = $e['valueEnd'];
        $le = strpos($this->s, "\n", $end);
        $le = $le === false ? $this->n : $le;
        if (trim(substr($this->s, $ls, $start - $ls)) === '' && trim(substr($this->s, $end, $le - $end)) === '') {
            $start = $ls;
            $end = min($this->n, $le + 1);
        }

        return $this->splice($start, $end, '');
    }

    // ------------------------------------------------------------------ internals

    /** @return array{path: string, line: int, keyStart: int, valueStart: int, valueEnd: int, kind: string, raw: string, close: ?int, indent: ?string} */
    private function entry(string $path): array
    {
        return $this->entries[$path] ?? throw new BlueMapException("The setting {$path} is not in this file.");
    }

    private function splice(int $from, int $to, string $text): self
    {
        return self::parse($this->bom . substr($this->s, 0, $from) . $text . substr($this->s, $to));
    }

    private function spliceAt(int $at, string $text): self
    {
        return $this->splice($at, $at, $text);
    }

    private function lineStart(int $pos): int
    {
        $p = strrpos(substr($this->s, 0, $pos), "\n");

        return $p === false ? 0 : $p + 1;
    }

    private function reindent(string $text, string $indent): string
    {
        $lines = preg_split('/\r\n|\n/', $text) ?: [$text];
        foreach ($lines as $k => $line) {
            if ($k > 0 && $line !== '') {
                $lines[$k] = $indent . $line;
            }
        }

        return implode($this->eol, $lines);
    }

    /** @return array{0: string, 1: string} */
    private static function split(string $path): array
    {
        $p = strrpos($path, '.');

        return $p === false ? ['', $path] : [substr($path, 0, $p), substr($path, $p + 1)];
    }

    private function childIndent(string $parent): ?string
    {
        $prefix = $parent === '' ? '' : $parent . '.';
        foreach ($this->entries as $path => $e) {
            if ($e['indent'] !== null && str_starts_with($path, $prefix) && !str_contains(substr($path, strlen($prefix)), '.')) {
                return $e['indent'];
            }
        }

        return null;
    }

    private function rootOpen(): int
    {
        $i = 0;
        while ($i < $this->n && $this->s[$i] !== '{') {
            if ($this->s[$i] === '#' || ($this->s[$i] === '/' && ($this->s[$i + 1] ?? '') === '/')) {
                $e = strpos($this->s, "\n", $i);
                $i = $e === false ? $this->n : $e;
            } else {
                $i++;
            }
        }

        return $i;
    }

    // ------------------------------------------------------------------ scanner

    private function refuse(string $what, ?int $at = null): never
    {
        $line = $at === null ? '' : ' (line ' . (substr_count($this->s, "\n", 0, min($at, $this->n)) + 1) . ')';
        throw new BlueMapException("The wizard can't safely edit this config file: {$what}{$line}.");
    }

    private function scanRoot(): void
    {
        $this->i = 0;
        // A file wrapped in one pair of braces is allowed.
        $j = 0;
        while ($j < $this->n) {
            $c = $this->s[$j];
            if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n") {
                $j++;
            } elseif ($c === '#' || ($c === '/' && ($this->s[$j + 1] ?? '') === '/')) {
                $e = strpos($this->s, "\n", $j);
                $j = $e === false ? $this->n : $e;
            } else {
                break;
            }
        }
        if ($j < $this->n && $this->s[$j] === '{') {
            $this->i = $j + 1;
            $this->rootClose = $this->parseObject('', true);
            $this->skipTrailing();
        } else {
            $this->parseObject('', false);
        }
    }

    private function skipTrailing(): void
    {
        while ($this->i < $this->n) {
            $c = $this->s[$this->i];
            if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n" || $c === ',') {
                $this->i++;
            } elseif ($c === '#' || ($c === '/' && ($this->s[$this->i + 1] ?? '') === '/')) {
                $this->comment('');
            } else {
                $this->refuse('unexpected text after the closing brace', $this->i);
            }
        }
    }

    /** Parses entries until the closing brace (returned: its offset) or EOF for an unbraced root. */
    private function parseObject(string $prefix, bool $braced): int
    {
        $s = $this->s;
        $n = $this->n;
        while (true) {
            while ($this->i < $n) {
                $c = $s[$this->i];
                if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n" || $c === ',') {
                    $this->i++;
                } elseif ($c === '#' || ($c === '/' && ($s[$this->i + 1] ?? '') === '/')) {
                    $this->comment($prefix);
                } else {
                    break;
                }
            }
            if ($this->i >= $n) {
                if ($braced) {
                    $this->refuse('unbalanced braces', $n);
                }

                return $n;
            }
            $c = $s[$this->i];
            if ($c === '}') {
                if (!$braced) {
                    $this->refuse('unbalanced braces', $this->i);
                }
                $close = $this->i;
                $this->i++;

                return $close;
            }

            // ---- key
            $keyStart = $this->i;
            $quoted = false;
            if ($c === '"') {
                if (substr($s, $this->i, 3) === '"""') {
                    $this->refuse('a triple-quoted key', $this->i);
                }
                $key = (string) $this->readQuoted();
                $quoted = true;
            } else {
                while ($this->i < $n && !in_array($s[$this->i], [' ', "\t", "\r", "\n", ':', '=', '{', '}', '[', ']', ',', '#', '"'], true)
                    && !($s[$this->i] === '+' && ($s[$this->i + 1] ?? '') === '=')
                    && !($s[$this->i] === '/' && ($s[$this->i + 1] ?? '') === '/')) {
                    $this->i++;
                }
                if ($this->i === $keyStart) {
                    $this->refuse('unexpected character "' . $c . '"', $this->i);
                }
                $key = substr($s, $keyStart, $this->i - $keyStart);
            }
            while ($this->i < $n && ($s[$this->i] === ' ' || $s[$this->i] === "\t")) {
                $this->i++;
            }
            $ch = $s[$this->i] ?? '';
            if ($ch === '+' && ($s[$this->i + 1] ?? '') === '=') {
                $this->refuse('a "+=" append', $this->i);
            }
            if (!$quoted && $key === 'include' && $ch !== ':' && $ch !== '=' && $ch !== '{') {
                $this->refuse('an include statement', $keyStart);
            }
            if ($ch === ':' || $ch === '=') {
                $this->i++;
                while ($this->i < $n && in_array($s[$this->i], [' ', "\t", "\r", "\n"], true)) {
                    $this->i++;
                }
            } elseif ($ch !== '{') {
                $this->refuse('expected ":" after the key "' . $key . '"', $keyStart);
            }

            $path = $prefix === '' ? $key : $prefix . '.' . $key;
            if (isset($this->entries[$path])) {
                $this->refuse('"' . $path . '" appears twice', $keyStart);
            }
            $ls = strrpos(substr($s, 0, $keyStart), "\n");
            $ls = $ls === false ? 0 : $ls + 1;
            $pre = substr($s, $ls, $keyStart - $ls);
            $indent = trim($pre) === '' ? $pre : null;
            $line = substr_count($s, "\n", 0, $keyStart) + 1;

            // ---- value
            $vs = $this->i;
            $v = $s[$vs] ?? '';
            $close = null;
            if ($v === '' || $v === '}' || $v === ',') {
                $this->refuse('"' . $path . '" has no value', $keyStart);
            }
            if ($v === '{') {
                $kind = 'object';
                $this->entries[$path] = [];   // keeps document order: the key precedes its children
                $this->i++;
                $close = $this->parseObject($path, true);
                $ve = $close + 1;
            } elseif ($v === '[') {
                $kind = 'array';
                $ve = $this->skipArray($vs);
                $this->i = $ve;
            } elseif ($v === '"') {
                $kind = 'scalar';
                if (substr($s, $vs, 3) === '"""') {
                    $e = strpos($s, '"""', $vs + 3);
                    if ($e === false) {
                        $this->refuse('an unterminated """ string', $vs);
                    }
                    $e += 3;
                    while (($s[$e] ?? '') === '"') {
                        $e++;
                    }
                    $ve = $e;
                    $this->i = $ve;
                } else {
                    $this->readQuoted();
                    $ve = $this->i;
                }
            } else {
                $kind = 'scalar';
                $j = $vs;
                while ($j < $n) {
                    $cc = $s[$j];
                    if ($cc === "\n" || $cc === "\r" || $cc === ',' || $cc === '}' || $cc === '#' || ($cc === '/' && ($s[$j + 1] ?? '') === '/')) {
                        break;
                    }
                    if ($cc === '$' && ($s[$j + 1] ?? '') === '{') {
                        $e = strpos($s, '}', $j);
                        if ($e === false) {
                            $this->refuse('an unterminated substitution', $j);
                        }
                        $j = $e + 1;
                        continue;
                    }
                    if ($cc === '"') {
                        $this->i = $j;
                        $this->readQuoted();
                        $j = $this->i;
                        continue;
                    }
                    $j++;
                }
                while ($j > $vs && ($s[$j - 1] === ' ' || $s[$j - 1] === "\t")) {
                    $j--;
                }
                $ve = $j;
                $this->i = $j;
                if ($ve === $vs) {
                    $this->refuse('"' . $path . '" has no value', $keyStart);
                }
            }

            $this->entries[$path] = [
                'path' => $path, 'line' => $line, 'keyStart' => $keyStart, 'valueStart' => $vs, 'valueEnd' => $ve,
                'kind' => $kind, 'raw' => substr($s, $vs, $ve - $vs), 'close' => $close, 'indent' => $indent,
            ];
        }
    }

    /** At a '"': reads a JSON-style string, leaves $this->i after the closing quote, returns the decoded text. */
    private function readQuoted(): string
    {
        $s = $this->s;
        $start = $this->i;
        $j = $start + 1;
        while ($j < $this->n && $s[$j] !== '"') {
            if ($s[$j] === "\n") {
                $this->refuse('a string that is not closed', $start);
            }
            $j += $s[$j] === '\\' ? 2 : 1;
        }
        if ($j >= $this->n) {
            $this->refuse('a string that is not closed', $start);
        }
        $this->i = $j + 1;
        $lit = substr($s, $start, $j + 1 - $start);
        $d = json_decode($lit);

        return is_string($d) ? $d : substr($lit, 1, -1);
    }

    /** Offset just after the array that starts at $start ('['). */
    private function skipArray(int $start): int
    {
        $s = $this->s;
        $n = $this->n;
        $stack = [];
        for ($j = $start; $j < $n; $j++) {
            $c = $s[$j];
            if ($c === '"') {
                if (substr($s, $j, 3) === '"""') {
                    $e = strpos($s, '"""', $j + 3);
                    if ($e === false) {
                        $this->refuse('an unterminated """ string', $j);
                    }
                    $j = $e + 2;
                    continue;
                }
                for ($j++; $j < $n && $s[$j] !== '"'; $j++) {
                    if ($s[$j] === '\\') {
                        $j++;
                    } elseif ($s[$j] === "\n") {
                        $this->refuse('a string that is not closed', $j);
                    }
                }
                if ($j >= $n) {
                    $this->refuse('a string that is not closed', $start);
                }
            } elseif ($c === '#' || ($c === '/' && ($s[$j + 1] ?? '') === '/')) {
                $e = strpos($s, "\n", $j);
                $j = $e === false ? $n : $e;
            } elseif ($c === '[' || $c === '{') {
                $stack[] = $c === '[' ? ']' : '}';
            } elseif ($c === ']' || $c === '}') {
                if ($stack === [] || array_pop($stack) !== $c) {
                    $this->refuse('unbalanced brackets', $j);
                }
                if ($stack === []) {
                    return $j + 1;
                }
            }
        }
        $this->refuse('unbalanced brackets', $start);
    }

    /** Skips a comment at $this->i (to the end of the line) and remembers "#key:" placeholders. */
    private function comment(string $prefix): void
    {
        $start = $this->i;
        $e = strpos($this->s, "\n", $start);
        $end = $e === false ? $this->n : $e;
        $ls = $this->lineStart($start);
        $pre = substr($this->s, $ls, $start - $ls);
        if (trim($pre) === '' && $start < $this->n) {
            $text = substr($this->s, $start, $end - $start);
            if (preg_match('/^(?:#|\/\/)[ \t]?([A-Za-z0-9_.-]+)[ \t]*[:=]/', $text, $m) === 1) {
                $k = $prefix . "\0" . $m[1];
                if (!isset($this->placeholders[$k])) {
                    $this->placeholders[$k] = ['lineStart' => $ls, 'lineEnd' => $e === false ? $this->n : $e + 1, 'indent' => $pre];
                }
            }
        }
        $this->i = $end;
    }
}
