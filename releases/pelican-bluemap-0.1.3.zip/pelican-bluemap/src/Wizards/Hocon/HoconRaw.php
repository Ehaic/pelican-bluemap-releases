<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Hocon;

/** Already rendered HOCON text (an object or array block) that HoconValue::render must emit unchanged. */
final class HoconRaw
{
    public function __construct(public readonly string $text)
    {
    }
}
