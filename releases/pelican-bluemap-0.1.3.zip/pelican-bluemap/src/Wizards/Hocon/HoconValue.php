<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Hocon;

use Ehaic\PelicanBlueMap\Support\ConfigRenderer;

/** Pure: PHP value <-> HOCON text (docs/WIZARDS.md 5.1). */
final class HoconValue
{
    public static function render(mixed $v): string
    {
        if ($v instanceof HoconRaw) {
            return $v->text;
        }
        if ($v === null) {
            return 'null';
        }
        if (is_bool($v)) {
            return $v ? 'true' : 'false';
        }
        if (is_int($v)) {
            return (string) $v;
        }
        if (is_float($v)) {
            if (!is_finite($v)) {
                throw new \InvalidArgumentException('Cannot render a non-finite number');
            }
            $s = rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.');

            return ($s === '' || $s === '-0') ? '0' : $s;
        }
        if (is_string($v)) {
            return ConfigRenderer::hoconString($v);
        }
        if (is_array($v)) {
            if (array_is_list($v)) {
                return $v === [] ? '[]' : '[ ' . implode(', ', array_map(self::render(...), $v)) . ' ]';
            }
            $parts = [];
            foreach ($v as $k => $item) {
                $key = (string) $k;
                $parts[] = (preg_match('/^[A-Za-z0-9_-]+$/', $key) === 1 ? $key : ConfigRenderer::hoconString($key)) . ': ' . self::render($item);
            }

            return '{ ' . implode(', ', $parts) . ' }';
        }
        throw new \InvalidArgumentException('Cannot render this value as HOCON');
    }

    /** Scalar (bool/int/float/string/null), list of scalars, or the raw text for objects and mixed arrays. */
    public static function decode(string $raw): mixed
    {
        $raw = trim($raw);
        if ($raw === '') {
            return null;
        }
        if ($raw[0] === '[') {
            return self::decodeList($raw);
        }
        if ($raw[0] === '{') {
            return $raw;
        }

        return self::decodeScalar($raw);
    }

    public static function decodeScalar(string $raw): mixed
    {
        if (str_starts_with($raw, '"""') && str_ends_with($raw, '"""') && strlen($raw) >= 6) {
            return substr($raw, 3, -3);
        }
        if ($raw[0] === '"') {
            $d = json_decode($raw);

            return is_string($d) ? $d : substr($raw, 1, -1);
        }
        if ($raw === 'true') {
            return true;
        }
        if ($raw === 'false') {
            return false;
        }
        if ($raw === 'null') {
            return null;
        }
        if (preg_match('/^-?\d+$/', $raw) === 1 && strlen($raw) < 18) {
            return (int) $raw;
        }
        if (preg_match('/^-?\d+\.\d+(?:[eE][+-]?\d+)?$/', $raw) === 1) {
            return (float) $raw;
        }

        return $raw;
    }

    /** @return list<mixed>|string list of scalars, or the raw text when an element is not a scalar */
    private static function decodeList(string $raw): array|string
    {
        $s = substr($raw, 1);
        $n = strlen($s);
        $out = [];
        $i = 0;
        while ($i < $n) {
            $c = $s[$i];
            if ($c === ' ' || $c === "\t" || $c === "\r" || $c === "\n" || $c === ',') {
                $i++;
            } elseif ($c === '#' || ($c === '/' && ($s[$i + 1] ?? '') === '/')) {
                $e = strpos($s, "\n", $i);
                $i = $e === false ? $n : $e;
            } elseif ($c === ']') {
                return $out;
            } elseif ($c === '{' || $c === '[') {
                return $raw;
            } elseif ($c === '"') {
                $j = $i + 1;
                while ($j < $n && $s[$j] !== '"') {
                    $j += $s[$j] === '\\' ? 2 : 1;
                }
                $out[] = self::decodeScalar(substr($s, $i, $j - $i + 1));
                $i = $j + 1;
            } else {
                $j = $i;
                while ($j < $n && !in_array($s[$j], [' ', "\t", "\r", "\n", ',', ']', '#'], true)) {
                    $j++;
                }
                $out[] = self::decodeScalar(substr($s, $i, $j - $i));
                $i = $j;
            }
        }

        return $raw;
    }
}
