# pelican-bluemap

Pelican panel plugin (1.0.0-rc.2) that installs and configures [BlueMap](https://bluemap.bluecolored.de) on
Minecraft Java servers: MariaDB map storage through the panel's database host, and an HTTPS address per server
through Nginx Proxy Manager (NPM) with a per-subdomain Let's Encrypt certificate.

## Install

1. Download `pelican-bluemap.zip` from the releases and import it in Admin → Plugins, then enable it.
2. Admin → Plugins → BlueMap → Settings: NPM URL, a dedicated NPM user (no admin rights), base domain,
   forward host and database host. Use "Test NPM connection" and "Test port 80" (they test the saved settings).
3. Servers on Minecraft eggs get a **BlueMap** page. Install needs a stopped server, one spare allocation (the web
   port) and a database slot (`database_limit` ≥ 1).

## Permissions (per server)

| action | needs |
|---|---|
| view | `file.read` |
| install / resume / finish setup / update / change port | `file.create` + `file.update` + `file.delete` |
| uninstall | `file.delete` + `file.update` (dropping the database also `database.delete`) |
| retry certificate | `file.update` |
| pause / resume / update / purge / reload | `control.console` |

## Notes

- Everything that touches server files requires the server to be **stopped** (enforced server-side).
- The NPM password is stored encrypted with `APP_KEY`; changing the key means re-entering it.
- **Uninstall BlueMap from each server before uninstalling the plugin.** Removing the plugin drops its table
  (rows are first saved to `storage/app/pelican-bluemap-orphans-*.json`).

See `docs/DESIGN.md` in the repository for the full behaviour.
