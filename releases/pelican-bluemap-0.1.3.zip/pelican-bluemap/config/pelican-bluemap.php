<?php

declare(strict_types=1);

// Values can be changed on Admin -> Plugins -> BlueMap -> Settings (written to the panel's .env).
return [
    'npm_url' => env('BLUEMAP_NPM_URL', 'http://192.168.4.171:81'),
    'npm_email' => env('BLUEMAP_NPM_EMAIL', ''),
    'npm_password' => env('BLUEMAP_NPM_PASSWORD', ''), // "enc:<Crypt::encryptString>"
    'base_domain' => env('BLUEMAP_BASE_DOMAIN', 'andrewj.us'),
    'le_email' => env('BLUEMAP_LE_EMAIL', ''),
    'hsts' => (bool) env('BLUEMAP_HSTS', true),
    'forward_host' => env('BLUEMAP_FORWARD_HOST', ''),
    'jdbc_host' => env('BLUEMAP_JDBC_HOST', ''),
    'jdbc_port' => env('BLUEMAP_JDBC_PORT', ''),
    'reserved' => env('BLUEMAP_RESERVED', 'www,mail,smtp,imap,panel,pelican,wings,node,npm,proxy,auth,sso,git,gitea,api,admin,dashboard,vpn,cloud,map,maps,status'),
    'debug' => (bool) env('BLUEMAP_DEBUG', false),
    'modrinth_url' => 'https://api.modrinth.com/v2',
    'user_agent' => 'Ehaic/pelican-bluemap (github.com/Ehaic/pelican-bluemap)',
    'min_bluemap_major' => 5,
    'jdbc_driver' => [
        'filename' => 'mariadb-java-client-3.5.11.jar',
        'url' => 'https://repo1.maven.org/maven2/org/mariadb/jdbc/mariadb-java-client/3.5.11/mariadb-java-client-3.5.11.jar',
        'sha1' => '2fd47e0cfae9e8a0f0b629da31a72fa99eeeb06d',
        'size' => 793387,
        'class' => 'org.mariadb.jdbc.Driver',
    ],
    'cert_cooldown_minutes' => 15,
    'cert_hourly_cap' => 10,
    'backups_keep' => 3,
    'max_log_bytes' => 8 * 1024 * 1024,
    'max_verify_bytes' => 32 * 1024 * 1024,
    'test_abort_after' => env('BLUEMAP_TEST_ABORT_AFTER'), // testenv only; honoured only when debug=true
];
