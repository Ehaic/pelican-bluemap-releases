<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (!Schema::hasColumn('bluemap_installations', 'wizard_state')) {
            Schema::table('bluemap_installations', function (Blueprint $table) {
                $table->json('wizard_state')->nullable();
                $table->json('wizard_pending')->nullable();
            });
        }
    }

    public function down(): void
    {
        if (Schema::hasColumn('bluemap_installations', 'wizard_state')) {
            Schema::table('bluemap_installations', function (Blueprint $table) {
                $table->dropColumn(['wizard_state', 'wizard_pending']);
            });
        }
    }
};
