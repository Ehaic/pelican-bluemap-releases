<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('bluemap_installations', function (Blueprint $table) {
            $table->increments('id');
            $table->unsignedInteger('server_id')->unique();
            $table->foreign('server_id')->references('id')->on('servers')->cascadeOnDelete();

            $table->string('status', 32);
            $table->string('failed_step', 32)->nullable();
            $table->text('last_error')->nullable();
            $table->json('steps_done');

            $table->string('loader', 16);
            $table->string('mc_version', 32);
            $table->string('jar_dir', 64);
            $table->string('config_dir', 64);

            $table->string('bluemap_version_id', 16)->nullable();
            $table->string('bluemap_version_number', 64)->nullable();
            $table->string('jar_path', 255)->nullable();
            $table->string('jar_sha1', 40)->nullable();
            $table->string('driver_path', 255)->nullable();
            $table->string('fabric_api_path', 255)->nullable();
            $table->boolean('fabric_api_by_plugin')->default(false);

            $table->unsignedInteger('database_id')->nullable();
            $table->foreign('database_id')->references('id')->on('databases')->nullOnDelete();
            $table->boolean('db_created_by_plugin')->default(false);

            $table->unsignedInteger('allocation_id')->nullable();
            $table->foreign('allocation_id')->references('id')->on('allocations')->nullOnDelete();
            $table->unsignedInteger('web_port')->nullable();
            $table->string('forward_host', 255)->nullable();

            $table->string('subdomain', 63)->nullable();
            $table->string('fqdn', 255)->nullable()->unique();
            $table->unsignedInteger('npm_host_id')->nullable();
            $table->unsignedInteger('npm_cert_id')->nullable();
            $table->string('cert_status', 16)->default('none');
            $table->text('cert_error')->nullable();
            $table->timestamp('cert_expires_at')->nullable();

            $table->boolean('maps_finalized')->default(false);
            $table->json('backups')->nullable();
            $table->unsignedInteger('created_by')->nullable();

            $table->timestamps();
        });
    }

    public function down(): void
    {
        // Rows hold NPM host/certificate ids that nothing else records: dump them before the table goes.
        if (Schema::hasTable('bluemap_installations')) {
            $rows = DB::table('bluemap_installations')->get();
            if ($rows->isNotEmpty()) {
                $path = storage_path('app/pelican-bluemap-orphans-' . date('Ymd-His') . '.json');
                file_put_contents($path, json_encode($rows->all(), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
                Log::warning('pelican-bluemap: plugin tables dropped with ' . $rows->count() . ' installation row(s); NPM ids saved to ' . $path);
            }
        }

        Schema::dropIfExists('bluemap_installations');
    }
};
