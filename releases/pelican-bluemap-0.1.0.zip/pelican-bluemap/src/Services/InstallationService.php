<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Enums\SubuserPermission;
use App\Facades\Activity;
use App\Models\Allocation;
use App\Models\Server;
use App\Models\User;
use Ehaic\PelicanBlueMap\Clients\ModrinthClient;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Support\ConfigRenderer;
use Ehaic\PelicanBlueMap\Support\InstallPlan;
use Ehaic\PelicanBlueMap\Support\MinecraftJavaGate;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Support\SubdomainGenerator;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Support\Facades\Cache;

/**
 * The orchestrator: install / resume / certificate / finish setup / update / change port / uninstall / rollback.
 * Every mutating method runs under the per-server lock, checks permissions and the stopped rule, and returns an
 * OperationResult instead of throwing.
 *
 * @phpstan-type OperationResult array{ok: bool, status: string, step: ?string, message: string, next: ?string}
 */
class InstallationService
{
    public const STEPS = ['database', 'jars', 'config', 'proxy_host', 'certificate'];
    public const UNINSTALL_STEPS = ['proxy_host', 'certificate', 'jars', 'config', 'database', 'row'];
    private const FILE_RW = [SubuserPermission::FileCreate, SubuserPermission::FileUpdate, SubuserPermission::FileDelete];
    private const MAX_CONF_BYTES = 1024 * 1024;

    private ?Server $server = null;
    private ?User $user = null;
    private ?string $op = null;
    private ?string $stamp = null;

    public function forServer(Server $server, ?User $user): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->user = $user;
        $new->op = null;
        $new->stamp = null;

        return $new;
    }

    // ================================================================== preflight

    /**
     * @return array{can_install: bool, blockers: list<string>, warnings: list<string>, detection: array<string, mixed>,
     *               build: ?array<string, mixed>, database: array{ok: bool, reason: ?string, existing_database_id: ?int},
     *               allocations: list<array{id: int, label: string, port: int}>, subdomain_suggestion: ?string, settings_ok: bool}
     */
    public function preflight(?string $loaderOverride = null, ?string $mcOverride = null): array
    {
        $server = $this->server();
        $settings = app(Settings::class);
        $blockers = [];
        $warnings = [];

        $detection = $this->safeDetect($loaderOverride, $mcOverride);
        $loader = $detection['loader'];
        $mc = $detection['mc_version'];

        if (!$this->guard()->can($this->user, SubuserPermission::FileRead)) {
            $blockers[] = "You don't have permission to see this server's files.";
        }
        if ($loader === 'vanilla') {
            $blockers[] = 'BlueMap needs Fabric, Forge, NeoForge, Paper, Spigot or Sponge. Vanilla servers are not supported.';
        } elseif (LoaderDetector::layoutFor($loader) === null) {
            $blockers[] = 'The server type could not be detected. Pick the loader (Fabric, Forge, NeoForge, Paper, Spigot or Sponge).';
        }
        if ($mc === null) {
            $blockers[] = 'Start the server once so the Minecraft version can be read, or pick it by hand.';
        }

        $build = null;
        if (LoaderDetector::layoutFor($loader) !== null && $mc !== null) {
            try {
                $build = app(ModrinthClient::class)->bestBlueMap($loader, $mc, (bool) $detection['fabric_api_present']);
            } catch (\Throwable $e) {
                Trace::warning('preflight.modrinth_failed', ['cause' => get_class($e)]);
                $build = ['status' => 'error', 'bluemap' => null, 'fabric_api' => null, 'query_loaders' => [], 'message' => 'Modrinth could not be reached. Try again in a minute.'];
            }
            if ($build['status'] !== 'ok') {
                $blockers[] = $build['message'] ?? match ($build['status']) {
                    'unsupported' => "Only BlueMap versions older than 5 exist for {$loader} {$mc}; they are not supported.",
                    'none' => "No BlueMap build exists for {$loader} {$mc}.",
                    default => 'Modrinth could not be reached. Try again in a minute.',
                };
            }
        }

        $row = Installation::forServer($server);
        $database = ['ok' => false, 'reason' => 'Database check failed.', 'existing_database_id' => null];
        try {
            $database = app(DatabaseProvisioner::class)->preflight($server, $row?->database_id);
        } catch (\Throwable $e) {
            Trace::warning('preflight.db_failed', ['cause' => get_class($e)]);
        }
        if (!$database['ok']) {
            $blockers[] = (string) $database['reason'];
        } elseif ($database['existing_database_id'] === null && !$this->guard()->can($this->user, SubuserPermission::DatabaseCreate)) {
            $blockers[] = "A database must be created for the map, but you don't have the database.create permission on this server.";
        }

        $picker = app(AllocationPicker::class);
        $allocations = [];
        foreach ($picker->candidates($server, $row?->allocation_id) as $a) {
            $allocations[] = ['id' => (int) $a->id, 'label' => $picker->label($a), 'port' => (int) $a->port];
        }
        if ($allocations === []) {
            $blockers[] = "This server needs a second port (allocation) for the map's web server. Ask an admin to add one.";
        }

        $settingsOk = $settings->isConfigured();
        if (!$settingsOk) {
            $blockers[] = 'The web proxy is not set up yet. An admin must fill in Admin → Plugins → BlueMap → Settings.';
        }

        if ($detection['existing_jars'] !== [] && ($row === null)) {
            $warnings[] = 'A BlueMap jar is already installed here (not managed by this plugin). Installing takes it over; the old jar is kept in ' . ServerFiles::BACKUP_ROOT . '.';
        }
        foreach ($detection['maps'] as $map) {
            if ($map['storage'] !== null && $map['storage'] !== 'sql') {
                $warnings[] = "Existing map \"{$map['id']}\" uses \"{$map['storage']}\" storage. It will be switched to MariaDB; tiles already rendered are not copied.";
                break;
            }
        }
        if ($row !== null && $row->status === 'failed') {
            $warnings[] = 'A previous install did not finish. Use Retry or Undo install.';
        }
        if (!$this->guard()->isStopped()) {
            $warnings[] = 'Stop the server before installing: files are changed.';
        }

        return [
            'can_install' => $blockers === [],
            'blockers' => $blockers,
            'warnings' => $warnings,
            'detection' => $detection,
            'build' => $build,
            'database' => $database,
            'allocations' => $allocations,
            'subdomain_suggestion' => $this->suggestSubdomain($row),
            'settings_ok' => $settingsOk,
        ];
    }

    private function suggestSubdomain(?Installation $row): ?string
    {
        if ($row?->subdomain !== null) {
            return $row->subdomain;
        }
        try {
            $settings = app(Settings::class);
            $gen = new SubdomainGenerator();
            foreach ($gen->candidates((string) $this->server()->name, $settings->reservedSubdomains()) as $label) {
                if (!Installation::query()->where('fqdn', $label . '.' . $settings->baseDomain())->exists()) {
                    return $label;
                }
            }
        } catch (\Throwable) {
            // A suggestion is optional.
        }

        return null;
    }

    /** @return array<string, mixed> */
    private function safeDetect(?string $loader, ?string $mc): array
    {
        try {
            return app(LoaderDetector::class)->forServer($this->server())->detect($loader, $mc);
        } catch (\Throwable $e) {
            Trace::warning('detect.failed', ['cause' => get_class($e)]);

            return [
                'loader' => 'unknown', 'loader_source' => 'none', 'mc_version' => null, 'mc_source' => 'none',
                'jar_dir' => null, 'config_dir' => null, 'existing_jars' => [], 'config_exists' => false, 'maps' => [],
                'fabric_api_present' => false, 'driver_present' => false,
            ];
        }
    }

    // ================================================================== install / resume

    /** @param array{allocation_id: int, subdomain: ?string, loader: ?string, mc_version: ?string, install_fabric_api: bool} $options */
    public function install(array $options): array
    {
        return $this->run('install', self::FILE_RW, function () use ($options) {
            $server = $this->server();
            if (!MinecraftJavaGate::matches($server)) {
                throw new BlueMapException('This server is not a Minecraft Java server.');
            }
            if (!app(Settings::class)->isConfigured()) {
                throw new BlueMapException('The web proxy is not set up yet. An admin must fill in Admin → Plugins → BlueMap → Settings.');
            }

            $row = Installation::forServer($server);
            if ($row !== null) {
                $this->assertNotUninstalling($row);
                if (!in_array($row->status, ['failed', 'installing'], true)) {
                    throw new BlueMapException('BlueMap is already installed on this server.');
                }
            }

            $det = app(LoaderDetector::class)->forServer($server)->detect($options['loader'] ?? null, $options['mc_version'] ?? null);
            $layout = LoaderDetector::layoutFor($det['loader']);
            if ($layout === null) {
                throw new BlueMapException('BlueMap needs Fabric, Forge, NeoForge, Paper, Spigot or Sponge. Pick the loader.');
            }
            if ($det['mc_version'] === null) {
                throw new BlueMapException('The Minecraft version is unknown. Start the server once, or pick it by hand.');
            }

            $alloc = app(AllocationPicker::class)->resolve($server, (int) ($options['allocation_id'] ?? 0));

            $label = isset($options['subdomain']) ? strtolower(trim((string) $options['subdomain'])) : '';
            if ($label !== '') {
                $gen = new SubdomainGenerator();
                if (!$gen->isValidLabel($label) || in_array($label, app(Settings::class)->reservedSubdomains(), true)) {
                    throw new BlueMapException('That subdomain is not allowed. Use lowercase letters, digits and dashes (not at the start or end).');
                }
            }

            $this->guard()->assertStopped();

            // Hard stop before a row exists: a server without a usable database must not be left with a "failed" install.
            $dbBlocker = InstallPlan::databaseBlocker(app(DatabaseProvisioner::class)->preflight($server, $row?->database_id));
            if ($dbBlocker !== null) {
                throw new BlueMapException($dbBlocker);
            }

            $i = $row ?? new Installation(['server_id' => $server->id, 'steps_done' => [], 'cert_status' => 'none']);
            $i->fill([
                'status' => 'installing', 'failed_step' => null, 'last_error' => null,
                'loader' => $det['loader'], 'mc_version' => $det['mc_version'],
                'jar_dir' => $layout['jar_dir'], 'config_dir' => $layout['config_dir'],
                'allocation_id' => $alloc->id, 'web_port' => $alloc->port,
                'created_by' => $i->created_by ?? $this->user?->id,
            ]);
            if ($i->fqdn === null && $label !== '') {
                $i->subdomain = $label;
            }
            $i->save();

            $this->activity('install', ['loader' => $i->loader, 'mc' => $i->mc_version]);

            return $this->execute($i, $det, (bool) ($options['install_fabric_api'] ?? true));
        });
    }

    public function resume(): array
    {
        return $this->run('resume', self::FILE_RW, function () {
            $i = $this->row();
            if ($i->hasStep('un:start')) {
                throw new BlueMapException('A removal did not finish. Run Uninstall again to finish it, or use Forget NPM objects if Nginx Proxy Manager is gone.');
            }
            if (!in_array($i->status, ['failed', 'installing', 'awaiting_first_start', 'active'], true)) {
                throw new BlueMapException('Nothing to resume.');
            }
            $this->guard()->assertStopped();

            $i->status = 'installing';
            $i->failed_step = null;
            $i->last_error = null;
            $i->save();

            // A failed settings conversion after a jar update is retried here (WIZARDS.md 8.3).
            $from = InstallPlan::pendingMigration($i->steps_done);
            if ($from !== null) {
                $this->migrateSettings($i, $from);
            }

            $det = app(LoaderDetector::class)->forServer($this->server())->detect($i->loader, $i->mc_version);

            // The "without Fabric API" choice isn't stored: a resumed install adds it when it's required and missing.
            return $this->execute($i, $det, true);
        });
    }

    /** Runs the missing steps of the install pipeline (database → jars → config → proxy_host). */
    private function execute(Installation $i, array $det, bool $installFabricApi): array
    {
        $this->step($i, 'database', fn () => $this->stepDatabase($i));
        $this->step($i, 'jars', fn () => $this->stepJars($i, $det, $installFabricApi));
        $this->step($i, 'config', fn () => $this->stepConfig($i));
        $this->step($i, 'proxy_host', fn () => $this->stepProxyHost($i));

        $i->status = $i->maps_finalized ? 'active' : 'awaiting_first_start';
        $i->failed_step = null;
        $i->last_error = null;
        $i->save();

        $needsCert = $i->cert_status !== 'issued';
        $msg = $i->maps_finalized
            ? 'BlueMap is installed. Start the server to begin rendering.'
            : 'BlueMap is installed. Start the server once so BlueMap can detect your worlds, stop it, then click Finish setup.';

        $msg .= ($needsCert ? ' Requesting the HTTPS certificate next.' : '') . $this->noticeSuffix();

        return $this->result(true, $i->status, null, $msg, $needsCert ? 'certificate' : null);
    }

    private function stepDatabase(Installation $i): void
    {
        $server = $this->server();
        $prov = app(DatabaseProvisioner::class);
        $pre = $prov->preflight($server, $i->database_id);
        if (!$pre['ok']) {
            throw new BlueMapException((string) $pre['reason']);
        }
        if ($pre['existing_database_id'] === null) {
            $this->guard()->assertCan($this->user, SubuserPermission::DatabaseCreate);
        }
        $r = $prov->ensure($server, $i->database_id);
        $i->database_id = (int) $r['database']->id;
        $i->db_created_by_plugin = $i->db_created_by_plugin || $r['created'];
        $i->save();
    }

    private function stepJars(Installation $i, array $det, bool $installFabricApi): void
    {
        $this->guard()->assertStopped();
        $fabricNeededLoader = $i->loader === 'fabric';
        $fabricPresent = !$fabricNeededLoader || $det['fabric_api_present'] || !$installFabricApi;

        $build = app(ModrinthClient::class)->bestBlueMap($i->loader, $i->mc_version, $fabricPresent);
        $this->requireBuild($build, $i);
        /** @var array<string, mixed> $bm */
        $bm = $build['bluemap'];

        $this->installBlueMapJar($i, $bm);
        $this->installDriver($i);

        $needFabric = $fabricNeededLoader && !$fabricPresent && ($bm['requires_fabric_api'] ?? false);
        if ($needFabric) {
            if ($build['fabric_api'] === null) {
                throw new BlueMapException("BlueMap needs Fabric API, but no Fabric API build was found for Minecraft {$i->mc_version}.");
            }
            $this->installFabricApi($i, $build['fabric_api']);
        }
    }

    /** @param array<string, mixed> $build BuildChoice */
    private function requireBuild(array $build, Installation $i): void
    {
        if (($build['status'] ?? '') === 'ok' && is_array($build['bluemap'] ?? null)) {
            return;
        }
        throw new BlueMapException($build['message'] ?? match ($build['status'] ?? 'error') {
            'unsupported' => "Only BlueMap versions older than 5 exist for {$i->loader} {$i->mc_version}; they are not supported.",
            'none' => "No BlueMap build exists for {$i->loader} {$i->mc_version}.",
            default => 'Modrinth could not be reached. Try again in a minute.',
        });
    }

    /** @param array<string, mixed> $v ModrinthVersion */
    private function installBlueMapJar(Installation $i, array $v): void
    {
        $files = $this->files();
        $name = (string) $v['file']['filename'];
        ServerFiles::assertFileName($name);
        $dir = $i->jar_dir;
        $target = $dir . '/' . $name;
        $sha1 = (string) ($v['file']['sha1'] ?? '');

        $exists = $files->exists($target);
        $same = $exists && $i->jar_path === $target && $i->jar_sha1 !== null && strcasecmp((string) $i->jar_sha1, $sha1) === 0;

        if (!$same) {
            $stamp = $this->stamp();
            $moved = false;
            if ($exists) {
                $files->backup([$target], $stamp);
                $this->recordBackup($i, $stamp);
                $moved = true;
            }
            try {
                $files->pullVerified((string) $v['file']['url'], $dir, $name, (int) $v['file']['size'], $sha1 !== '' ? $sha1 : null, $this->guard());
            } catch (\Throwable $e) {
                if ($moved) {
                    try {
                        $files->move(ServerFiles::BACKUP_ROOT . '/' . $stamp . '/' . $target, $target);
                    } catch (\Throwable) {
                        // Left in the backup folder; the error below says the install failed.
                    }
                }
                throw $e;
            }
        }

        // Any other BlueMap jar would load twice: move it to the backups.
        $others = [];
        foreach ($files->list($dir) as $e) {
            if ($e['is_file'] && LoaderDetector::isBlueMapJar($e['name']) && $e['name'] !== $name) {
                $others[] = $dir . '/' . $e['name'];
            }
        }
        if ($others !== []) {
            $stamp = $this->stamp();
            $files->backup($others, $stamp);
            $this->recordBackup($i, $stamp);
        }

        $i->jar_path = $target;
        $i->jar_sha1 = $sha1 !== '' ? strtolower($sha1) : null;
        $i->bluemap_version_id = (string) $v['id'];
        $i->bluemap_version_number = (string) $v['version_number'];
        $i->save();
    }

    private function installDriver(Installation $i): void
    {
        $cfg = (array) config('pelican-bluemap.jdbc_driver');
        $name = (string) $cfg['filename'];
        ServerFiles::assertFileName($name);
        $dir = 'bluemap/drivers';
        $path = $dir . '/' . $name;
        $files = $this->files();

        $have = null;
        foreach ($files->list($dir) as $e) {
            if ($e['is_file'] && $e['name'] === $name) {
                $have = $e['size'];
            }
        }
        if ($have === null || $have !== (int) $cfg['size']) {
            $files->ensureDir($dir);
            if ($have !== null) {
                $stamp = $this->stamp();
                $files->backup([$path], $stamp);
                $this->recordBackup($i, $stamp);
            }
            $files->pullVerified((string) $cfg['url'], $dir, $name, (int) $cfg['size'], (string) $cfg['sha1'], $this->guard());
        }

        // An older pinned driver of ours is no longer referenced.
        if ($i->driver_path !== null && $i->driver_path !== $path && str_starts_with($i->driver_path, $dir . '/')) {
            $files->delete($dir, [basename($i->driver_path)]);
        }
        $i->driver_path = $path;
        $i->save();
    }

    /** @param array<string, mixed> $v ModrinthVersion */
    private function installFabricApi(Installation $i, array $v): void
    {
        $files = $this->files();
        $name = (string) $v['file']['filename'];
        ServerFiles::assertFileName($name);
        $target = $i->jar_dir . '/' . $name;
        if (!$files->exists($target)) {
            $files->pullVerified((string) $v['file']['url'], $i->jar_dir, $name, (int) $v['file']['size'], ($v['file']['sha1'] ?? '') !== '' ? (string) $v['file']['sha1'] : null, $this->guard());
        }
        $i->fabric_api_path = $target;
        $i->fabric_api_by_plugin = true;
        $i->save();
    }

    private function stepConfig(Installation $i): void
    {
        $this->guard()->assertStopped();
        $files = $this->files();
        $C = $i->config_dir;

        $db = $i->database;
        if ($db === null) {
            throw new BlueMapException('The map database no longer exists. Retry the install to create it again.');
        }
        $target = app(DatabaseProvisioner::class)->jdbcTarget($db);
        $cfg = (array) config('pelican-bluemap.jdbc_driver');
        $driver = $i->driver_path ?? ('bluemap/drivers/' . $cfg['filename']);
        $port = (int) ($i->web_port ?? 0);
        if ($port < 1) {
            throw new BlueMapException('No web port is recorded for this install. Retry and pick a port.');
        }

        /** @var array<string, ?string> $orig path => original content (null = did not exist) */
        $orig = [];
        /** @var array<string, string> $plan path => new content */
        $plan = [];

        $sqlPath = $C . '/storages/sql.conf';
        $orig[$sqlPath] = $files->read($sqlPath, self::MAX_CONF_BYTES);
        $plan[$sqlPath] = ConfigRenderer::sqlConf($target['url'], $target['user'], $target['password'], $driver, (string) $cfg['class'], 8);

        $corePath = $C . '/core.conf';
        $orig[$corePath] = $files->read($corePath, self::MAX_CONF_BYTES);
        $plan[$corePath] = $orig[$corePath] === null ? ConfigRenderer::newCoreConf() : ConfigRenderer::setTopLevelKey($orig[$corePath], 'accept-download', true);

        $webPath = $C . '/webserver.conf';
        $orig[$webPath] = $files->read($webPath, self::MAX_CONF_BYTES);
        if ($orig[$webPath] === null) {
            $plan[$webPath] = ConfigRenderer::newWebserverConf($port);
        } else {
            $w = ConfigRenderer::setTopLevelKey($orig[$webPath], 'enabled', true);
            $w = ConfigRenderer::setTopLevelKey($w, 'port', $port);
            $plan[$webPath] = ConfigRenderer::setTopLevelKey($w, 'ip', '0.0.0.0');
        }

        // BlueMap skips its default storage configs when storages/ exists (we create it for sql.conf), and the
        // maps it generates on the first start use "file" storage until Finish setup.
        $filePath = $C . '/storages/file.conf';
        if (!$files->exists($filePath)) {
            $orig[$filePath] = null;
            $plan[$filePath] = ConfigRenderer::newFileStorageConf();
        }

        $mapPaths = [];
        foreach ($files->list($C . '/maps') as $e) {
            if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                $p = $C . '/maps/' . $e['name'];
                $text = $files->read($p, self::MAX_CONF_BYTES);
                if ($text === null) {
                    continue;
                }
                $orig[$p] = $text;
                $plan[$p] = ConfigRenderer::setTopLevelKey($text, 'storage', 'sql');
                $mapPaths[] = $p;
            }
        }

        // Back up every pre-existing file we manage, changed or not: Undo install restores from the backup and
        // deletes files without one, so an unchanged original must be in it too. Our own previous sql.conf holds
        // the DB password and is not copied.
        $toBackup = InstallPlan::configBackupPaths($orig);
        if ($toBackup !== []) {
            $stamp = $this->stamp();
            $files->backup($toBackup, $stamp);
            $this->recordBackup($i, $stamp);
        }

        $files->ensureDir($C . '/storages');
        $written = [];
        try {
            foreach ($plan as $path => $content) {
                if ($orig[$path] === $content) {
                    continue;
                }
                $files->writeVerified($path, $content);
                $written[] = $path;
            }
        } catch (\Throwable $e) {
            $this->restoreOriginals($files, $written, $orig);
            throw $e;
        }

        $i->maps_finalized = $mapPaths !== [];
        $i->save();
    }

    /** @param list<string> $paths @param array<string, ?string> $orig */
    private function restoreOriginals(ServerFiles $files, array $paths, array $orig): void
    {
        foreach (array_reverse($paths) as $path) {
            try {
                if ($orig[$path] === null) {
                    $files->delete(dirname($path), [basename($path)]);
                } else {
                    $files->writeVerified($path, $orig[$path]);
                }
            } catch (\Throwable) {
                // Best effort: the originals are also in the backup folder.
            }
        }
    }

    private function stepProxyHost(Installation $i): void
    {
        $picker = app(AllocationPicker::class);
        if ($i->allocation_id === null) {
            throw new BlueMapException('The web port allocation is missing. Undo the install and start again.');
        }
        $alloc = $picker->resolve($this->server(), (int) $i->allocation_id);
        app(ProxyProvisioner::class)->ensureHost($i, $alloc, $i->subdomain);
        $picker->tagNote($alloc);
    }

    // ================================================================== certificate

    public function requestCertificate(): array
    {
        return $this->run('certificate', [SubuserPermission::FileUpdate], function () {
            $i = $this->row();
            if ($i->hasStep('un:start')) {
                throw new BlueMapException('A removal is in progress.');
            }
            $r = app(ProxyProvisioner::class)->ensureCertificate($i);
            if ($r['ok']) {
                $i->markStep('certificate');
                $this->activity('certificate', ['fqdn' => $i->fqdn]);
            }
            $r['status'] = (string) $i->status;
            $r['message'] .= $this->noticeSuffix();

            return $r;
        });
    }

    // ================================================================== finish setup

    public function finishSetup(): array
    {
        return $this->run('finish', self::FILE_RW, function () {
            $i = $this->row();
            $this->assertNotUninstalling($i);
            $this->guard()->assertStopped();
            $files = $this->files();

            $paths = [];
            foreach ($files->list($i->config_dir . '/maps') as $e) {
                if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                    $paths[] = $i->config_dir . '/maps/' . $e['name'];
                }
            }
            if ($paths === []) {
                throw new BlueMapException('No maps exist yet. Start the server once so BlueMap can detect your worlds, stop it, then try again.');
            }

            $orig = [];
            $plan = [];
            foreach ($paths as $p) {
                $text = $files->read($p, self::MAX_CONF_BYTES);
                if ($text === null) {
                    throw new BlueMapException("Could not read {$p}.");
                }
                $orig[$p] = $text;
                $plan[$p] = ConfigRenderer::setTopLevelKey($text, 'storage', 'sql');
            }

            $changed = array_keys(array_filter($plan, fn ($c, $p) => $orig[$p] !== $c, ARRAY_FILTER_USE_BOTH));
            if ($changed !== []) {
                $stamp = $this->stamp();
                $files->backup($changed, $stamp);
                $this->recordBackup($i, $stamp);
            }
            $written = [];
            try {
                foreach ($changed as $p) {
                    $files->writeVerified($p, $plan[$p]);
                    $written[] = $p;
                }
            } catch (\Throwable $e) {
                $this->restoreOriginals($files, $written, $orig);
                throw $e;
            }

            $i->maps_finalized = true;
            if (in_array($i->status, ['awaiting_first_start', 'installing'], true)) {
                $i->status = 'active';
            }
            $i->save();
            $this->activity('finish', ['maps' => count($paths)]);

            return $this->result(true, $i->status, null, 'Setup finished: ' . count($paths) . ' map(s) now use MariaDB storage. Start the server.');
        });
    }

    // ================================================================== update

    public function update(): array
    {
        return $this->run('update', self::FILE_RW, function () {
            $i = $this->row();
            $this->assertNotUninstalling($i);
            if (!in_array($i->status, ['active', 'awaiting_first_start'], true)) {
                throw new BlueMapException('Finish the install before updating.');
            }
            $this->guard()->assertStopped();

            $det = app(LoaderDetector::class)->forServer($this->server())->detect($i->loader, null);
            $mc = $det['mc_version'] ?? $i->mc_version;
            $mcChanged = $mc !== $i->mc_version;
            $oldVersion = $i->bluemap_version_number;

            $fabricAbsent = $i->loader === 'fabric' && $i->fabric_api_by_plugin && $mcChanged;
            $build = app(ModrinthClient::class)->bestBlueMap($i->loader, $mc, !$fabricAbsent);
            $this->requireBuild($build, $i);
            /** @var array<string, mixed> $bm */
            $bm = $build['bluemap'];

            $jarMissing = $i->jar_path === null || !$this->files()->exists($i->jar_path);
            $newJar = $mcChanged || $jarMissing || $i->bluemap_version_id !== (string) $bm['id'];

            if ($mcChanged) {
                $i->mc_version = $mc;
                $i->save();
            }
            if ($newJar) {
                $this->installBlueMapJar($i, $bm);
            }
            $this->installDriver($i);

            if ($fabricAbsent && $build['fabric_api'] !== null) {
                $new = (string) $build['fabric_api']['file']['filename'];
                if ($i->fabric_api_path === null || basename($i->fabric_api_path) !== $new) {
                    if ($i->fabric_api_path !== null && $this->files()->exists($i->fabric_api_path)) {
                        $stamp = $this->stamp();
                        $this->files()->backup([$i->fabric_api_path], $stamp);
                        $this->recordBackup($i, $stamp);
                    }
                    $this->installFabricApi($i, $build['fabric_api']);
                }
            }

            if ($newJar && $oldVersion !== null && $oldVersion !== $i->bluemap_version_number) {
                // Config keys moved between BlueMap versions (docs/WIZARDS.md 8.3); the server is still stopped.
                $this->migrateSettings($i, (string) $oldVersion);
            }

            $this->activity('update', ['from' => $oldVersion, 'to' => $i->bluemap_version_number]);

            return $this->result(true, $i->status, null, $newJar
                ? "Updated BlueMap {$oldVersion} → {$i->bluemap_version_number}."
                : 'BlueMap is already up to date.');
        });
    }

    /**
     * Convert the settings after a jar update. On failure the row is marked failed at step "config" (like any install
     * step) and the conversion is remembered, so Resume retries it; an update retry would not, since the new jar
     * is already in place by then.
     */
    private function migrateSettings(Installation $i, string $oldVersion): void
    {
        $marker = InstallPlan::migrationMarker($oldVersion);
        $mig = app(\Ehaic\PelicanBlueMap\Wizards\WizardService::class)->forServer($this->server(), null)
            ->migrateForVersion($i, $oldVersion, (string) $i->bluemap_version_number);
        if ($mig['ok']) {
            if ($i->hasStep($marker)) {
                $i->unmarkStep($marker);
            }

            return;
        }
        $msg = 'BlueMap was updated, but its settings could not be converted: ' . rtrim((string) $mig['message'], " .") . '. Fix the problem and use Resume to try again.';
        if (!$i->hasStep($marker)) {
            $i->markStep($marker);
        }
        $i->fail('config', $msg);
        throw new StepFailure('config', $msg);
    }

    // ================================================================== change port

    public function changePort(int $allocationId): array
    {
        return $this->run('change_port', self::FILE_RW, function () use ($allocationId) {
            $i = $this->row();
            $this->assertNotUninstalling($i);
            $this->guard()->assertStopped();
            $picker = app(AllocationPicker::class);
            $new = $picker->resolve($this->server(), $allocationId);
            if ((int) $i->allocation_id === (int) $new->id) {
                throw new BlueMapException('That port is already in use for the map.');
            }
            $old = $i->allocation_id !== null ? Allocation::query()->find($i->allocation_id) : null;

            $files = $this->files();
            $path = $i->config_dir . '/webserver.conf';
            $orig = $files->read($path, self::MAX_CONF_BYTES);
            $port = (int) $new->port;
            $content = $orig === null ? ConfigRenderer::newWebserverConf($port) : ConfigRenderer::setTopLevelKey($orig, 'port', $port);

            if ($orig !== null) {
                $stamp = $this->stamp();
                $files->backup([$path], $stamp);
                $this->recordBackup($i, $stamp);
            }
            $files->ensureDir($i->config_dir);
            $files->writeVerified($path, $content);

            try {
                if ($i->npm_host_id !== null) {
                    app(ProxyProvisioner::class)->syncHost($i, $new);
                }
            } catch (\Throwable $e) {
                $this->restoreOriginals($files, [$path], [$path => $orig]);
                throw $e;
            }

            $i->allocation_id = (int) $new->id;
            $i->web_port = $port;
            $i->forward_host = $picker->forwardHost($new);
            $i->save();
            $picker->tagNote($new);
            if ($old !== null) {
                $picker->clearNote($old);
            }
            $this->activity('change_port', ['port' => $port]);

            return $this->result(true, $i->status, null, "The map now uses port {$port}. Start the server for it to take effect." . $this->noticeSuffix());
        });
    }

    // ================================================================== uninstall / rollback

    /** @param array{remove_config: bool, remove_web_data: bool, remove_fabric_api: bool, drop_database: bool, confirm_name: ?string} $options */
    public function uninstall(array $options): array
    {
        $perms = [SubuserPermission::FileDelete, SubuserPermission::FileUpdate];
        if (!empty($options['drop_database'])) {
            $perms[] = SubuserPermission::DatabaseDelete;
        }

        return $this->run('uninstall', $perms, function () use ($options) {
            $i = $this->row();
            if (!empty($options['drop_database']) && trim((string) ($options['confirm_name'] ?? '')) !== (string) $this->server()->name) {
                throw new BlueMapException('Type the server name exactly to confirm deleting the map database.');
            }

            return $this->teardown($i, [
                'remove_config' => (bool) ($options['remove_config'] ?? true),
                'remove_web_data' => (bool) ($options['remove_web_data'] ?? true),
                'remove_fabric_api' => (bool) ($options['remove_fabric_api'] ?? false),
                'drop_database' => (bool) ($options['drop_database'] ?? false),
            ], false);
        });
    }

    /** "Undo install": removes what the row says the plugin created, in reverse order (host → cert → config → jars → DB). */
    public function rollback(bool $dropDatabase): array
    {
        $perms = [SubuserPermission::FileDelete, SubuserPermission::FileUpdate];
        if ($dropDatabase) {
            $perms[] = SubuserPermission::DatabaseDelete;
        }

        return $this->run('rollback', $perms, function () use ($dropDatabase) {
            $i = $this->row();

            return $this->teardown($i, [
                'remove_config' => true, 'remove_web_data' => false,
                'remove_fabric_api' => true, 'drop_database' => $dropDatabase,
            ], true);
        });
    }

    /** @param array{remove_config: bool, remove_web_data: bool, remove_fabric_api: bool, drop_database: bool} $o */
    private function teardown(Installation $i, array $o, bool $rollback): array
    {
        $this->guard()->assertStopped();
        $server = $this->server();

        if (!$i->hasStep('un:start')) {
            $i->steps_done = ['un:start'];
        }
        $i->status = 'uninstalling';
        $i->failed_step = null;
        $i->last_error = null;
        $i->save();
        $this->activity($rollback ? 'rollback' : 'uninstall', $o);

        $files = $this->files();
        $unstep = function (string $name, \Closure $fn) use ($i): void {
            $this->step($i, $name, $fn, 'un:');
        };

        $unstep('proxy_host', fn () => app(ProxyProvisioner::class)->removeHost($i));
        $unstep('certificate', fn () => app(ProxyProvisioner::class)->removeCertificate($i));

        $unstep('jars', function () use ($i, $files, $o) {
            $paths = [$i->jar_path, $i->driver_path];
            if ($o['remove_fabric_api'] && $i->fabric_api_by_plugin) {
                $paths[] = $i->fabric_api_path;
            }
            foreach ($paths as $p) {
                if ($p !== null && $p !== '') {
                    $files->delete(dirname($p) === '.' ? '' : dirname($p), [basename($p)]);
                }
            }
        });

        $unstep('config', function () use ($i, $files, $o, $rollback) {
            $C = $i->config_dir;
            if ($rollback) {
                $this->undoConfig($i, $files);
            } elseif ($o['remove_config'] && $files->exists($C)) {
                $this->backupConfigBeforeDelete($i, $files);
                $files->delete(dirname($C), [basename($C)]);
            }
            if ($o['remove_web_data'] && $files->exists('bluemap')) {
                $files->delete('', ['bluemap']);
            }
        });

        $unstep('database', function () use ($i, $o, $server) {
            if (!$o['drop_database'] || $i->database_id === null) {
                return;
            }
            $db = $i->database;
            if ($db === null) {
                return;
            }
            $ours = $i->db_created_by_plugin || $db->database === 's' . $server->id . '_' . DatabaseProvisioner::DB_SUFFIX;
            if (!$ours) {
                throw new BlueMapException('The map database was not created by this plugin, so it is left alone. Delete it from the Databases tab if you want it gone.');
            }
            app(DatabaseProvisioner::class)->drop($db);
            $i->database_id = null;
            $i->save();
        });

        $this->step($i, 'row', function () use ($i) {
            if ($i->allocation_id !== null) {
                $a = Allocation::query()->find($i->allocation_id);
                if ($a !== null) {
                    app(AllocationPicker::class)->clearNote($a);
                }
            }
            $i->delete();
        }, 'un:', false);

        return $this->result(true, 'none', null, $rollback ? 'The install was undone.' : 'BlueMap was removed from this server.');
    }

    /** Restore backed-up originals of the files we patched; delete the ones we created. */
    private function undoConfig(Installation $i, ServerFiles $files): void
    {
        $C = $i->config_dir;
        $targets = [$C . '/storages/sql.conf', $C . '/core.conf', $C . '/webserver.conf'];
        $fileConf = $files->read($C . '/storages/file.conf', self::MAX_CONF_BYTES);
        if ($fileConf !== null && InstallPlan::isPluginFile($fileConf)) {
            $targets[] = $C . '/storages/file.conf'; // only when we created it
        }
        foreach ($files->list($C . '/maps') as $e) {
            if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                $targets[] = $C . '/maps/' . $e['name'];
            }
        }
        foreach ($targets as $path) {
            $restored = false;
            // Oldest backup first: that is the pre-install original (later stamps may hold our own edits).
            foreach (InstallPlan::restoreOrder($i->backups) as $stamp) {
                $b = ServerFiles::BACKUP_ROOT . '/' . $stamp . '/' . $path;
                $text = $files->read($b, self::MAX_CONF_BYTES);
                if ($text !== null) {
                    $files->writeVerified($path, $text);
                    $restored = true;
                    break;
                }
            }
            if (!$restored && $files->exists($path)) {
                $files->delete(dirname($path), [basename($path)]);
            }
        }
    }

    private function backupConfigBeforeDelete(Installation $i, ServerFiles $files): void
    {
        try {
            $C = $i->config_dir;
            $paths = [];
            foreach ($files->list($C) as $e) {
                if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                    $paths[] = $C . '/' . $e['name'];
                }
            }
            foreach ($files->list($C . '/maps') as $e) {
                if ($e['is_file'] && str_ends_with($e['name'], '.conf')) {
                    $paths[] = $C . '/maps/' . $e['name'];
                }
            }
            if ($paths !== []) {
                $files->backup($paths, $this->stamp());
            }
        } catch (\Throwable $e) {
            Trace::warning('uninstall.backup_failed', ['cause' => get_class($e)]);
        }
    }

    // ================================================================== forget NPM

    public function forgetNpm(): array
    {
        return $this->run('forget_npm', [SubuserPermission::FileUpdate], function () {
            $i = $this->row();
            Trace::warning('npm.forgotten', ['npm_host_id' => $i->npm_host_id, 'npm_cert_id' => $i->npm_cert_id, 'fqdn' => $i->fqdn]);
            $i->npm_host_id = null;
            $i->npm_cert_id = null;
            $i->cert_status = 'none';
            $i->cert_error = null;
            $i->cert_expires_at = null;
            $i->save();
            if ($i->hasStep('un:start')) {
                $i->markStep('un:proxy_host');
                $i->markStep('un:certificate');
            }
            $this->activity('forget_npm', ['fqdn' => $i->fqdn]);

            return $this->result(true, (string) $i->status, null, 'The Nginx Proxy Manager entries were forgotten. Ask an admin to delete ' . ($i->fqdn ?? 'the proxy host') . ' there by hand if it still exists.');
        });
    }

    // ================================================================== plumbing

    /**
     * Permission check, per-server lock, trace id, error mapping. $work returns an OperationResult.
     *
     * @param list<SubuserPermission> $perms
     */
    private function run(string $op, array $perms, \Closure $work): array
    {
        $server = $this->server();
        $this->op = Trace::begin((int) $server->id);
        $this->stamp = null;
        $t0 = hrtime(true);
        $lock = null;
        $locked = false;

        try {
            $this->guard()->assertCan($this->user, ...$perms);

            $lock = Cache::lock('pelican-bluemap:server:' . $server->id, 600);
            $locked = (bool) $lock->get();
            if (!$locked) {
                throw new BlueMapException('Another BlueMap operation is running for this server. Try again in a moment.');
            }
            ignore_user_abort(true);
            @set_time_limit(300);

            Trace::info($op . '.start', ['user' => $this->user?->id]);
            $result = $work();
            Trace::info($op . '.done', ['ok' => $result['ok'], 'status' => $result['status'], 'ms' => (int) round((hrtime(true) - $t0) / 1e6)]);

            return $result;
        } catch (TestAbort $e) {
            Trace::warning($op . '.test_abort', ['after' => $e->step]);

            return $this->result(false, $this->currentStatus(), $e->step, 'Stopped after step "' . $e->step . '" for testing.');
        } catch (StepFailure $e) {
            Trace::warning($op . '.failed', ['step' => $e->step, 'error' => $e->getMessage(), 'cause' => $e->getPrevious() ? get_class($e->getPrevious()) : null]);

            return $this->result(false, $this->currentStatus(), $e->step, $e->getMessage());
        } catch (BlueMapException $e) {
            Trace::warning($op . '.failed', ['error' => $e->getMessage(), 'cause' => $e->getPrevious() ? get_class($e->getPrevious()) : null]);

            return $this->result(false, $this->currentStatus(), null, $e->getMessage());
        } catch (\Throwable $e) {
            report($e);
            Trace::error($op . '.unexpected', ['cause' => get_class($e), 'at' => basename($e->getFile()) . ':' . $e->getLine()]);

            return $this->result(false, $this->currentStatus(), null, $this->unexpectedMessage());
        } finally {
            if ($locked) {
                try {
                    $lock?->release();
                } catch (\Throwable) {
                    // The lock expires on its own.
                }
            }
            Trace::end();
        }
    }

    /**
     * Run one pipeline step unless already done: record the failure on the row, mark success, honour the
     * debug-only abort switch.
     */
    private function step(Installation $i, string $name, \Closure $fn, string $prefix = '', bool $mark = true): void
    {
        if ($i->hasStep($prefix . $name)) {
            return;
        }
        try {
            $fn();
        } catch (\Throwable $e) {
            if ($e instanceof BlueMapException) {
                $msg = $e->getMessage();
            } else {
                report($e);
                Trace::error('step.unexpected', ['step' => $name, 'cause' => get_class($e), 'at' => basename($e->getFile()) . ':' . $e->getLine()]);
                $msg = $this->unexpectedMessage();
            }
            $i->fail($name, $msg);
            throw new StepFailure($name, $msg, $e);
        }
        if ($mark) {
            $i->markStep($prefix . $name);
        }
        if ($prefix === '' && app(Settings::class)->debug() && config('pelican-bluemap.test_abort_after') === $name) {
            // Leave the row like a real interruption that was noticed: "failed" at the next step, so the page
            // offers Retry / Undo install (an "installing" row has no buttons).
            $i->fail(InstallPlan::stepAfter($name), 'Stopped after step "' . $name . '" for testing. Use Retry.');
            throw new TestAbort($name);
        }
    }

    private function unexpectedMessage(): string
    {
        return 'Unexpected error (see the panel log, op=' . ($this->op ?? '?') . ')';
    }

    private function currentStatus(): string
    {
        try {
            return Installation::forServer($this->server())?->status ?? 'none';
        } catch (\Throwable) {
            return 'unknown';
        }
    }

    private function row(): Installation
    {
        return Installation::forServer($this->server()) ?? throw new BlueMapException('BlueMap is not installed on this server.');
    }

    private function assertNotUninstalling(Installation $i): void
    {
        if ($i->hasStep('un:start')) {
            throw new BlueMapException('A removal did not finish. Run Uninstall again to finish it, or use Forget NPM objects if Nginx Proxy Manager is gone.');
        }
    }

    /** Non-fatal proxy notices (e.g. advanced_config refused by NPM) as a message suffix. */
    private function noticeSuffix(): string
    {
        $n = ProxyProvisioner::takeNotices();

        return $n === [] ? '' : ' Note: ' . implode(' ', array_map(fn (string $x) => rtrim($x, '.') . '.', $n));
    }

    /** One backup stamp per operation (UTC). */
    private function stamp(): string
    {
        return $this->stamp ??= gmdate('Ymd-His');
    }

    private function recordBackup(Installation $i, string $stamp): void
    {
        $list = (array) ($i->backups ?? []);
        if (!in_array($stamp, $list, true)) {
            $list[] = $stamp;
            $i->backups = array_slice($list, -10);
            $i->save();
        }
    }

    /** @return array{ok: bool, status: string, step: ?string, message: string, next: ?string} */
    private function result(bool $ok, string $status, ?string $step, string $message, ?string $next = null): array
    {
        return ['ok' => $ok, 'status' => $status, 'step' => $step, 'message' => $message, 'next' => $next];
    }

    /** @param array<string, mixed> $props */
    private function activity(string $event, array $props = []): void
    {
        try {
            Activity::event('server:bluemap.' . $event)->subject($this->server())->property($props)->log();
        } catch (\Throwable) {
            // The audit entry is a nice-to-have; never fail an operation over it.
        }
    }

    private function guard(): ServerGuard
    {
        return app(ServerGuard::class)->forServer($this->server());
    }

    private function files(): ServerFiles
    {
        return app(ServerFiles::class)->forServer($this->server());
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }
}

/** A pipeline step failed; the row already records it. */
final class StepFailure extends BlueMapException
{
    public function __construct(public readonly string $step, string $message, ?\Throwable $previous = null)
    {
        parent::__construct($message, $previous);
    }
}

/** Debug-only: the install was cut off on purpose after a step (BLUEMAP_TEST_ABORT_AFTER). */
final class TestAbort extends \RuntimeException
{
    public function __construct(public readonly string $step)
    {
        parent::__construct('test abort after ' . $step);
    }
}
