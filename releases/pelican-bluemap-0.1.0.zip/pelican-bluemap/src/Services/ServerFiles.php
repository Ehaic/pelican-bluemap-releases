<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Models\Server;
use App\Repositories\Daemon\DaemonFileRepository;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Contracts\Filesystem\FileNotFoundException;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;

/**
 * Thin, verified wrapper over Wings' file API. Paths are server-root relative without a leading slash;
 * this class adds the "/" Wings wants.
 */
class ServerFiles
{
    public const BACKUP_ROOT = '.pelican-bluemap/backups';

    /** Hosts we are willing to have Wings download from (Modrinth CDN, Maven Central). */
    private const ALLOWED_HOSTS = ['cdn.modrinth.com', 'repo1.maven.org'];

    private ?Server $server = null;

    /** @var array<string, true> */
    private array $ensured = [];

    public function forServer(Server $server): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->ensured = [];

        return $new;
    }

    // ------------------------------------------------------------------ read

    /** @return list<array{name: string, size: int, is_file: bool, modified: ?string}> [] when the directory is missing */
    public function list(string $dir): array
    {
        $dir = self::clean($dir);
        try {
            $list = $this->repo()->getDirectory('/' . $dir);
        } catch (RequestException $e) {
            if ($e->response->status() === 404) {
                return [];
            }
            throw $this->wingsError($e);
        } catch (ConnectionException $e) {
            throw $this->wingsError($e);
        }

        if (!is_array($list) || isset($list['error'])) {
            return [];
        }

        $out = [];
        foreach ($list as $e) {
            if (!is_array($e) || !isset($e['name'])) {
                continue;
            }
            $out[] = [
                'name' => (string) $e['name'],
                'size' => (int) ($e['size'] ?? 0),
                'is_file' => (bool) ($e['file'] ?? !($e['directory'] ?? false)),
                'modified' => isset($e['modified']) ? (string) $e['modified'] : null,
            ];
        }

        return $out;
    }

    /** True when the file or directory exists (looked up in its parent's listing). */
    public function exists(string $path): bool
    {
        $path = self::clean($path);
        $parent = dirname($path);
        $name = basename($path);
        foreach ($this->list($parent === '.' ? '' : $parent) as $e) {
            if ($e['name'] === $name) {
                return true;
            }
        }

        return false;
    }

    /** null when the file is missing or larger than $maxBytes. */
    public function read(string $path, int $maxBytes): ?string
    {
        $path = self::clean($path);
        try {
            return (string) $this->repo()->getContent('/' . $path, $maxBytes);
        } catch (FileNotFoundException) {
            return null;
        } catch (\App\Exceptions\Http\Server\FileSizeTooLargeException) {
            return null;
        } catch (\App\Exceptions\Repository\FileNotEditableException) {
            return null;
        } catch (RequestException $e) {
            if ($e->response->status() === 404) {
                return null;
            }
            throw $this->wingsError($e);
        } catch (ConnectionException $e) {
            throw $this->wingsError($e);
        }
    }

    // ------------------------------------------------------------------ write

    public function writeVerified(string $path, string $content): void
    {
        $path = self::clean($path);
        try {
            $this->repo()->putContent('/' . $path, $content);
        } catch (RequestException|ConnectionException $e) {
            throw $this->wingsError($e);
        }

        $back = $this->read($path, max(strlen($content) * 2, 1024 * 1024));
        if ($back !== $content) {
            throw new BlueMapException("Writing {$path} did not verify (the file read back differently). Nothing else was changed.");
        }
    }

    /** Creates each missing segment. */
    public function ensureDir(string $path): void
    {
        $path = self::clean($path);
        if ($path === '' || isset($this->ensured[$path])) {
            return;
        }
        $parent = '/';
        foreach (explode('/', $path) as $segment) {
            try {
                $this->repo()->createDirectory($segment, $parent);
            } catch (\Throwable) {
                // Already exists (Wings answers 400). A real failure shows up when something is written there.
            }
            $parent = rtrim($parent, '/') . '/' . $segment;
        }
        $this->ensured[$path] = true;
    }

    /**
     * Download $url into "$dir/$finalName" through Wings, verified. Writes to ".{finalName}.part" first and only
     * renames once size (and sha1 for files up to max_verify_bytes) match and the server is still stopped.
     */
    public function pullVerified(string $url, string $dir, string $finalName, int $size, ?string $sha1, ServerGuard $guard): void
    {
        $dir = self::clean($dir);
        self::assertFileName($finalName);
        $host = strtolower((string) parse_url($url, PHP_URL_HOST));
        if (!str_starts_with($url, 'https://') || !in_array($host, self::ALLOWED_HOSTS, true)) {
            throw new BlueMapException('Refusing to download from an unexpected address.');
        }

        $tmp = '.' . $finalName . '.part';
        $tmpPath = ($dir === '' ? '' : $dir . '/') . $tmp;
        $finalPath = ($dir === '' ? '' : $dir . '/') . $finalName;

        if ($this->exists($finalPath)) {
            throw new BlueMapException("{$finalPath} already exists; it must be moved away before it is replaced.");
        }
        $this->deleteQuiet($dir, $tmp);

        try {
            Trace::info('files.pull', ['file' => $finalName, 'url' => Trace::safeUrl($url), 'dir' => $dir]);
            try {
                $this->repo()->getHttpClient()
                    ->timeout(max((int) config('panel.guzzle.timeout', 15), 120))
                    ->post("/api/servers/{$this->server()->uuid}/files/pull", [
                        'url' => $url,
                        'root' => '/' . $dir,
                        'file_name' => $tmp,
                        'foreground' => true,
                    ]);
            } catch (RequestException|ConnectionException $e) {
                throw $this->wingsError($e, 'The download failed');
            }

            $got = null;
            foreach ($this->list($dir) as $e) {
                if ($e['name'] === $tmp) {
                    $got = $e['size'];
                }
            }
            if (!$got) {
                throw new BlueMapException("The download of {$finalName} did not produce a file.");
            }
            if ($size > 0 && $got !== $size) {
                throw new BlueMapException("The download of {$finalName} has the wrong size ({$got} bytes, expected {$size}).");
            }

            if ($sha1 !== null && $got <= (int) config('pelican-bluemap.max_verify_bytes', 32 * 1024 * 1024)) {
                $bytes = $this->read($tmpPath, $got + 1024);
                if ($bytes === null || strlen($bytes) !== $got || !hash_equals(strtolower($sha1), sha1($bytes))) {
                    throw new BlueMapException("The download of {$finalName} failed its checksum.");
                }
            }

            // The download can be slow: nobody may have started the server meanwhile.
            $guard->assertStopped();

            try {
                $this->repo()->renameFiles('/', [['from' => '/' . $tmpPath, 'to' => '/' . $finalPath]]);
            } catch (RequestException|ConnectionException $e) {
                throw $this->wingsError($e, 'Could not put the downloaded file in place');
            }
        } catch (\Throwable $e) {
            $this->deleteQuiet($dir, $tmp);
            throw $e;
        }
    }

    /** Wings rename at root "/" (works across directories). */
    public function move(string $from, string $to): void
    {
        try {
            $this->repo()->renameFiles('/', [['from' => '/' . self::clean($from), 'to' => '/' . self::clean($to)]]);
        } catch (RequestException|ConnectionException $e) {
            throw $this->wingsError($e);
        }
    }

    /** @param list<string> $names entries inside $dir; a missing one is fine */
    public function delete(string $dir, array $names): void
    {
        $dir = self::clean($dir);
        $paths = [];
        foreach ($names as $name) {
            if ($name === '' || str_contains($name, '/') || $name === '..') {
                throw new BlueMapException('Refusing to delete a path with unexpected characters.');
            }
            $paths[] = '/' . ($dir === '' ? '' : $dir . '/') . $name;
        }
        if ($paths === []) {
            return;
        }
        try {
            $this->repo()->deleteFiles('/', $paths);
        } catch (RequestException $e) {
            if ($e->response->status() !== 404) {
                throw $this->wingsError($e);
            }
        } catch (ConnectionException $e) {
            throw $this->wingsError($e);
        }
    }

    /**
     * Keep a copy of $paths under .pelican-bluemap/backups/<stamp>/<path>. *.jar files are moved (they are
     * replaced anyway), everything else is copied (read + write). Missing paths are skipped. Returns the backup
     * folder (server-root relative) and prunes old stamps down to backups_keep.
     *
     * @param list<string> $paths
     */
    public function backup(array $paths, string $stamp): string
    {
        if (!preg_match('/^[0-9]{8}-[0-9]{6}(?:-[a-z0-9]{1,6})?$/D', $stamp)) {
            throw new BlueMapException('Invalid backup name.');
        }
        $folder = self::BACKUP_ROOT . '/' . $stamp;
        $this->ensureDir($folder);

        foreach ($paths as $path) {
            $path = self::clean($path);
            if (!$this->exists($path)) {
                continue;
            }
            $dest = $folder . '/' . $path;
            $this->ensureDir(dirname($dest));
            if (str_ends_with(strtolower($path), '.jar')) {
                $this->move($path, $dest);
            } else {
                $content = $this->read($path, 4 * 1024 * 1024);
                if ($content === null) {
                    continue;
                }
                $this->writeVerified($dest, $content);
            }
        }

        $this->prune();

        return $folder;
    }

    private function prune(): void
    {
        $keep = max(1, (int) config('pelican-bluemap.backups_keep', 3));
        $names = array_map(fn ($e) => $e['name'], array_filter($this->list(self::BACKUP_ROOT), fn ($e) => !$e['is_file']));
        sort($names);
        $old = array_slice($names, 0, max(0, count($names) - $keep));
        if ($old !== []) {
            $this->delete(self::BACKUP_ROOT, $old);
        }
    }

    // ------------------------------------------------------------------ helpers

    /** Strips leading/trailing slashes, refuses ".." and control characters. */
    public static function clean(string $path): string
    {
        $path = trim(str_replace('\\', '/', $path), '/');
        if (preg_match('/[\x00-\x1F\x7F]/', $path) || in_array('..', explode('/', $path), true)) {
            throw new BlueMapException('Refusing a path with unexpected characters.');
        }

        return preg_replace('#/+#', '/', $path) ?? $path;
    }

    /** Jar names come from Modrinth / config: no path tricks. */
    public static function assertFileName(string $name): void
    {
        if (!preg_match('/^[A-Za-z0-9._+-]{1,128}\.jar$/D', $name) || str_contains($name, '..') || str_starts_with($name, '.')) {
            throw new BlueMapException('Refusing a file name that is not a plain .jar name.');
        }
    }

    private function deleteQuiet(string $dir, string $name): void
    {
        try {
            $this->delete($dir, [$name]);
        } catch (\Throwable) {
            // Nothing to delete or the node is unreachable: the caller is already failing.
        }
    }

    private function wingsError(\Throwable $e, string $what = 'The server node reported an error'): BlueMapException
    {
        $status = $e instanceof RequestException ? ' (HTTP ' . $e->response->status() . ')' : '';
        Trace::warning('files.wings_error', ['what' => $what, 'cause' => get_class($e), 'status' => $status]);

        return new BlueMapException($what . $status . '. Check that the node is online and try again.', $e);
    }

    private function repo(): DaemonFileRepository
    {
        return (new DaemonFileRepository())->setServer($this->server());
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }
}
