<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Services;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Models\User;
use Ehaic\PelicanBlueMap\Clients\ModrinthClient;
use Ehaic\PelicanBlueMap\Clients\NpmClient;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Support\Settings;
use Ehaic\PelicanBlueMap\Support\Trace;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;

/** Read-only snapshot of everything the BlueMap page shows. Never throws: failing sections become null. */
class StatusService
{
    private const MAX_CONF_BYTES = 1024 * 1024;

    /**
     * @return array<string, mixed> StatusSnapshot (INTERFACES §4.6)
     */
    public function snapshot(Server $server, ?User $user): array
    {
        $guard = app(ServerGuard::class)->forServer($server);
        $files = app(ServerFiles::class)->forServer($server);

        $state = 'missing';
        $conflict = false;
        try {
            $conflict = $server->isInConflictState();
        } catch (\Throwable) {
            // keep false
        }
        if (!$conflict) {
            $state = $guard->state();
        }
        $wings = $state !== 'missing';

        $row = $this->safe(fn () => Installation::forServer($server));
        $managed = $row !== null;

        $preflight = null;
        if (!$managed && $wings && $guard->can($user, SubuserPermission::FileRead)) {
            $preflight = $this->safe(fn () => app(InstallationService::class)->forServer($server, $user)->preflight());
        }
        $detection = $preflight['detection'] ?? null;
        if ($detection === null) {
            // A managed install knows its loader: detecting again could pick another layout (wrong jar/config dir).
            $detection = $wings
                ? ($this->safe(fn () => app(LoaderDetector::class)->forServer($server)->detect($row?->loader)) ?? $this->emptyDetection())
                : $this->emptyDetection();
        }

        $jarName = $row?->jar_path !== null ? basename($row->jar_path) : null;
        $existing = array_map(fn ($j) => $j['name'], $detection['existing_jars']);
        $updateInfo = $managed ? $this->updateInfo($row) : null;

        $bluemap = [
            'installed_version' => $row?->bluemap_version_number,
            'jar_present' => $managed ? ($jarName !== null && in_array($jarName, $existing, true)) : $existing !== [],
            'update' => $updateInfo,
            'mc_mismatch' => $managed && $detection['mc_version'] !== null && LoaderDetector::isConcreteVersion($row->mc_version) && $detection['mc_version'] !== $row->mc_version,
            'driver_present' => (bool) $detection['driver_present'],
            'fabric_api_present' => ($managed ? $row->loader : $detection['loader']) === 'fabric' ? (bool) $detection['fabric_api_present'] : null,
            'unmanaged_jars' => array_values($managed ? array_filter($existing, fn ($n) => $n !== $jarName) : $existing),
        ];

        $maps = $detection['maps'];
        $needsFinish = $managed && $row->status === 'awaiting_first_start' && $maps !== [];

        $log = null;
        if ($wings && $managed) {
            $log = $this->safe(fn () => $files->read('logs/latest.log', (int) config('pelican-bluemap.max_log_bytes', 8 * 1024 * 1024)));
        }
        $health = $managed ? self::healthFromLog((string) $log) : [];
        if ($managed && $row->status === 'failed' && $row->last_error) {
            array_unshift($health, ['level' => 'error', 'line' => (string) $row->last_error, 'hint' => 'Use Retry, or Undo install.']);
        }
        if ($managed && $row->cert_status === 'failed' && $row->cert_error) {
            $health[] = ['level' => 'warning', 'line' => 'Certificate: ' . $row->cert_error, 'hint' => 'The map works on plain HTTP. Use Retry certificate.'];
        }
        if ($managed && !$wings) {
            $health[] = ['level' => 'warning', 'line' => "The server's node could not be reached.", 'hint' => 'File checks are skipped until it is back.'];
        }

        return [
            'server' => ['state' => $state, 'stopped' => $state === 'offline', 'conflict' => $conflict],
            'managed' => $managed,
            'installation_status' => $row?->status,
            'failed_step' => $row?->failed_step,
            'last_error' => $row?->last_error,
            'detection' => $detection,
            'bluemap' => $bluemap,
            'maps' => $maps,
            'maps_finalized' => $managed ? (bool) $row->maps_finalized : false,
            'needs_finish_setup' => $needsFinish,
            'database' => $managed ? $this->databaseInfo($row) : null,
            'web' => $managed ? $this->webInfo($row, $server, $state) : null,
            'health' => $health,
            'render' => $managed && $wings ? $this->renderInfo($files) : null,
            'npm_available' => $this->safe(fn () => app(NpmClient::class)->isAvailable()) ?? false,
            'modrinth_available' => $this->safe(fn () => app(ModrinthClient::class)->isAvailable()) ?? false,
            'wings_available' => $wings,
            'preflight' => $preflight,
        ];
    }

    private function updateInfo(Installation $row): ?array
    {
        try {
            $modrinth = app(ModrinthClient::class);
            if (!$modrinth->isAvailable()) {
                return null;
            }
            $build = $modrinth->bestBlueMap($row->loader, $row->mc_version, true);
            if (($build['status'] ?? '') === 'ok' && is_array($build['bluemap'] ?? null) && (string) $build['bluemap']['id'] !== (string) $row->bluemap_version_id) {
                return $build['bluemap'];
            }
        } catch (\Throwable $e) {
            Trace::debug('status.update_check_failed', ['cause' => get_class($e)]);
        }

        return null;
    }

    /** @return ?array{name: string, jdbc_host: string, jdbc_port: int, panel_connect_ok: ?bool, tables: ?int, error: ?string} */
    private function databaseInfo(Installation $row): ?array
    {
        return $this->safe(function () use ($row) {
            $db = $row->database;
            if ($db === null) {
                return null;
            }
            $prov = app(DatabaseProvisioner::class);
            $t = $prov->jdbcTarget($db);
            $c = $prov->testConnection($db);

            return [
                'name' => (string) $db->database, 'jdbc_host' => $t['host'], 'jdbc_port' => $t['port'],
                'panel_connect_ok' => $c['ok'], 'tables' => $c['tables'], 'error' => $c['error'],
            ];
        });
    }

    private function webInfo(Installation $row, Server $server, string $state): ?array
    {
        return $this->safe(function () use ($row, $server, $state) {
            $picker = app(AllocationPicker::class);
            $alloc = $row->allocation_id !== null ? $server->allocations()->where('id', $row->allocation_id)->first() : null;

            $hostOk = null;
            $hostErr = null;
            $expires = $row->cert_expires_at?->toIso8601String();
            if ($row->npm_host_id !== null && app(NpmClient::class)->isAvailable()) {
                $st = app(ProxyProvisioner::class)->status($row);
                if ($st['host'] !== null) {
                    $online = $st['host']['nginx_online'] ?? null;
                    $hostOk = (bool) ($st['host']['enabled'] ?? true) && $online !== false;
                    $hostErr = $online === false ? (string) ($st['host']['nginx_err'] ?? 'Nginx reports the host as offline.') : null;
                } else {
                    $hostOk = false;
                    $hostErr = $st['error'];
                }
                if (!empty($st['cert']['expires_on'])) {
                    try {
                        $expires = \Illuminate\Support\Carbon::parse((string) $st['cert']['expires_on'])->toIso8601String();
                    } catch (\Throwable) {
                        // keep the stored value
                    }
                }
            }

            $until = (int) Cache::get('pelican-bluemap:cert:cooldown:' . $row->server_id, 0);

            $reach = null;
            if ($state === 'running' && $row->forward_host !== null && $row->web_port !== null) {
                try {
                    $r = Http::connectTimeout(2)->timeout(2)->get('http://' . $row->forward_host . ':' . $row->web_port . '/');
                    $reach = $r->status() < 500;
                } catch (\Throwable) {
                    $reach = false;
                }
            }

            return [
                'url' => $row->url(), 'fqdn' => $row->fqdn,
                'allocation' => $alloc !== null ? $picker->label($alloc) : null,
                'allocation_missing' => $alloc === null,
                'forward' => $row->forward_host !== null && $row->web_port !== null ? $row->forward_host . ':' . $row->web_port : null,
                'host_ok' => $hostOk, 'host_error' => $hostErr,
                'cert_status' => (string) $row->cert_status, 'cert_error' => $row->cert_error,
                'cert_expires_at' => $expires,
                'cert_retry_after' => $until > time() ? gmdate('c', $until) : null,
                'webserver_reachable' => $reach,
            ];
        });
    }

    /** @return ?array{paused: bool} */
    private function renderInfo(ServerFiles $files): ?array
    {
        return $this->safe(function () use ($files) {
            $raw = $files->read('bluemap/pluginState.json', 64 * 1024);
            if ($raw === null) {
                return null;
            }
            $data = json_decode($raw, true);
            // The real key is dashed (docs/WIZARDS.md 1); the camelCase spelling is kept as a fallback for old fixtures.
            $key = is_array($data) ? (array_key_exists('render-threads-enabled', $data) ? 'render-threads-enabled' : (array_key_exists('renderThreadsEnabled', $data) ? 'renderThreadsEnabled' : null)) : null;
            if ($key === null) {
                return null;
            }

            return ['paused' => $data[$key] === false];
        });
    }

    /**
     * The last 15 BlueMap lines of a server log with hints for known problems (D§9). Pure.
     *
     * @return list<array{level: 'info'|'warning'|'error', line: string, hint: ?string}>
     */
    public static function healthFromLog(string $log): array
    {
        if ($log === '') {
            return [];
        }
        $hits = [];
        foreach (preg_split('/\r?\n/', $log) ?: [] as $line) {
            if ($line === '') {
                continue;
            }
            if (stripos($line, 'bluemap') !== false || preg_match('/Communications link failure|Access denied for user|org\.mariadb\.jdbc/i', $line)) {
                $hits[] = $line;
            }
        }
        $out = [];
        foreach (array_slice($hits, -15) as $line) {
            $level = preg_match('/\/(ERROR|FATAL)\]|\bERROR\b|Exception/', $line) ? 'error'
                : (preg_match('/\/WARN\]|\bWARN(ING)?\b/', $line) ? 'warning' : 'info');
            $out[] = ['level' => $level, 'line' => mb_substr(trim($line), 0, 300), 'hint' => self::hintFor($line)];
        }

        return $out;
    }

    private static function hintFor(string $line): ?string
    {
        return match (true) {
            (bool) preg_match('/accept-download/i', $line) => "BlueMap's config was not applied (accept-download is false). Re-run the install step or check core.conf.",
            (bool) preg_match('/storage[^\n]*\b(file)\b[^\n]*(not|missing|unknown|exist)|(not|missing|unknown|exist)[^\n]*storage[^\n]*\bfile\b/i', $line) => 'The maps still point at "file" storage. Stop the server and click Finish setup.',
            (bool) preg_match('/Communications link failure|Access denied|SQLException|JDBC|No suitable driver|ClassNotFoundException[^\n]*(jdbc|mariadb|mysql)|Unable to connect/i', $line) => 'BlueMap cannot use the database: check the database host (it must be reachable from the game container), the credentials, and that the driver jar exists.',
            (bool) preg_match('/Address already in use|BindException/i', $line) => 'The web port is already in use by something else. Use Change web port.',
            default => null,
        };
    }

    /** @return array<string, mixed> */
    private function emptyDetection(): array
    {
        return [
            'loader' => 'unknown', 'loader_source' => 'none', 'mc_version' => null, 'mc_source' => 'none',
            'jar_dir' => null, 'config_dir' => null, 'existing_jars' => [], 'config_exists' => false, 'maps' => [],
            'fabric_api_present' => false, 'driver_present' => false,
        ];
    }

    /** Runs $fn; any throwable becomes null (and a debug trace line). */
    private function safe(\Closure $fn): mixed
    {
        try {
            return $fn();
        } catch (\Throwable $e) {
            Trace::debug('status.section_failed', ['cause' => get_class($e), 'at' => basename($e->getFile()) . ':' . $e->getLine()]);

            return null;
        }
    }
}
