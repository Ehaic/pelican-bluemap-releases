<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Filament\Server\Wizards;

/**
 * Pure: turns a ChangePlan (docs/WIZARDS.md 7.2) into the Review step's HTML.
 *
 * Everything that comes from a file, a setting value or a player name goes through htmlspecialchars: nothing from the
 * files is ever emitted as markup. Layout is stacked text with inline styles (no table wider than two columns, no
 * Tailwind classes: the panel CSS does not contain the plugin's classes).
 */
final class ReviewTable
{
    /** PlanBuilder::requireAck() blocks Apply with this text until the box is ticked. */
    public const ACK_PREFIX = 'Tick "Replace it" to overwrite: ';

    public const MAX_DIFF_LINES = 400;

    private const CONTEXT = 3;

    /** Cell budget of the LCS table; bigger changes show a summary line instead of a line diff. */
    private const MAX_LCS_CELLS = 4_000_000;

    /**
     * Blockers the user can not clear by ticking a box.
     *
     * @param array<string, mixed> $plan
     * @return list<string>
     */
    public static function hardBlockers(array $plan): array
    {
        return array_values(array_filter(
            array_map('strval', (array) ($plan['blockers'] ?? [])),
            static fn (string $b) => !str_starts_with($b, self::ACK_PREFIX)
        ));
    }

    /**
     * @param array<string, mixed> $plan
     * @param array<string, string> $t labels: current_new, nothing, renamed, created, warnings, blockers, after_start, required, optional, new_file
     * @param array<string, string> $postLabels PendingAction action key => text
     */
    public static function summaryHtml(array $plan, array $t, array $postLabels = []): string
    {
        $out = '';
        $ops = (array) ($plan['ops'] ?? []);
        if ($ops === []) {
            $out .= self::p(self::esc($t['nothing'] ?? 'Nothing would change.'));
        }

        $byFile = [];
        foreach ($ops as $op) {
            $byFile[(string) ($op['file'] ?? '')][] = $op;
        }
        foreach ($byFile as $file => $fileOps) {
            $out .= '<p style="margin:.75rem 0 .15rem;font-weight:600;overflow-wrap:anywhere">' . self::esc($file) . '</p>';
            foreach ($fileOps as $op) {
                $out .= self::opLine($op, $t);
            }
        }

        foreach ((array) ($plan['warnings'] ?? []) as $w) {
            $out .= self::p('⚠️ ' . self::esc((string) $w));
        }
        foreach (self::hardBlockers($plan) as $b) {
            $out .= self::p('⛔ ' . self::esc($b));
        }

        $post = (array) ($plan['post_actions'] ?? []);
        if ($post !== []) {
            $out .= '<p style="margin:.75rem 0 .15rem;font-weight:600">' . self::esc($t['after_start'] ?? 'After you start the server') . '</p>';
            foreach ($post as $a) {
                $key = (string) ($a['action'] ?? '');
                $label = $postLabels[$key] ?? $key;
                $map = isset($a['map']) && $a['map'] !== null ? ' · ' . (string) $a['map'] : '';
                $line = '• ' . self::esc($label . $map);
                if (!empty($a['reason'])) {
                    $line .= ' <span style="opacity:.75">' . self::esc((string) $a['reason']) . '</span>';
                }
                $out .= self::p($line);
            }
        }

        return $out;
    }

    /** @param array<string, mixed> $op @param array<string, string> $t */
    private static function opLine(array $op, array $t): string
    {
        $kind = (string) ($op['op'] ?? '');
        $label = (string) ($op['label'] ?? '');
        if ($kind === 'rename') {
            $line = '<strong>' . self::esc($t['renamed'] ?? 'Renamed') . '</strong> ' . self::esc((string) ($op['before'] ?? '')) . ' → ' . self::esc((string) ($op['after'] ?? ''));
        } elseif ($kind === 'create') {
            $line = '<strong>' . self::esc($t['created'] ?? 'New file') . '</strong> ' . self::esc($label);
        } else {
            $before = $op['before'] === null ? '—' : self::short((string) $op['before']);
            $after = $op['after'] === null ? '—' : self::short((string) $op['after']);
            $line = '<strong>' . self::esc($label) . '</strong> ' . self::esc($before) . ' → ' . self::esc($after);
        }

        return '<p style="margin:.15rem 0 .15rem 1rem;overflow-wrap:anywhere">' . $line . '</p>';
    }

    /**
     * Unified line diff of every changed file, monospace, escaped, capped.
     *
     * @param array<string, mixed> $plan
     */
    public static function diffHtml(array $plan, string $noChange = 'No change.', string $truncated = '(diff truncated)'): string
    {
        $lines = [];
        foreach ((array) ($plan['files'] ?? []) as $path => $c) {
            $lines[] = ['h', (string) $path];
            foreach (self::diff($c['before'] ?? null, $c['after'] ?? null) as $l) {
                $lines[] = $l;
            }
        }
        if ($lines === []) {
            return self::p(self::esc($noChange));
        }

        $html = '';
        $n = 0;
        foreach ($lines as [$k, $text]) {
            if (++$n > self::MAX_DIFF_LINES) {
                $html .= '<div>' . self::esc($truncated) . '</div>';
                break;
            }
            $style = match ($k) {
                '+' => 'color:#16a34a',
                '-' => 'color:#dc2626',
                'h' => 'font-weight:600;margin-top:.5rem',
                default => 'opacity:.7',
            };
            $prefix = $k === 'h' ? '' : $k;
            $html .= '<div style="' . $style . '">' . self::esc($prefix . $text) . '</div>';
        }

        return '<div style="font-family:monospace;font-size:.8rem;white-space:pre-wrap;overflow-wrap:anywhere">' . $html . '</div>';
    }

    /**
     * Line diff with context. Returns [kind, text] pairs: kind is ' ', '+', '-' or '~' (hunk gap).
     *
     * @return list<array{0: string, 1: string}>
     */
    public static function diff(?string $before, ?string $after): array
    {
        $a = $before === null ? [] : explode("\n", $before);
        $b = $after === null ? [] : explode("\n", $after);

        $ops = self::lineOps($a, $b);

        // Keep changed lines and CONTEXT lines around them.
        $keep = array_fill(0, count($ops), false);
        foreach ($ops as $i => [$k]) {
            if ($k !== ' ') {
                for ($j = max(0, $i - self::CONTEXT); $j <= min(count($ops) - 1, $i + self::CONTEXT); $j++) {
                    $keep[$j] = true;
                }
            }
        }
        $out = [];
        $gap = false;
        foreach ($ops as $i => $op) {
            if (!$keep[$i]) {
                $gap = true;

                continue;
            }
            if ($gap && $out !== []) {
                $out[] = ['~', '…'];
            }
            $gap = false;
            $out[] = $op;
        }

        return $out;
    }

    /**
     * @param list<string> $a
     * @param list<string> $b
     * @return list<array{0: string, 1: string}>
     */
    private static function lineOps(array $a, array $b): array
    {
        $na = count($a);
        $nb = count($b);
        $pre = 0;
        while ($pre < $na && $pre < $nb && $a[$pre] === $b[$pre]) {
            $pre++;
        }
        $suf = 0;
        while ($suf < $na - $pre && $suf < $nb - $pre && $a[$na - 1 - $suf] === $b[$nb - 1 - $suf]) {
            $suf++;
        }
        $ma = array_slice($a, $pre, $na - $pre - $suf);
        $mb = array_slice($b, $pre, $nb - $pre - $suf);

        $ops = [];
        for ($i = 0; $i < $pre; $i++) {
            $ops[] = [' ', $a[$i]];
        }
        if (count($ma) * count($mb) > self::MAX_LCS_CELLS) {
            foreach ($ma as $l) {
                $ops[] = ['-', $l];
            }
            foreach ($mb as $l) {
                $ops[] = ['+', $l];
            }
        } else {
            foreach (self::lcsOps($ma, $mb) as $op) {
                $ops[] = $op;
            }
        }
        for ($i = $na - $suf; $i < $na; $i++) {
            $ops[] = [' ', $a[$i]];
        }

        return $ops;
    }

    /**
     * @param list<string> $a
     * @param list<string> $b
     * @return list<array{0: string, 1: string}>
     */
    private static function lcsOps(array $a, array $b): array
    {
        return self::walk($a, $b, self::fullTable($a, $b));
    }

    /**
     * @param list<string> $a
     * @param list<string> $b
     * @return list<list<int>>
     */
    private static function fullTable(array $a, array $b): array
    {
        $n = count($a);
        $m = count($b);
        $t = array_fill(0, $n + 1, array_fill(0, $m + 1, 0));
        for ($i = $n - 1; $i >= 0; $i--) {
            for ($j = $m - 1; $j >= 0; $j--) {
                $t[$i][$j] = $a[$i] === $b[$j] ? $t[$i + 1][$j + 1] + 1 : max($t[$i + 1][$j], $t[$i][$j + 1]);
            }
        }

        return $t;
    }

    /**
     * @param list<string> $a
     * @param list<string> $b
     * @param list<list<int>> $t
     * @return list<array{0: string, 1: string}>
     */
    private static function walk(array $a, array $b, array $t): array
    {
        $i = 0;
        $j = 0;
        $n = count($a);
        $m = count($b);
        $out = [];
        while ($i < $n && $j < $m) {
            if ($a[$i] === $b[$j]) {
                $out[] = [' ', $a[$i]];
                $i++;
                $j++;
            } elseif ($t[$i + 1][$j] >= $t[$i][$j + 1]) {
                $out[] = ['-', $a[$i++]];
            } else {
                $out[] = ['+', $b[$j++]];
            }
        }
        while ($i < $n) {
            $out[] = ['-', $a[$i++]];
        }
        while ($j < $m) {
            $out[] = ['+', $b[$j++]];
        }

        return $out;
    }

    private static function short(string $s): string
    {
        $s = trim((string) preg_replace('/\s+/', ' ', $s));

        return mb_strlen($s) > 140 ? mb_substr($s, 0, 137) . '…' : $s;
    }

    private static function p(string $inner): string
    {
        return '<p style="margin:.25rem 0;overflow-wrap:anywhere">' . $inner . '</p>';
    }

    private static function esc(string $s): string
    {
        return htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    }
}
