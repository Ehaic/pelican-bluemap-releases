<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

/** Pure builders for FieldSpec / StepSpec arrays (every key always present, docs/WIZARDS.md 7.2). */
final class Spec
{
    /**
     * @param array<string, mixed> $o any FieldSpec key (help, default, options, min, max, step, required, visible_if, children, max_items, warning, disabled_reason)
     * @return array<string, mixed>
     */
    public static function field(string $name, string $type, string $label, array $o = []): array
    {
        return array_merge([
            'name' => $name, 'type' => $type, 'label' => $label, 'help' => null, 'default' => null, 'options' => null,
            'min' => null, 'max' => null, 'step' => null, 'required' => false, 'visible_if' => null, 'children' => null,
            'max_items' => null, 'warning' => null, 'disabled_reason' => null,
        ], $o);
    }

    /** @param list<array<string, mixed>> $fields @return array<string, mixed> */
    public static function step(string $id, string $title, ?string $description, array $fields): array
    {
        return ['id' => $id, 'title' => $title, 'description' => $description, 'fields' => $fields];
    }

    /** @return array{field: string, in: list<mixed>} */
    public static function visibleIf(string $field, array $in): array
    {
        return ['field' => $field, 'in' => array_values($in)];
    }
}
