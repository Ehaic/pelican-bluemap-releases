<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Models\User;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Models\Installation;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Services\ServerGuard;
use Ehaic\PelicanBlueMap\Support\Trace;
use Ehaic\PelicanBlueMap\Wizards\Contracts\Wizard;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\Support\MaskRenderer;
use Ehaic\PelicanBlueMap\Wizards\Support\NbtWorldBorder;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;
use Illuminate\Support\Facades\Cache;

/** Entry point of the wizards: permissions, lock, context, validation, plan, apply, after-start actions. */
class WizardService
{
    /** Paths whose managed blocks are hashed after an apply (drift / hand-edit detection). */
    private const MANAGED = ['render-mask', 'marker-sets.pelican-pois'];

    private ?Server $server = null;
    private ?User $user = null;

    public function forServer(Server $server, ?User $user): static
    {
        $new = clone $this;
        $new->server = $server;
        $new->user = $user;

        return $new;
    }

    // ------------------------------------------------------------------ read side

    /** @return list<array<string, mixed>> WizardMeta */
    public function catalog(): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();
        $base = $this->baseContext($row);
        $pending = $this->store()->pending($row);
        $state = $this->store()->get($row);
        $out = [];
        foreach ($this->registry()->all() as $id => $w) {
            $meta = $this->metaFor($w, $base, $state);
            $meta['pending'] = count(array_filter($pending, fn ($p) => ($p['wizard'] ?? null) === $id));
            $out[] = $meta;
        }

        return $out;
    }

    /** @return array{meta: array<string, mixed>, steps: list<array<string, mixed>>, values: array<string, mixed>, drift: bool} */
    public function open(string $wizard, ?string $mapId = null): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();
        $w = $this->registry()->get($wizard);
        $ctx = $this->context($row, $w);
        $meta = $w->meta($ctx);
        if (!$meta['available']) {
            throw new BlueMapException((string) $meta['unavailable_reason']);
        }
        $current = $w->current($ctx, $mapId);

        return ['meta' => $meta, 'steps' => $w->steps($ctx, $current), 'values' => $current, 'drift' => $meta['drift']];
    }

    /** @return array<string, mixed> ChangePlan; read-only, works while the server runs */
    public function preview(string $wizard, array $input, array $acks = []): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();
        $w = $this->registry()->get($wizard);

        return $this->planFor($w, $this->context($row, $w), $input, $acks);
    }

    // ------------------------------------------------------------------ write side

    /** @return array<string, mixed> WizardResult */
    public function apply(string $wizard, array $input, string $planHash, array $acks = []): array
    {
        $server = $this->server();
        Trace::begin((int) $server->id);
        $lock = null;
        $locked = false;
        try {
            $guard = $this->guard();
            $guard->assertCan($this->user, SubuserPermission::FileRead, SubuserPermission::FileUpdate);
            $w = $this->registry()->get($wizard);
            $row = $this->installation();

            $lock = Cache::lock('pelican-bluemap:server:' . $server->id, 600);
            $locked = (bool) $lock->get();
            if (!$locked) {
                throw new BlueMapException('Another BlueMap operation is running for this server. Try again in a moment.');
            }
            ignore_user_abort(true);
            @set_time_limit(300);

            $guard->assertStopped();
            $ctx = $this->context($row, $w);
            $meta = $w->meta($ctx);
            if (!$meta['available']) {
                throw new BlueMapException((string) $meta['unavailable_reason']);
            }
            $plan = $this->planFor($w, $ctx, $input, $acks);
            if ($plan['blockers'] !== []) {
                return $this->fail($wizard, implode(' ', $plan['blockers']));
            }
            if (!hash_equals((string) $plan['plan_hash'], $planHash)) {
                return $this->fail($wizard, 'Files changed since you reviewed; review again.');
            }
            foreach ($plan['files'] as $c) {
                if ($c['before'] === null) {
                    $guard->assertCan($this->user, SubuserPermission::FileCreate);
                    break;
                }
            }

            $result = $this->edit()->apply($row, $plan);
            if ($result['ok'] && $plan['files'] !== []) {
                $this->record($row, $wizard, $input, $plan, $ctx, $result);
                $actions = $plan['post_actions'];
                if ($actions !== []) {
                    $this->store()->addPending($row, $actions);
                }
            }
            Trace::info('wizard.apply', ['wizard' => $wizard, 'ok' => $result['ok'], 'restored' => $result['restored'], 'files' => count($plan['files'])]);

            return $result;
        } catch (BlueMapException $e) {
            return $this->fail($wizard, $e->getMessage());
        } catch (\Throwable $e) {
            report($e);
            Trace::error('wizard.unexpected', ['wizard' => $wizard, 'cause' => get_class($e)]);

            return $this->fail($wizard, 'Something went wrong. Check the panel log (search for pelican-bluemap).');
        } finally {
            if ($locked) {
                try {
                    $lock?->release();
                } catch (\Throwable) {
                }
            }
            Trace::end();
        }
    }

    /** @return list<array<string, mixed>> PendingAction */
    public function pending(): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);

        return $this->store()->pending($this->installation());
    }

    /** @return array<string, mixed> OperationResult */
    public function runPending(string $actionId): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::ControlConsole);
        $row = $this->installation();
        foreach ($this->store()->pending($row) as $a) {
            if ($a['id'] === $actionId) {
                $r = $this->console()->send((string) $a['action'], $a['map'] ?? null, $a['storage'] ?? null);
                if ($r['ok']) {
                    $this->store()->removePending($row, $actionId);
                }

                return $r;
            }
        }

        return ['ok' => false, 'status' => (string) $row->status, 'step' => null, 'message' => 'That action is no longer pending.', 'next' => null];
    }

    public function dismissPending(string $actionId): void
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();
        $this->store()->removePending($row, $actionId);
    }

    /** @return list<array<string, mixed>> MapInfo of every map file (the render wizard maps a disabled map to its storage) */
    public function maps(): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);

        return $this->edit()->listMaps($this->installation());
    }

    /** @return list<string> wizard backup folders, newest first */
    public function backups(): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $this->installation();

        return $this->edit()->listBackups();
    }

    /**
     * Restore every file of one wizard backup. Same rules as apply(): permissions, per-server lock, stopped server,
     * and the stamp must be one of backups().
     *
     * @return array<string, mixed> WizardResult
     */
    public function restoreBackup(string $stamp): array
    {
        $server = $this->server();
        Trace::begin((int) $server->id);
        $lock = null;
        $locked = false;
        try {
            $guard = $this->guard();
            $guard->assertCan($this->user, SubuserPermission::FileRead, SubuserPermission::FileUpdate);
            $this->installation();
            if (!in_array($stamp, $this->edit()->listBackups(), true)) {
                throw new BlueMapException('That backup does not exist.');
            }
            $lock = Cache::lock('pelican-bluemap:server:' . $server->id, 600);
            $locked = (bool) $lock->get();
            if (!$locked) {
                throw new BlueMapException('Another BlueMap operation is running for this server. Try again in a moment.');
            }
            ignore_user_abort(true);
            @set_time_limit(300);
            $guard->assertStopped();
            $result = $this->edit()->restoreBackup($stamp);
            Trace::info('wizard.restore', ['backup' => $stamp, 'ok' => $result['ok'], 'files' => count($result['written'] ?? [])]);

            return $result;
        } catch (BlueMapException $e) {
            return $this->fail('restore', $e->getMessage());
        } catch (\Throwable $e) {
            report($e);
            Trace::error('wizard.restore_failed', ['cause' => get_class($e)]);

            return $this->fail('restore', 'Something went wrong. Check the panel log (search for pelican-bluemap).');
        } finally {
            if ($locked) {
                try {
                    $lock?->release();
                } catch (\Throwable) {
                }
            }
            Trace::end();
        }
    }

    /** @return array<string, mixed> OperationResult */
    public function runConsole(string $action, ?string $mapId = null, ?string $storage = null): array
    {
        return $this->console()->send($action, $mapId, $storage);
    }

    /** @return array<string, mixed> RenderProgressInfo */
    public function progress(): array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();

        return app(RenderProgress::class)->forServer($this->server())->snapshot($row, $this->edit()->listMaps($row));
    }

    /** @return ?array{center_x: float, center_z: float, size: float} */
    public function readWorldBorder(string $mapId): ?array
    {
        $this->guard()->assertCan($this->user, SubuserPermission::FileRead);
        $row = $this->installation();
        $ctx = $this->baseContext($row);
        $map = null;
        foreach ($ctx['maps'] as $m) {
            if ($m['id'] === $mapId) {
                $map = $m;
            }
        }
        if ($map === null) {
            return null;
        }
        $files = app(ServerFiles::class)->forServer($this->server());
        foreach (array_unique(array_filter([(string) $map['world'], (string) $ctx['level_name']])) as $world) {
            if (preg_match('#^[A-Za-z0-9 _./-]{1,128}$#', $world) !== 1 || str_contains($world, '..')) {
                continue;
            }
            $raw = $files->read(trim($world, '/') . '/level.dat', 4 * 1024 * 1024);
            $b = $raw === null ? null : NbtWorldBorder::read($raw);
            if ($b !== null) {
                return $b;
            }
        }

        return null;
    }

    /**
     * Called by InstallationService::update() after the jar swap (server stopped, lock held by the caller).
     *
     * @return array<string, mixed> WizardResult
     */
    public function migrateForVersion(Installation $i, string $oldVersion, string $newVersion): array
    {
        try {
            $this->guard()->assertStopped();
            $old = BlueMapVersion::parse($oldVersion);
            $new = BlueMapVersion::parse($newVersion);
            if ($old === null || $new === null) {
                return $this->fail('migrate', 'Unknown BlueMap version, nothing migrated.', true);
            }
            $ctx = $this->edit()->loadContext($i, []);
            $ctx['version'] = $new;
            $paths = array_column($ctx['maps'], 'file');
            $paths[] = $ctx['config_dir'] . '/core.conf';
            $paths[] = $ctx['config_dir'] . '/plugin.conf';
            $ctx = $this->edit()->withFiles($ctx, $paths);
            $plan = self::migrationPlan($ctx, $old, $new);
            if ($plan['blockers'] !== []) {
                return $this->fail('migrate', implode(' ', $plan['blockers']), true);
            }
            $r = $this->edit()->apply($i, $plan);
            $r['wizard'] = 'migrate';
            if ($r['ok'] && $plan['files'] !== []) {
                Trace::info('wizard.migrate', ['from' => $oldVersion, 'to' => $newVersion, 'files' => count($plan['files'])]);
            }

            return $r;
        } catch (BlueMapException $e) {
            return $this->fail('migrate', $e->getMessage(), true);
        }
    }

    /**
     * Pure (given the loaded files): the config changes a BlueMap version jump needs (docs/WIZARDS.md 8.3).
     *
     * @param array<string, mixed> $ctx with version = the NEW version
     * @param array{raw: string, major: int, minor: int} $old
     * @param array{raw: string, major: int, minor: int} $new
     * @return array<string, mixed> ChangePlan
     */
    public static function migrationPlan(array $ctx, array $old, array $new): array
    {
        $b = new PlanBuilder($ctx, 'migrate');
        $legacy = ['min-x', 'max-x', 'min-z', 'max-z', 'min-y', 'max-y'];

        if ($old['minor'] < 11 && $new['minor'] >= 11) {
            foreach ($ctx['maps'] as $m) {
                $file = $m['file'];
                if (($ctx['files'][$file] ?? null) === null) {
                    continue;
                }
                try {
                    $doc = HoconDocument::parse((string) $ctx['files'][$file]);
                } catch (\Throwable) {
                    $b->block(basename($file) . ' can not be edited safely, so it can not be converted to BlueMap ' . $new['raw'] . '.');
                    continue;
                }
                $set = [];
                foreach ($legacy as $k) {
                    if ($doc->has($k) && $doc->kind($k) === 'scalar' && is_int($doc->get($k))) {
                        $set[$k] = (int) $doc->get($k);
                    }
                }
                if ($set === []) {
                    continue;
                }
                $nether = str_ends_with((string) $m['dimension'], 'the_nether');
                $area = ['mode' => 'whole', 'nether_ceiling' => false];
                if ($nether && ($set['max-y'] ?? null) === 90) {
                    $area['nether_ceiling'] = true;
                    unset($set['max-y']);
                }
                if ($set !== []) {
                    $area['mode'] = 'box';
                    foreach (['min_x' => 'min-x', 'max_x' => 'max-x', 'min_z' => 'min-z', 'max_z' => 'max-z', 'min_y' => 'min-y', 'max_y' => 'max-y'] as $f => $k) {
                        $area[$f] = $set[$k] ?? null;
                    }
                }
                $mask = MaskRenderer::renderMask($area, $new)['block'] ?? null;
                $keepMask = $doc->has('render-mask') && !MaskRenderer::isTemplateMask((string) $doc->raw('render-mask'));
                if ($mask !== null && !$keepMask) {
                    $b->upsert($file, 'render-mask', new Hocon\HoconRaw($mask), basename($file) . ' · render-mask');
                } elseif ($keepMask) {
                    $b->warn(basename($file) . ' already had a custom render-mask; the old area limits were commented out, not converted.');
                }
                foreach ($legacy as $k) {
                    $b->commentOut($file, $k, 'converted to render-mask by Pelican BlueMap', basename($file) . ' · ' . $k);
                }
            }
        }

        if ($old['minor'] <= 20 && $new['minor'] >= 21) {
            $plugin = $ctx['config_dir'] . '/plugin.conf';
            $core = $ctx['config_dir'] . '/core.conf';
            if (($ctx['files'][$plugin] ?? null) !== null && ($ctx['files'][$core] ?? null) !== null) {
                try {
                    $pd = HoconDocument::parse((string) $ctx['files'][$plugin]);
                    foreach (['update-cooldown', 'full-update-interval'] as $k) {
                        if ($pd->has($k) && is_int($pd->get($k))) {
                            $cd = $b->doc($core);
                            $val = $pd->get($k);
                            if (!$cd->has($k) || $cd->get($k) !== $val) {
                                $b->upsert($core, $k, $val, 'core.conf · ' . $k);
                            }
                            $b->commentOut($plugin, $k, 'moved to core.conf by Pelican BlueMap', 'plugin.conf · ' . $k);
                        }
                    }
                } catch (\Throwable) {
                    $b->block('core.conf or plugin.conf can not be edited safely, so the moved settings were not migrated.');
                }
            }
        }

        return $b->build();
    }

    // ------------------------------------------------------------------ internals

    /** @return array<string, mixed> */
    private function planFor(Wizard $w, array $ctx, array $input, array $acks): array
    {
        $meta = $w->meta($ctx);
        $empty = ['wizard' => $w->id(), 'ops' => [], 'files' => [], 'plan_hash' => sha1('empty'), 'warnings' => [], 'blockers' => [], 'requires_overwrite_ack' => [], 'post_actions' => []];
        if (!$meta['available']) {
            $empty['blockers'][] = (string) $meta['unavailable_reason'];

            return $empty;
        }
        $errors = $w->validate($ctx, $input);
        if ($errors !== []) {
            foreach ($errors as $field => $msg) {
                $empty['blockers'][] = $msg;
            }

            return $empty;
        }
        $plan = $w->plan($ctx, $input, $acks);
        if (!empty($ctx['server_running']) && $meta['kind'] === 'config') {
            $plan['warnings'][] = 'The server is running. Stop it before you apply.';
        }

        return $plan;
    }

    /** @param array<string, mixed> $state @return array<string, mixed> */
    private function metaFor(Wizard $w, array $base, array $state): array
    {
        $ctx = $this->edit()->withFiles($base, $w->files($base));
        $ctx['state'] = $state[$w->id()] ?? null;

        return $w->meta($ctx);
    }

    /** @return array<string, mixed> */
    private function context(Installation $row, Wizard $w): array
    {
        $base = $this->baseContext($row);
        $ctx = $this->edit()->withFiles($base, $w->files($base));
        $ctx['state'] = $this->store()->get($row)[$w->id()] ?? null;

        return $ctx;
    }

    /** @return array<string, mixed> */
    private function baseContext(Installation $row): array
    {
        $ctx = $this->edit()->loadContext($row, []);
        $ctx['is_root_admin'] = (bool) ($this->user?->isRootAdmin() ?? false);
        $ctx['server_running'] = $this->guard()->state() === 'running';
        if (!($ctx['version']['major'] ?? 0)) {
            $ctx['version'] = ['raw' => (string) $row->bluemap_version_number, 'major' => 0, 'minor' => 0];
        }

        return $ctx;
    }

    private function installation(): Installation
    {
        $row = Installation::forServer($this->server()) ?? throw new BlueMapException('BlueMap is not installed on this server.');
        if ($row->status !== 'active' || !$row->maps_finalized) {
            throw new BlueMapException('Finish the BlueMap install first.');
        }

        return $row;
    }

    /** @param array<string, mixed> $plan @param array<string, mixed> $ctx @param array<string, mixed> $result */
    private function record(Installation $row, string $wizard, array $input, array $plan, array $ctx, array $result): void
    {
        $files = [];
        $blocks = [];
        foreach ($plan['files'] as $path => $c) {
            if ($c['after'] === null) {
                continue;
            }
            $files[$path] = sha1((string) $c['after']);
            if (str_ends_with($path, '.conf')) {
                try {
                    $d = HoconDocument::parse((string) $c['after']);
                    foreach (self::MANAGED as $p) {
                        if ($d->has($p)) {
                            $blocks[$path . '#' . $p] = sha1((string) $d->raw($p));
                        }
                    }
                } catch (\Throwable) {
                }
            }
        }
        // Files of this wizard that were not touched keep their current hash, so the drift check stays quiet.
        $w = $this->registry()->get($wizard);
        foreach ($w->files($ctx) as $p) {
            if (!str_ends_with($p, '/') && !isset($files[$p]) && ($ctx['files'][$p] ?? null) !== null && !array_key_exists($p, $plan['files'])) {
                $files[$p] = sha1((string) $ctx['files'][$p]);
            }
        }
        $old = $ctx['state'] ?? [];
        // Managed blocks of untouched maps stay known.
        foreach ((array) ($old['blocks'] ?? []) as $k => $h) {
            $blocks[$k] ??= $h;
        }
        $values = $input;
        unset($values['known_players']);
        if (isset($input['map']) && in_array($wizard, ['markers', 'area', 'detail'], true)) {
            $values = (array) ($old['values'] ?? []);
            $values[(string) $input['map']] = $input;
        }
        $this->store()->put($row, $wizard, [
            'applied_at' => gmdate('c'), 'applied_by' => $this->user?->id, 'bluemap_version' => (string) $ctx['version']['raw'],
            'values' => $values, 'files' => $files, 'blocks' => $blocks, 'backup' => (string) $result['backup'],
        ]);
    }

    /** @return array<string, mixed> WizardResult */
    private function fail(string $wizard, string $message, bool $unused = false): array
    {
        return ['ok' => false, 'message' => $message, 'wizard' => $wizard, 'backup' => null, 'written' => [], 'restored' => false, 'post_actions' => []];
    }

    private function server(): Server
    {
        return $this->server ?? throw new \LogicException('Call forServer() first.');
    }

    private function guard(): ServerGuard
    {
        return app(ServerGuard::class)->forServer($this->server());
    }

    private function edit(): ConfigEditService
    {
        return app(ConfigEditService::class)->forServer($this->server());
    }

    private function store(): WizardStateStore
    {
        return app(WizardStateStore::class);
    }

    private function registry(): WizardRegistry
    {
        return app(WizardRegistry::class);
    }

    private function console(): WizardConsole
    {
        return app(WizardConsole::class)->forServer($this->server(), $this->user);
    }
}
