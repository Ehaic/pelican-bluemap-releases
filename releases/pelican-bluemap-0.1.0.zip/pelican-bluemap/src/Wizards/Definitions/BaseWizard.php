<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\BlueMapVersion;
use Ehaic\PelicanBlueMap\Wizards\Contracts\Wizard;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;

/** Shared helpers of the wizard definitions. Pure: everything comes from the WizardContext. */
abstract class BaseWizard implements Wizard
{
    /** @var array<string, ?HoconDocument> */
    private array $docCache = [];

    abstract protected function title(): string;

    abstract protected function description(): string;

    abstract protected function icon(): string;

    protected function kind(): string
    {
        return 'config';
    }

    /** Extra availability rule on top of "BlueMap 5.x known". */
    protected function unavailableReason(array $ctx): ?string
    {
        return null;
    }

    public function files(array $ctx): array
    {
        return [];
    }

    public function meta(array $ctx): array
    {
        $reason = $this->versionReason($ctx) ?? $this->unavailableReason($ctx);
        $state = $ctx['state'] ?? null;
        $drift = false;
        if (is_array($state)) {
            foreach ((array) ($state['files'] ?? []) as $path => $sha) {
                if (array_key_exists($path, $ctx['files'] ?? []) && ($ctx['files'][$path] === null || sha1((string) $ctx['files'][$path]) !== $sha)) {
                    $drift = true;
                }
            }
        }

        return [
            'id' => $this->id(), 'title' => $this->title(), 'description' => $this->description(), 'icon' => $this->icon(),
            'kind' => $this->kind(), 'available' => $reason === null, 'unavailable_reason' => $reason,
            'last_applied_at' => is_array($state) ? ($state['applied_at'] ?? null) : null, 'drift' => $drift, 'pending' => 0,
        ];
    }

    protected function versionReason(array $ctx): ?string
    {
        $v = $ctx['version'] ?? null;
        if (!is_array($v) || ($v['major'] ?? 0) !== 5) {
            return 'Unknown BlueMap version, run Update first.';
        }

        return null;
    }

    // ------------------------------------------------------------------ context helpers

    /** @return array{raw: string, major: int, minor: int} */
    protected function ver(array $ctx): array
    {
        return $ctx['version'];
    }

    protected function atLeast(array $ctx, int $minor): bool
    {
        return BlueMapVersion::atLeast($ctx['version'], $minor);
    }

    protected function configFile(array $ctx, string $name): string
    {
        return rtrim((string) $ctx['config_dir'], '/') . '/' . $name;
    }

    /** Parsed document of a loaded file, null when missing or unparseable. */
    protected function doc(array $ctx, string $path): ?HoconDocument
    {
        $t = $ctx['files'][$path] ?? null;
        if ($t === null) {
            return null;
        }
        // Keyed by content: one wizard instance serves many contexts (registry is reused), so a path alone would go stale.
        $key = $path . "\0" . md5($t);
        if (!array_key_exists($key, $this->docCache)) {
            if (count($this->docCache) > 64) {
                $this->docCache = [];
            }
            try {
                $this->docCache[$key] = HoconDocument::parse($t);
            } catch (\Throwable) {
                $this->docCache[$key] = null;
            }
        }

        return $this->docCache[$key];
    }

    /** Path of the file a catalog key lives in for this version (null = unsupported / needs a map id). */
    protected function pathOf(array $ctx, string $key, ?string $mapId = null): ?string
    {
        $kind = KeyCatalog::fileKind($key, $ctx['version']);
        if ($kind === null) {
            return null;
        }
        if ($kind === 'lang') {
            return rtrim((string) $ctx['webroot'], '/') . '/lang/settings.conf';
        }
        if ($kind === 'state') {
            return rtrim((string) $ctx['data_dir'], '/') . '/pluginState.json';
        }

        return KeyCatalog::locate($key, $ctx['version'], (string) $ctx['config_dir'], $mapId === null ? null : $mapId);
    }

    /** Current value of a catalog key (HOCON files only) or the BlueMap default. */
    protected function keyValue(array $ctx, string $key, ?string $mapId = null): mixed
    {
        $k = KeyCatalog::KEYS[$key];
        $file = $this->pathOf($ctx, $key, $mapId);
        $doc = $file === null ? null : $this->doc($ctx, $file);
        if ($doc !== null && $doc->has($k['path'])) {
            return $doc->get($k['path']);
        }

        return $k['default'];
    }

    protected function supports(array $ctx, string $key): bool
    {
        return KeyCatalog::supports($key, $ctx['version']);
    }

    /** @return list<array<string, mixed>> MapInfo */
    protected function maps(array $ctx): array
    {
        return (array) ($ctx['maps'] ?? []);
    }

    /** @return list<array<string, mixed>> */
    protected function enabledMaps(array $ctx): array
    {
        return array_values(array_filter($this->maps($ctx), fn (array $m) => $m['enabled']));
    }

    /** @return array<string, mixed>|null */
    protected function mapById(array $ctx, ?string $id): ?array
    {
        foreach ($this->maps($ctx) as $m) {
            if ($m['id'] === $id) {
                return $m;
            }
        }

        return null;
    }

    /** The map a one-map wizard works on: the asked one, else the first enabled. */
    protected function pickMap(array $ctx, ?string $mapId): ?array
    {
        return $this->mapById($ctx, $mapId) ?? ($this->enabledMaps($ctx)[0] ?? null);
    }

    /** @return array<string, string> id => "Name (dimension)" for the map select */
    protected function mapOptions(array $ctx, bool $enabledOnly = true): array
    {
        $o = [];
        foreach ($enabledOnly ? $this->enabledMaps($ctx) : $this->maps($ctx) as $m) {
            $o[$m['id']] = ($m['name'] ?? $m['id']) . ($m['dimension'] !== null ? ' (' . $m['dimension'] . ')' : '');
        }

        return $o;
    }

    /** "minecraft:the_nether" -> "the_nether". */
    protected static function dimKey(?string $dimension): string
    {
        $d = (string) $dimension;

        return str_starts_with($d, 'minecraft:') ? substr($d, 10) : $d;
    }

    protected function builder(array $ctx): PlanBuilder
    {
        return new PlanBuilder($ctx, $this->id());
    }

    /** @param array<string, string> $errors */
    protected static function err(array &$errors, string $field, string $msg): void
    {
        if (!isset($errors[$field])) {
            $errors[$field] = $msg;
        }
    }

    /** Compare for "did this change" without float/int/string noise. */
    protected static function same(mixed $a, mixed $b): bool
    {
        if (is_numeric($a) && is_numeric($b)) {
            return (float) $a === (float) $b;
        }
        if (is_array($a) && is_array($b)) {
            $a = array_map('strval', $a);
            $b = array_map('strval', $b);
            sort($a);
            sort($b);

            return $a === $b;
        }

        return $a === $b;
    }

    /** Rows of a repeater input as list of arrays. */
    protected static function rows(mixed $v): array
    {
        return is_array($v) ? array_values(array_filter($v, 'is_array')) : [];
    }
}
