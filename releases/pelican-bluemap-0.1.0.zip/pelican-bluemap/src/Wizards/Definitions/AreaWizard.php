<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconRaw;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\MaskRenderer;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.2 Render area & world border (one map per run). */
final class AreaWizard extends BaseWizard
{
    private const LEGACY = ['min-x', 'max-x', 'min-z', 'max-z', 'min-y', 'max-y'];
    private const EXPLORED = [0 => 'Off (render everything)', 1200 => '1 minute of play nearby', 12000 => '10 minutes of play nearby', 72000 => '1 hour of play nearby'];
    private const LIMIT = 29999984;

    public function id(): string
    {
        return 'area';
    }

    protected function title(): string
    {
        return 'Render area & world border';
    }

    protected function description(): string
    {
        return 'Render only inside the world border or a box or circle, hide secret areas and drop the nether ceiling.';
    }

    protected function icon(): string
    {
        return 'tabler-border-corners';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        return $this->enabledMaps($ctx) === [] ? 'No enabled map exists yet.' : null;
    }

    public function files(array $ctx): array
    {
        return array_column($this->maps($ctx), 'file');
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $m = $this->pickMap($ctx, $mapId);
        $v = [
            'map' => $m['id'] ?? null, 'mode' => 'whole', 'cx' => 0, 'cz' => 0, 'size' => 10000, 'radius' => 5000,
            'min_x' => null, 'max_x' => null, 'min_z' => null, 'max_z' => null, 'nether_ceiling' => false, 'hide' => [],
            'explored' => 0, 'render_edges' => true, 'edge_light_strength' => 15, 'custom_mask' => false,
        ];
        $doc = $m === null ? null : $this->doc($ctx, $m['file']);
        if ($m === null || $doc === null) {
            return $v;
        }
        $nether = self::dimKey($m['dimension']) === 'the_nether';
        if ($this->atLeast($ctx, 11)) {
            if ($doc->has('render-mask')) {
                $raw = (string) $doc->raw('render-mask');
                $a = MaskRenderer::parseMask($raw);
                if ($a === null) {
                    $v['custom_mask'] = true;
                } else {
                    $v['mode'] = $a['mode'];
                    $v['nether_ceiling'] = $a['nether_ceiling'];
                    $v['hide'] = $a['hide'];
                    foreach (['cx', 'cz', 'radius', 'min_x', 'max_x', 'min_z', 'max_z'] as $k) {
                        if (isset($a[$k])) {
                            $v[$k] = $a[$k];
                        }
                    }
                }
            }
        } else {
            $g = fn (string $k) => $doc->has($k) && is_int($doc->get($k)) ? $doc->get($k) : null;
            if ($g('min-x') !== null && $g('max-x') !== null && $g('min-z') !== null && $g('max-z') !== null) {
                $v['mode'] = 'box';
                $v['min_x'] = $g('min-x');
                $v['max_x'] = $g('max-x');
                $v['min_z'] = $g('min-z');
                $v['max_z'] = $g('max-z');
            }
            $v['nether_ceiling'] = $nether && $g('max-y') === 90;
        }
        $v['explored'] = (int) $this->docValue($doc, 'min-inhabited-time', 0);
        $v['render_edges'] = (bool) $this->docValue($doc, 'render-edges', true);
        $v['edge_light_strength'] = (int) $this->docValue($doc, 'edge-light-strength', 15);

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $new = $this->atLeast($ctx, 11);
        $modes = ['whole' => 'Whole world', 'square' => 'World border (square)', 'box' => 'Box'];
        if ($new) {
            $modes = ['whole' => 'Whole world', 'square' => 'World border (square)', 'circle' => 'Circle', 'box' => 'Box'];
        }
        $c = $this->pickMap($ctx, $current['map'] ?? null);
        $nether = $c !== null && self::dimKey($c['dimension']) === 'the_nether';
        $vi = fn (array $in) => Spec::visibleIf('mode', $in);

        $fields = [
            Spec::field('map', 'map', 'Map', ['options' => $this->mapOptions($ctx), 'required' => true, 'default' => $current['map'] ?? null]),
        ];
        if ($new && ($current['custom_mask'] ?? false)) {
            $fields[0]['warning'] = 'This map has a custom render-mask. Saving here replaces it (a backup is kept); you will be asked to confirm.';
        }
        $fields[] = Spec::field('mode', 'radio', 'Area', ['options' => $modes, 'default' => $current['mode'] ?? 'whole']);
        $fields[] = Spec::field('cx', 'int', 'Centre X', ['min' => -self::LIMIT, 'max' => self::LIMIT, 'default' => 0, 'visible_if' => $vi(['square', 'circle'])]);
        $fields[] = Spec::field('cz', 'int', 'Centre Z', ['min' => -self::LIMIT, 'max' => self::LIMIT, 'default' => 0, 'visible_if' => $vi(['square', 'circle'])]);
        $fields[] = Spec::field('size', 'int', 'Size (blocks)', ['min' => 16, 'max' => 59999968, 'default' => 10000, 'visible_if' => $vi(['square']), 'help' => 'The world border diameter. Use "Read from world" to fill these from level.dat.']);
        if ($new) {
            $fields[] = Spec::field('radius', 'int', 'Radius (blocks)', ['min' => 16, 'max' => self::LIMIT, 'default' => 5000, 'visible_if' => $vi(['circle'])]);
        }
        foreach (['min_x' => 'Min X', 'max_x' => 'Max X', 'min_z' => 'Min Z', 'max_z' => 'Max Z'] as $f => $l) {
            $fields[] = Spec::field($f, 'int', $l, ['min' => -self::LIMIT, 'max' => self::LIMIT, 'visible_if' => $vi(['box'])]);
        }
        if ($nether) {
            $fields[] = Spec::field('nether_ceiling', 'toggle', 'Remove the nether ceiling', ['default' => false, 'help' => 'Hides the bedrock roof (y 90 and above) so the map shows the nether floor.']);
        }
        if ($new) {
            $fields[] = Spec::field('hide', 'repeater', 'Hide areas', ['max_items' => 5, 'help' => 'Cut these boxes out of the map. The label is only kept as a comment in the file.', 'children' => [
                Spec::field('label', 'text', 'Label', ['max' => 64]),
                Spec::field('min_x', 'int', 'Min X', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('max_x', 'int', 'Max X', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('min_z', 'int', 'Min Z', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('max_z', 'int', 'Max Z', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('min_y', 'int', 'Min Y (optional)', ['min' => -2048, 'max' => 4096]),
                Spec::field('max_y', 'int', 'Max Y (optional)', ['min' => -2048, 'max' => 4096]),
            ]]);
        } else {
            $fields[] = Spec::field('hide', 'repeater', 'Hide areas', ['max_items' => 0, 'disabled_reason' => 'Needs BlueMap 5.11+', 'children' => []]);
        }
        $fields[] = Spec::field('explored', 'select', 'Explored chunks only', ['options' => array_map('strval', self::EXPLORED), 'default' => 0, 'help' => 'Skip chunks nobody spent time in. Chunks the world generated but nobody visited stay out of the map.']);

        $edges = [Spec::field('render_edges', 'toggle', 'Show the cut face at the border', ['default' => true, 'help' => 'Off shows x-ray style edges instead.'])];
        if ($this->supports($ctx, 'edge-light-strength')) {
            $edges[] = Spec::field('edge_light_strength', 'slider', 'Edge light strength', ['min' => 0, 'max' => 15, 'step' => 1, 'default' => 15]);
        }

        return [Spec::step('area', 'Area', null, $fields), Spec::step('edges', 'Edges', 'Border tiles can be tidied after a change with a re-render of the edges.', $edges)];
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled']) {
            self::err($e, 'map', 'Pick one of the enabled maps.');
        }
        $new = $this->atLeast($ctx, 11);
        $mode = (string) ($input['mode'] ?? 'whole');
        if (!in_array($mode, $new ? ['whole', 'square', 'circle', 'box'] : ['whole', 'square', 'box'], true)) {
            self::err($e, 'mode', $mode === 'circle' ? 'A circle needs BlueMap 5.11+.' : 'Unknown area type.');
        }
        $L = self::LIMIT;
        if (in_array($mode, ['square', 'circle'], true)) {
            foreach (['cx' => 'Centre X', 'cz' => 'Centre Z'] as $f => $l) {
                if (Check::int($input[$f] ?? null, -$L, $L) === null) {
                    self::err($e, $f, "$l must be a whole number within ±29 999 984.");
                }
            }
        }
        if ($mode === 'square' && Check::int($input['size'] ?? null, 16, 59999968) === null) {
            self::err($e, 'size', 'Size must be 16 to 59 999 968.');
        }
        if ($mode === 'circle' && Check::int($input['radius'] ?? null, 16, $L) === null) {
            self::err($e, 'radius', 'Radius must be 16 to 29 999 984.');
        }
        if ($mode === 'box') {
            $this->checkBox($e, '', $input, false);
        }
        $hide = self::rows($input['hide'] ?? []);
        if ($hide !== [] && !$new) {
            self::err($e, 'hide', 'Hide areas need BlueMap 5.11+.');
        }
        if (count($hide) > 5) {
            self::err($e, 'hide', 'At most 5 hidden areas.');
        }
        foreach ($hide as $i => $h) {
            $this->checkBox($e, "hide.$i.", $h, true);
            if (!Check::blank($h['label'] ?? null) && Check::text($h['label'], 64) === null) {
                self::err($e, "hide.$i.label", 'Label: up to 64 characters, no control characters.');
            }
        }
        if (!array_key_exists((int) ($input['explored'] ?? 0), self::EXPLORED) || Check::int($input['explored'] ?? 0, 0, 72000) === null) {
            self::err($e, 'explored', 'Pick one of the listed values.');
        }
        if (isset($input['edge_light_strength']) && !Check::blank($input['edge_light_strength']) && Check::int($input['edge_light_strength'], 0, 15) === null) {
            self::err($e, 'edge_light_strength', 'Use 0 to 15.');
        }

        return $e;
    }

    /** @param array<string, string> $e */
    private function checkBox(array &$e, string $p, array $in, bool $withY): void
    {
        $L = self::LIMIT;
        $v = [];
        foreach (['min_x', 'max_x', 'min_z', 'max_z'] as $f) {
            $x = Check::int($in[$f] ?? null, -$L, $L);
            if ($x === null) {
                self::err($e, $p . $f, 'Whole number within ±29 999 984.');
            }
            $v[$f] = $x;
        }
        foreach ([['min_x', 'max_x'], ['min_z', 'max_z']] as [$lo, $hi]) {
            if ($v[$lo] !== null && $v[$hi] !== null && $v[$lo] >= $v[$hi]) {
                self::err($e, $p . $hi, 'Max has to be larger than min.');
            }
        }
        if ($withY || isset($in['min_y']) || isset($in['max_y'])) {
            $y = [];
            foreach (['min_y', 'max_y'] as $f) {
                if (Check::blank($in[$f] ?? null)) {
                    $y[$f] = null;
                    continue;
                }
                $y[$f] = Check::int($in[$f], -2048, 4096);
                if ($y[$f] === null) {
                    self::err($e, $p . $f, 'Y must be -2048 to 4096.');
                }
            }
            if (($y['min_y'] ?? null) !== null && ($y['max_y'] ?? null) !== null && $y['min_y'] >= $y['max_y']) {
                self::err($e, $p . 'max_y', 'Max Y has to be larger than min Y.');
            }
        }
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled']) {
            $b->block('Pick one of the enabled maps.');

            return $b->build();
        }
        $file = $m['file'];
        $doc = $this->doc($ctx, $file);
        if ($doc === null) {
            $b->block(basename($file) . ' can not be read or edited safely.');

            return $b->build();
        }
        $label = fn (string $k) => basename($file) . ' · ' . $k;
        $nether = self::dimKey($m['dimension']) === 'the_nether';
        $mode = (string) ($input['mode'] ?? 'whole');
        $area = ['mode' => $mode, 'nether_ceiling' => $nether && Check::bool($input['nether_ceiling'] ?? false), 'hide' => []];
        foreach (['cx', 'cz', 'size', 'radius'] as $f) {
            if (isset($input[$f]) && !Check::blank($input[$f])) {
                $area[$f] = (float) $input[$f];
            }
        }
        foreach (['min_x', 'max_x', 'min_z', 'max_z'] as $f) {
            $area[$f] = isset($input[$f]) && !Check::blank($input[$f]) ? (int) $input[$f] : null;
        }
        foreach (self::rows($input['hide'] ?? []) as $h) {
            $area['hide'][] = [
                'label' => (string) ($h['label'] ?? ''), 'min_x' => (int) $h['min_x'], 'max_x' => (int) $h['max_x'], 'min_z' => (int) $h['min_z'], 'max_z' => (int) $h['max_z'],
                'min_y' => Check::blank($h['min_y'] ?? null) ? null : (int) $h['min_y'], 'max_y' => Check::blank($h['max_y'] ?? null) ? null : (int) $h['max_y'],
            ];
        }

        $maskChanged = false;
        $r = MaskRenderer::renderMask($area, $ctx['version']);
        if (isset($r['block'])) {
            $managed = false;
            if ($doc->has('render-mask')) {
                $raw = (string) $doc->raw('render-mask');
                $stored = $ctx['state']['blocks'][$file . '#render-mask'] ?? null;
                $managed = MaskRenderer::isTemplateMask($raw) || ($stored !== null && hash_equals((string) $stored, sha1($raw)));
                if (!$managed && trim($raw) !== trim($r['block'])) {
                    $b->requireAck('custom render-mask in ' . $file, $acks);
                }
                if (trim($raw) !== trim($r['block'])) {
                    $maskChanged = true;
                }
            } else {
                $maskChanged = $mode !== 'whole' || $area['nether_ceiling'];
            }
            if (!$doc->has('render-mask') || trim((string) $doc->raw('render-mask')) !== trim($r['block'])) {
                $b->upsert($file, 'render-mask', new HoconRaw($r['block']), $label('render-mask'));
            }
            foreach (self::LEGACY as $k) {
                $b->commentOut($file, $k, 'removed by Pelican BlueMap: replaced by render-mask', $label($k));
            }
        } else {
            foreach ($r['scalars'] as $k => $val) {
                $d = $b->doc($file);
                if ($val === null) {
                    if ($d->has($k)) {
                        $b->commentOut($file, $k, 'removed by Pelican BlueMap', $label($k));
                        $maskChanged = true;
                    }
                } elseif (!$d->has($k) || !self::same($d->get($k), $val)) {
                    $b->upsert($file, $k, $val, $label($k));
                    $maskChanged = true;
                }
            }
        }

        $explored = Check::int($input['explored'] ?? 0, 0, 72000) ?? 0;
        $d = $b->doc($file);
        if (($d->has('min-inhabited-time') ? $d->get('min-inhabited-time') : 0) !== $explored) {
            $b->upsert($file, 'min-inhabited-time', $explored, $label('min-inhabited-time'));
        }
        $edgesChanged = false;
        $re = Check::bool($input['render_edges'] ?? true, true);
        $d = $b->doc($file);
        if ((bool) ($d->has('render-edges') ? $d->get('render-edges') : true) !== $re) {
            $b->upsert($file, 'render-edges', $re, $label('render-edges'));
            $edgesChanged = true;
        }
        if ($this->supports($ctx, 'edge-light-strength') && !Check::blank($input['edge_light_strength'] ?? null)) {
            $els = Check::int($input['edge_light_strength'], 0, 15);
            $d = $b->doc($file);
            if ($els !== null && (int) ($d->has('edge-light-strength') ? $d->get('edge-light-strength') : 15) !== $els) {
                $b->upsert($file, 'edge-light-strength', $els, $label('edge-light-strength'));
                $edgesChanged = true;
            }
        }

        if ($maskChanged) {
            $b->warn('BlueMap updates this map by itself after the start and deletes tiles outside the new area.');
        }
        if ($maskChanged || $edgesChanged) {
            $b->post(['action' => 'fix_edges', 'map' => $m['id'], 'required' => false, 'reason' => 'Tidy the border tiles of ' . $m['id'] . ' after the area or edge change.']);
        }

        return $b->build();
    }

    private function docValue(\Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument $doc, string $path, mixed $default): mixed
    {
        return $doc->has($path) ? $doc->get($path) : $default;
    }
}
