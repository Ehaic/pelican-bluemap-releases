<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Filament\Server\Pages;

use App\Enums\SubuserPermission;
use App\Models\Server;
use App\Repositories\Daemon\DaemonServerRepository;
use App\Traits\Filament\BlockAccessInConflict;
use Carbon\Carbon;
use Ehaic\PelicanBlueMap\Exceptions\BlueMapException;
use Ehaic\PelicanBlueMap\Filament\Server\Wizards\ReviewTable;
use Ehaic\PelicanBlueMap\Filament\Server\Wizards\WizardFormFactory;
use Ehaic\PelicanBlueMap\Filament\Server\Wizards\WizardInput;
use Ehaic\PelicanBlueMap\Services\ServerGuard;
use Ehaic\PelicanBlueMap\Support\MinecraftJavaGate;
use Ehaic\PelicanBlueMap\Support\Ui;
use Ehaic\PelicanBlueMap\Wizards\Definitions\RenderWizard;
use Ehaic\PelicanBlueMap\Services\ServerFiles;
use Ehaic\PelicanBlueMap\Wizards\WizardService;
use Filament\Actions\Action;
use Filament\Facades\Filament;
use Filament\Forms\Components\Checkbox;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Toggle;
use Filament\Infolists\Components\TextEntry;
use Filament\Notifications\Notification;
use Filament\Pages\Page;
use Filament\Schemas\Components\Callout;
use Filament\Schemas\Components\Grid;
use Filament\Schemas\Components\Html;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Text;
use Filament\Schemas\Components\Wizard\Step;
use Filament\Schemas\Schema;
use Filament\Support\Enums\Width;
use Filament\Support\Exceptions\Halt;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\HtmlString;
use Livewire\Attributes\Locked;
use Livewire\Attributes\On;
use Throwable;

/**
 * The wizard launcher (docs/WIZARDS.md 7.4): eight cards, the after-start actions and the backups list.
 *
 * Each wizard is a Filament Action modal with steps built from the wizard's own specs; the last step is a Review.
 * Every handler re-checks the permission, WizardService re-checks permission, the stopped server and the plan hash.
 * Nothing here writes a file itself.
 */
class BlueMapCustomisePage extends Page
{
    use BlockAccessInConflict;

    protected static string|\BackedEnum|null $navigationIcon = 'tabler-adjustments';

    protected static ?string $slug = 'bluemap/customise';

    protected static bool $shouldRegisterNavigation = false;

    /** Seconds a wizard's spec + current values are reused while the user clicks through the modal. */
    private const OPEN_TTL = 900;   // a spec stays valid for the whole modal session; mount and every write bump the version

    #[Locked]
    public ?int $serverId = null;

    #[Locked]
    public ?string $knownState = null;

    /** The review the Apply button is bound to. Locked: only this class can set them (the browser can't forge a hash). */
    #[Locked]
    public string $reviewWizard = '';

    #[Locked]
    public string $reviewHash = '';

    #[Locked]
    public string $reviewHtml = '';

    #[Locked]
    public string $reviewDiff = '';

    /** @var list<string> overwrite acknowledgements the plan asks for (the checkbox values are indexes into this) */
    #[Locked]
    public array $reviewAcks = [];

    #[Locked]
    public bool $reviewBlocked = true;

    /** @var list<array<string, mixed>>|null per-request WizardMeta list (protected: not kept between requests) */
    protected ?array $catalogMemo = null;

    protected ?string $catalogError = null;

    protected ?string $stateMemo = null;

    protected bool $openFailureNotified = false;

    /** @var array<string, array<string, mixed>> per-request open() results */
    protected array $openMemo = [];

    /** @var list<array<string, mixed>>|null */
    protected ?array $pendingMemo = null;

    // ------------------------------------------------------------------------------------------------
    // Access, plumbing
    // ------------------------------------------------------------------------------------------------

    public static function canAccess(): bool
    {
        $server = Filament::getTenant();
        if (!$server instanceof Server) {
            return false;
        }

        return parent::canAccess()
            && !$server->isInConflictState()
            && (bool) user()?->can(SubuserPermission::FileRead, $server)
            && MinecraftJavaGate::matches($server);
    }

    public static function shouldRegisterNavigation(): bool
    {
        return false;
    }

    public static function getNavigationLabel(): string
    {
        return static::w('nav');
    }

    public function getTitle(): string
    {
        return static::w('title');
    }

    public function mount(): void
    {
        $this->serverId = $this->server()->id;
        ServerFiles::invalidate((int) $this->serverId);   // a fresh page load reads the files again
        $this->knownState = $this->serverState();
    }

    protected static function w(string $key, array $replace = []): string
    {
        return trans('pelican-bluemap::wizards.' . $key, $replace);
    }

    protected static function wc(string $key, int $count, array $replace = []): string
    {
        return trans_choice('pelican-bluemap::wizards.' . $key, $count, $replace + ['count' => $count]);
    }

    protected function server(): Server
    {
        /** @var Server $server */
        $server = Filament::getTenant();
        abort_if($this->serverId !== null && $this->serverId !== $server->id, 403);

        return $server;
    }

    protected function can(SubuserPermission ...$permissions): bool
    {
        $user = user();
        if ($user === null) {
            return false;
        }
        foreach ($permissions as $permission) {
            if (!$user->can($permission, $this->server())) {
                return false;
            }
        }

        return true;
    }

    protected function canEdit(): bool
    {
        return $this->can(SubuserPermission::FileRead, SubuserPermission::FileUpdate);
    }

    protected function canConsole(): bool
    {
        return $this->can(SubuserPermission::ControlConsole);
    }

    protected function service(): WizardService
    {
        return app(WizardService::class)->forServer($this->server(), user());
    }

    /** Fresh state from Wings, once per request. */
    protected function serverState(): string
    {
        if ($this->stateMemo === null) {
            try {
                $this->stateMemo = app(ServerGuard::class)->forServer($this->server())->state();
            } catch (Throwable $e) {
                report($e);
                $this->stateMemo = 'unknown';
            }
        }

        return $this->stateMemo;
    }

    protected function isStopped(): bool
    {
        return $this->serverState() === 'offline';
    }

    protected function isRunning(): bool
    {
        return $this->serverState() === 'running';
    }

    protected function stateLabel(): string
    {
        $state = $this->serverState();
        $label = trans('pelican-bluemap::strings.state.' . $state);

        return $label === 'pelican-bluemap::strings.state.' . $state ? $state : $label;
    }

    /** The 5 s state poll: re-render only when the server state changed. */
    public function pollServerState(): void
    {
        $this->stateMemo = null;
        $state = $this->serverState();
        if ($state === $this->knownState) {
            $this->skipRender();

            return;
        }
        $this->knownState = $state;
        ServerFiles::invalidate((int) $this->server()->id);   // start/stop: BlueMap may have written its configs meanwhile
        $this->catalogMemo = null;
    }

    /** Target of the 15 s poll on the render wizard's progress step: the re-render is the refresh. */
    public function refreshProgress(): void
    {
        $this->stateMemo = null;
        $this->catalogMemo = null;
    }

    /** @param array<string, mixed>|null $result */
    protected function notify(string $title, ?array $result, bool $ok): void
    {
        $n = Notification::make()->title($title)->body((string) ($result['message'] ?? '') ?: null);
        ($ok ? $n->success() : $n->danger())->send();
    }

    protected function denied(string $title): void
    {
        Notification::make()->title($title)->body(static::w('notify.no_permission'))->danger()->send();
    }

    // ------------------------------------------------------------------------------------------------
    // Data (memoised per request, spec cached for a few seconds)
    // ------------------------------------------------------------------------------------------------

    /** @return list<array<string, mixed>> WizardMeta */
    protected function catalog(): array
    {
        if ($this->catalogMemo === null) {
            try {
                $this->catalogMemo = $this->service()->catalog();
                $this->catalogError = null;
            } catch (BlueMapException $e) {
                $this->catalogMemo = [];
                $this->catalogError = $e->getMessage();
            } catch (Throwable $e) {
                report($e);
                $this->catalogMemo = [];
                $this->catalogError = static::w('launcher.catalog_failed_body');
            }
        }

        return $this->catalogMemo;
    }

    protected function versionKey(): string
    {
        return 'pelican-bluemap:wizver:' . $this->server()->id;
    }

    /** Called after every write so the next open() reads the files again. */
    protected function bumpVersion(): void
    {
        $key = $this->versionKey();
        Cache::add($key, 1, 86400);
        Cache::increment($key);
        ServerFiles::invalidate((int) $this->server()->id);
        $this->openMemo = [];
        $this->catalogMemo = null;
    }

    /**
     * @return array{meta: array<string, mixed>, steps: list<array<string, mixed>>, values: array<string, mixed>, drift: bool}
     */
    protected function openWizard(string $id, ?string $mapId = null): array
    {
        $user = user();
        $key = $id . '|' . ($mapId ?? '');
        if (isset($this->openMemo[$key])) {
            return $this->openMemo[$key];
        }
        // Permission first: a cache hit must not hand the spec to someone who lost file.read.
        if (!$this->can(SubuserPermission::FileRead)) {
            throw new BlueMapException(static::w('notify.no_permission'));
        }
        $cacheKey = $this->openCacheKey($id, $mapId);
        $open = Cache::get($cacheKey);
        if (!is_array($open) || !isset($open['steps'])) {
            $open = $this->service()->open($id, $mapId);
            Cache::put($cacheKey, $open, self::OPEN_TTL);
        }

        return $this->openMemo[$key] = $open;
    }

    /** @return list<array<string, mixed>> PendingAction */
    protected function pending(): array
    {
        if ($this->pendingMemo === null) {
            try {
                $this->pendingMemo = $this->service()->pending();
            } catch (Throwable $e) {
                report($e);
                $this->pendingMemo = [];
            }
        }

        return $this->pendingMemo;
    }

    /**
     * Values for a freshly opened wizard modal. Opening always starts clean: a previous halted review, a stale cached
     * spec or a failed read must not leak into the new modal (a mounted wizard has to be able to leave an error state).
     */
    protected function freshDefaultsFor(string $id): array
    {
        $this->reviewWizard = '';
        $this->reviewHash = '';
        $this->reviewHtml = '';
        $this->reviewDiff = '';
        $this->reviewAcks = [];
        $this->reviewBlocked = true;
        $this->openMemo = [];
        // Mount = the one place where files are read fresh: new version for the spec/catalog caches and the file-read cache.
        $this->bumpVersion();

        return $this->defaultsFor($id);
    }

    protected function openCacheKey(string $id, ?string $mapId): string
    {
        return 'pelican-bluemap:wizopen:' . $this->server()->id . ':' . (user()?->id ?? 0) . ':' . (int) Cache::get($this->versionKey(), 1) . ':' . $id . ':' . ($mapId ?? '');
    }

    /** @return array<string, mixed> wizard step values for the form (spec defaults fill the gaps) */
    protected function defaultsFor(string $id): array
    {
        try {
            $open = $this->openWizard($id);
        } catch (Throwable) {
            return [];
        }
        $out = [];
        foreach (WizardInput::fields($open['steps']) as $f) {
            $name = (string) $f['name'];
            $out[$name] = $open['values'][$name] ?? $f['default'];
        }
        $out['show_diff'] = false;
        $out['acks'] = [];
        $out['confirm'] = false;

        return $out;
    }

    // ------------------------------------------------------------------------------------------------
    // Page content
    // ------------------------------------------------------------------------------------------------

    protected function getHeaderActions(): array
    {
        return [
            Action::make('back')->label(static::w('back'))->icon('tabler-arrow-left')->color('gray')->button()
                ->url(fn () => BlueMapPage::getUrl()),
            $this->backupsAction(),
        ];
    }

    public function content(Schema $schema): Schema
    {
        return $schema->components([
            // Long badge texts (unavailable reasons) must wrap inside the card on phones; layout only, no colours.
            Html::make(new HtmlString('<style>.bm-wrap-badges .fi-badge{white-space:normal;max-width:100%;overflow-wrap:anywhere}</style>')),

            Callout::make(fn () => $this->isStopped() ? static::w('banner.stopped') : static::w('banner.not_stopped', ['state' => $this->stateLabel()]))
                ->key('bluemap-customise-banner')
                ->extraAttributes(['wire:poll.5s' => 'pollServerState'])
                ->status(fn () => $this->isStopped() ? 'success' : 'warning')
                ->description(fn () => $this->isStopped() ? static::w('banner.stopped_body') : static::w('banner.not_stopped_body')),

            Callout::make(static::w('launcher.catalog_failed'))
                ->key('bluemap-customise-failed')
                ->visible(fn () => $this->catalog() === [] && $this->catalogError !== null)
                ->danger()
                ->description(fn () => (string) $this->catalogError),

            $this->pendingSection(),

            Section::make(static::w('launcher.heading'))
                ->key('bluemap-customise-launcher')
                ->visible(fn () => $this->catalog() !== [])
                ->schema(fn () => [
                    Grid::make(['default' => 1, 'md' => 2])->schema(
                        array_map(fn (array $meta) => $this->card($meta), $this->catalog())
                    ),
                ]),
        ]);
    }

    /** @param array<string, mixed> $meta WizardMeta */
    protected function card(array $meta): Section
    {
        $id = (string) $meta['id'];

        return Section::make((string) $meta['title'])
            ->key('bluemap-wizard-card-' . $id)
            ->description((string) $meta['description'])
            ->icon((string) ($meta['icon'] ?? 'tabler-adjustments'))
            ->compact()
            ->headerActions([$this->wizardAction($meta)])
            ->schema([
                TextEntry::make('badges_' . $id)
                    ->hiddenLabel()
                    ->state(fn () => array_keys($this->badges($meta)))
                    ->badge()
                    ->wrap()
                    ->extraAttributes(['class' => 'bm-wrap-badges', 'style' => 'max-width:100%;min-width:0'])
                    ->color(fn (string $state) => $this->badges($meta)[$state] ?? 'gray'),
            ]);
    }

    /** @param array<string, mixed> $meta @return array<string, string> badge text => colour */
    protected function badges(array $meta): array
    {
        $out = [];
        if (!$meta['available']) {
            $out[(string) ($meta['unavailable_reason'] ?: static::w('unavailable'))] = 'warning';
        }
        if (!empty($meta['drift'])) {
            $out[static::w('badge.drift')] = 'warning';
        }
        if (!empty($meta['last_applied_at'])) {
            try {
                $out[static::w('badge.applied', ['when' => Carbon::parse((string) $meta['last_applied_at'])->diffForHumans()])] = 'gray';
            } catch (Throwable) {
            }
        } elseif ($meta['kind'] === 'config') {
            $out[static::w('badge.never')] = 'gray';
        }
        if ((int) ($meta['pending'] ?? 0) > 0) {
            $out[static::wc('badge.pending', (int) $meta['pending'])] = 'info';
        }

        return $out;
    }

    // ---- after-start actions ---------------------------------------------------------------------------

    protected function pendingSection(): Section
    {
        return Section::make(static::w('pending.heading'))
            ->key('bluemap-customise-pending')
            ->visible(fn () => $this->pending() !== [])
            ->schema(fn () => array_map(fn (array $p) => $this->pendingItem($p), $this->pending()));
    }

    /** @param array<string, mixed> $p PendingAction */
    protected function pendingItem(array $p): Section
    {
        $id = (string) $p['id'];
        $action = (string) $p['action'];
        $label = static::wOr('post.' . $action, $action) . (($p['map'] ?? null) !== null ? ' · ' . $p['map'] : '');

        return Section::make($label)
            ->key('bluemap-pending-' . $id)
            ->compact()
            ->description(trim(((string) ($p['reason'] ?? '')) . ' ' . static::w(!empty($p['required']) ? 'pending.required' : 'pending.optional')))
            ->headerActions([
                Action::make('pending_run_' . $id)->label(static::w('pending.run'))->icon('tabler-player-play')->button()
                    ->visible(fn () => $this->canConsole())
                    ->disabled(fn () => !$this->isRunning())
                    ->tooltip(fn () => $this->isRunning() ? static::w('pending.run_title') : static::w('pending.needs_running'))
                    ->action(fn () => $this->runPending($id)),
                Action::make('pending_dismiss_' . $id)->label(static::w('pending.dismiss'))->icon('tabler-x')->color('gray')->button()
                    ->requiresConfirmation()
                    ->action(fn () => $this->dismissPending($id)),
            ])
            ->schema([]);
    }

    protected static function wOr(string $key, string $fallback): string
    {
        $v = static::w($key);

        return $v === 'pelican-bluemap::wizards.' . $key ? $fallback : $v;
    }

    protected function runPending(string $id): void
    {
        if (!$this->canConsole()) {
            $this->denied(static::w('notify.pending_ran'));

            return;
        }
        try {
            $result = $this->service()->runPending($id);
            $this->notify(static::w('notify.pending_ran'), $result, (bool) ($result['ok'] ?? false));
        } catch (BlueMapException $e) {
            $this->notify(static::w('notify.pending_ran'), ['message' => $e->getMessage()], false);
        } catch (Throwable $e) {
            report($e);
            $this->notify(static::w('notify.failed'), ['message' => static::w('notify.failed_unexpected')], false);
        }
        $this->pendingMemo = null;
        $this->catalogMemo = null;
    }

    protected function dismissPending(string $id): void
    {
        if (!$this->can(SubuserPermission::FileRead)) {
            $this->denied(static::w('notify.pending_dismissed'));

            return;
        }
        try {
            $this->service()->dismissPending($id);
            Notification::make()->title(static::w('notify.pending_dismissed'))->success()->send();
        } catch (BlueMapException $e) {
            $this->notify(static::w('notify.failed'), ['message' => $e->getMessage()], false);
        } catch (Throwable $e) {
            report($e);
            $this->notify(static::w('notify.failed'), ['message' => static::w('notify.failed_unexpected')], false);
        }
        $this->pendingMemo = null;
        $this->catalogMemo = null;
    }

    // ------------------------------------------------------------------------------------------------
    // The wizard modal
    // ------------------------------------------------------------------------------------------------

    /** @param array<string, mixed> $meta WizardMeta */
    protected function wizardAction(array $meta): Action
    {
        $id = (string) $meta['id'];
        $console = $meta['kind'] === 'console';

        return Action::make('wizard_' . $id)
            ->label(static::w('start'))->icon('tabler-player-play')->button()->color('primary')
            ->visible(fn () => $this->can(SubuserPermission::FileRead) && (!$console || $this->canConsole()))
            ->disabled(!$meta['available'])
            ->tooltip($meta['available'] ? null : (string) $meta['unavailable_reason'])
            ->modalHeading((string) $meta['title'])
            ->modalWidth(Width::FourExtraLarge)
            ->modalSubmitActionLabel(static::w($console ? 'render.send' : 'review.apply'))
            ->fillForm(fn () => $this->freshDefaultsFor($id))
            ->steps(fn () => $this->stepsFor($id, $console))
            ->modalSubmitAction(fn (Action $action) => $action
                ->disabled(fn () => $this->submitDisabledReason($console) !== null)
                ->tooltip(fn () => $this->submitDisabledReason($console)))
            ->action(fn (array $data, Action $action) => $console ? $this->sendConsole($id, $data, $action) : $this->applyWizard($id, $data, $action));
    }

    protected function submitDisabledReason(bool $console): ?string
    {
        if ($console) {
            return $this->isRunning() ? null : static::w('notify.stopped_required');
        }
        if (!$this->isStopped()) {
            return static::w('review.apply_tooltip_stop', ['state' => $this->stateLabel()]);
        }

        return $this->reviewBlocked ? static::w('review.apply_tooltip_blocked') : null;
    }

    /** @return list<Step> */
    protected function stepsFor(string $id, bool $console): array
    {
        try {
            $open = $this->openWizard($id);
        } catch (Throwable $e) {
            // Never silent: when the spec can't be read the step list collapses to one step, and Filament then ignores
            // Next (its step key no longer matches). Log it and tell the user once per request.
            $e instanceof BlueMapException ? Log::warning('pelican-bluemap: wizard.open_failed wizard=' . $id . ' cause=' . $e->getMessage()) : report($e);
            if (!$this->openFailureNotified) {
                $this->openFailureNotified = true;
                Notification::make('bluemap-wizard-error')->title(static::w('notify.failed'))
                    ->body($e instanceof BlueMapException ? $e->getMessage() : static::w('notify.failed_unexpected'))
                    ->danger()->persistent()->send();
            }

            return [Step::make(static::w('notify.failed'))->key('wizard-step-error')->schema([Text::make($e instanceof BlueMapException ? $e->getMessage() : static::w('notify.failed_unexpected'))])];
        }

        $steps = WizardFormFactory::steps(
            $open['steps'],
            fn (?string $mapId) => $this->openWizard($id, $mapId)['values'],
            $console ? $this->consoleOverrides($id) : [],
        );
        if ($console) {
            return $steps;
        }

        // Review: computed when the user leaves the last input step, shown from the locked review state.
        if ($steps !== []) {
            end($steps)->afterValidation(fn () => $this->buildReview($id));
        }
        $steps[] = Step::make(static::w('review.step'))->key('wizard-step-review')->schema([
            Text::make(static::w('review.intro')),
            Callout::make(fn () => static::w('review.not_stopped'))
                ->visible(fn () => !$this->isStopped())
                ->warning()
                ->description(fn () => static::w('review.not_stopped_body', ['state' => $this->stateLabel()])),
            Html::make(fn () => new HtmlString($this->reviewHtml)),
            CheckboxList::make('acks')
                ->label(static::w('review.ack'))
                ->helperText(static::w('review.ack_help'))
                ->options(fn () => array_combine(array_map('strval', array_keys($this->reviewAcks)), array_map('strval', $this->reviewAcks)) ?: [])
                ->visible(fn () => $this->reviewAcks !== []),
            // Show/hide in the browser (no round trip); the diff HTML is already part of the step.
            Toggle::make('show_diff')->label(static::w('review.show_diff'))->inline(false),
            Html::make(fn () => new HtmlString($this->reviewDiff))
                ->visibleJs('Boolean($get(\'show_diff\'))'),
        ]);

        return $steps;
    }

    /** Fills the locked review state from a fresh preview. Halts the wizard on blockers the user must fix first. */
    protected function buildReview(string $id): void
    {
        $this->reviewWizard = $id;
        $this->reviewHash = '';
        $this->reviewBlocked = true;
        $this->reviewHtml = '';
        $this->reviewDiff = '';
        $this->reviewAcks = [];

        try {
            $open = $this->openWizard($id);
            $input = WizardInput::fromState($open['steps'], $this->wizardData());
            $plan = $this->service()->preview($id, $input);
        } catch (BlueMapException $e) {
            Notification::make('bluemap-wizard-error')->title(static::w('review.failed_to_prepare'))->body($e->getMessage())->danger()->persistent()->send();

            throw new Halt();
        } catch (Throwable $e) {
            report($e);
            Notification::make('bluemap-wizard-error')->title(static::w('review.failed_to_prepare'))->body(static::w('notify.failed_unexpected'))->danger()->persistent()->send();

            throw new Halt();
        }

        $hard = ReviewTable::hardBlockers($plan);
        if ($hard !== []) {
            Notification::make('bluemap-wizard-error')->title(static::w('review.fix_inputs'))->body(implode("\n", array_map('strval', $hard)))->danger()->persistent()->send();

            throw new Halt();
        }

        $labels = [
            'nothing' => static::w('review.nothing'), 'renamed' => static::w('review.renamed'), 'created' => static::w('review.created'),
            'after_start' => static::w('review.after_start'),
        ];
        $post = [];
        foreach (array_keys(\Ehaic\PelicanBlueMap\Wizards\WizardConsole::COMMANDS) as $a) {
            $post[$a] = static::wOr('post.' . $a, $a);
        }
        $this->reviewHtml = ReviewTable::summaryHtml($plan, $labels, $post);
        $this->reviewDiff = ReviewTable::diffHtml($plan, static::w('review.diff_none'), static::w('review.diff_truncated'));
        $this->reviewAcks = array_values(array_map('strval', (array) ($plan['requires_overwrite_ack'] ?? [])));
        $this->reviewHash = (string) $plan['plan_hash'];
        // A plan with only ack blockers is applicable once the boxes are ticked; apply() re-checks all of it.
        $this->reviewBlocked = ($plan['files'] ?? []) === [];
    }

    /** @return array<string, mixed> raw form state of the open action modal */
    protected function wizardData(): array
    {
        $last = array_key_last($this->mountedActions);
        $data = $last === null ? [] : ($this->mountedActions[$last]['data'] ?? []);

        return is_array($data) ? $data : [];
    }

    /** @param array<string, mixed> $data */
    protected function applyWizard(string $id, array $data, Action $action): void
    {
        if (!$this->canEdit()) {
            $this->denied(static::w('notify.apply_failed'));
            $action->halt();
        }
        if ($this->reviewWizard !== $id || $this->reviewHash === '') {
            Notification::make()->title(static::w('notify.apply_failed'))->body(static::w('notify.review_first'))->danger()->send();
            $action->halt();
        }
        if ($this->reviewBlocked) {
            Notification::make()->title(static::w('notify.apply_failed'))->body(static::w('notify.nothing_to_apply'))->warning()->send();

            return;
        }

        try {
            $open = $this->openWizard($id);
            $input = WizardInput::fromState($open['steps'], $data);
            $acks = [];
            foreach ((array) ($data['acks'] ?? []) as $i) {
                if (is_scalar($i) && isset($this->reviewAcks[(int) $i])) {
                    $acks[] = $this->reviewAcks[(int) $i];
                }
            }
            $result = $this->service()->apply($id, $input, $this->reviewHash, $acks);
        } catch (BlueMapException $e) {
            $result = ['ok' => false, 'message' => $e->getMessage(), 'restored' => false];
        } catch (Throwable $e) {
            report($e);
            $result = ['ok' => false, 'message' => static::w('notify.failed_unexpected'), 'restored' => false];
        }

        $this->bumpVersion();
        $this->pendingMemo = null;

        if (!empty($result['ok'])) {
            $this->reviewHash = '';
            $n = Notification::make()->title(static::w('notify.applied'))->body((string) ($result['message'] ?? '') ?: null)->success();
            if ($this->can(SubuserPermission::ControlStart)) {
                $n->actions([Action::make('start_server')->label(static::w('notify.start_server'))->button()->dispatch('bluemap-start-server')->close()]);
            }
            $n->send();

            return;
        }

        if (!empty($result['restored'])) {
            // The write failed half way and every file was put back.
            $this->reviewHash = '';
            Notification::make()->title(static::w('notify.apply_failed'))->body(static::w('notify.restored_nothing_changed'))->danger()->send();

            return;
        }

        // Refused before any write (running server, changed files, ...): keep the modal so nothing is lost.
        Notification::make()->title(static::w('notify.apply_failed'))->body((string) ($result['message'] ?? ''))->danger()->send();
        $action->halt();
    }

    /** Start the server after an apply (same repository call the console page uses). */
    #[On('bluemap-start-server')]
    public function startServer(): void
    {
        $server = $this->server();
        if (!$this->can(SubuserPermission::ControlStart)) {
            $this->denied(static::w('notify.start_failed'));

            return;
        }
        try {
            app(DaemonServerRepository::class)->setServer($server)->power('start')->throw();
            cache()->forget("servers.$server->uuid.status");
            Notification::make()->title(static::w('notify.started'))->success()->send();
        } catch (Throwable $e) {
            report($e);
            Notification::make()->title(static::w('notify.start_failed'))->danger()->send();
        }
        $this->stateMemo = null;
    }

    // ---- render wizard (console only) ------------------------------------------------------------------

    /**
     * Render wizard: the Checks and Progress steps are read-only views, the Action step gets a confirmation box.
     *
     * @return array<string, array{replace: bool, components: list<\Filament\Schemas\Components\Component>}>
     */
    protected function consoleOverrides(string $id): array
    {
        return [
            'checks' => ['replace' => true, 'components' => [Html::make(fn () => new HtmlString($this->checksHtml($id)))]],
            'action' => ['replace' => false, 'components' => [
                Checkbox::make('confirm')
                    ->label(static::w('render.confirm'))->helperText(static::w('render.confirm_help'))
                    ->visibleJs(fn () => WizardFormFactory::visibleJs(['field' => 'action', 'in' => array_values(array_filter(array_keys(RenderWizard::ACTIONS), fn ($a) => $this->isDestructive((string) $a)))])),
            ]],
            'progress' => ['replace' => true, 'components' => [
                Section::make(static::w('render.progress_heading'))
                    ->extraAttributes(['wire:poll.15s' => 'refreshProgress'])
                    ->schema([Html::make(fn () => new HtmlString($this->progressHtml()))]),
            ]],
        ];
    }

    protected function isDestructive(string $action): bool
    {
        return (bool) (RenderWizard::ACTIONS[$action][2] ?? false);
    }

    protected function checksHtml(string $id): string
    {
        $esc = static fn (string $s) => e($s);
        $yes = static::w('render.yes');
        $no = static::w('render.no');
        $rows = [];
        $rows[] = '<strong>' . $esc(static::w('render.checks_running')) . '</strong> ' . ($this->isRunning() ? $yes : $no);
        try {
            $values = $this->openWizard($id)['values'];
            $paused = $values['paused'] ?? null;
            $rows[] = '<strong>' . $esc(static::w('render.checks_paused')) . '</strong> '
                . $esc($paused === null ? static::w('render.checks_paused_unknown') : static::w($paused ? 'render.checks_paused_yes' : 'render.checks_paused_no'));
            $rows[] = '<strong>' . $esc(static::w('render.checks_maps')) . '</strong> ' . $esc(implode(', ', array_map('strval', (array) ($values['maps'] ?? []))) ?: '—');
        } catch (Throwable) {
        }
        $pending = $this->pending();
        if ($pending !== []) {
            $rows[] = '<strong>' . $esc(static::w('render.checks_pending')) . '</strong> '
                . $esc(implode(', ', array_map(fn (array $p) => static::wOr('post.' . $p['action'], (string) $p['action']) . (($p['map'] ?? null) !== null ? ' · ' . $p['map'] : ''), $pending)));
        }

        return implode('', array_map(static fn (string $r) => '<p style="margin:.25rem 0;overflow-wrap:anywhere">' . $r . '</p>', $rows));
    }

    protected function progressHtml(): string
    {
        $p = static fn (string $inner) => '<p style="margin:.25rem 0;overflow-wrap:anywhere">' . $inner . '</p>';
        try {
            $info = $this->service()->progress();
        } catch (Throwable $e) {
            return $p(e($e instanceof BlueMapException ? $e->getMessage() : static::w('notify.failed_unexpected')));
        }
        if (!$info['available']) {
            return $p(e(static::w('render.progress_error', ['error' => (string) ($info['error'] ?? '?')])));
        }
        if ($info['maps'] === []) {
            return $p(e(static::w('render.progress_none')));
        }
        $out = '';
        foreach ($info['maps'] as $m) {
            $line = $m['percent'] === null
                ? static::w('render.progress_line_unknown', ['id' => (string) $m['id'], 'tiles' => (string) ($m['tiles'] ?? 0)])
                : static::w('render.progress_line', ['id' => (string) $m['id'], 'percent' => (string) $m['percent'], 'tiles' => (string) ($m['tiles'] ?? 0)]);
            if ($m['growing'] !== null) {
                $line .= ' · ' . static::w($m['growing'] ? 'render.progress_growing' : 'render.progress_idle');
            }
            $out .= $p(e($line));
        }
        $out .= $p('<span style="color:' . Ui::MUTED . '">' . e(static::w('render.progress_checked', ['time' => Carbon::parse((string) $info['checked_at'])->format('H:i:s')])) . '</span>');

        return $out;
    }

    /** @param array<string, mixed> $data */
    protected function sendConsole(string $id, array $data, Action $action): void
    {
        if (!$this->canConsole()) {
            $this->denied(static::w('notify.console'));
            $action->halt();
        }
        try {
            $open = $this->openWizard($id);
            $input = WizardInput::fromState($open['steps'], $data);
            $act = (string) ($input['action'] ?? '');
            if ($this->isDestructive($act) && empty($data['confirm'])) {
                Notification::make()->title(static::w('notify.console_failed'))->body(static::w('notify.confirm_required'))->danger()->send();
                $action->halt();
            }
            $plan = $this->service()->preview($id, $input);
            $hard = ReviewTable::hardBlockers($plan);
            if ($hard !== []) {
                Notification::make()->title(static::w('notify.console_failed'))->body(implode("\n", $hard))->danger()->send();
                $action->halt();
            }
            $map = ($input['map'] ?? '') === '' ? null : (string) $input['map'];
            $storage = null;
            if ($act === 'storage_delete' && $map !== null) {
                foreach ($this->service()->maps() as $m) {
                    if ($m['id'] === $map) {
                        $storage = $m['storage'];
                    }
                }
            }
            $result = $this->service()->runConsole($act, $map, $storage);
        } catch (Halt $h) {
            throw $h;
        } catch (BlueMapException $e) {
            $result = ['ok' => false, 'message' => $e->getMessage()];
        } catch (Throwable $e) {
            report($e);
            $result = ['ok' => false, 'message' => static::w('notify.failed_unexpected')];
        }
        $this->notify(static::w(!empty($result['ok']) ? 'notify.console' : 'notify.console_failed'), $result, !empty($result['ok']));
        if (empty($result['ok'])) {
            $action->halt();
        }
    }

    // ---- backups ---------------------------------------------------------------------------------------

    protected function backupsAction(): Action
    {
        return Action::make('backups')->label(static::w('backups.open'))->icon('tabler-history')->color('gray')->button()
            ->visible(fn () => $this->can(SubuserPermission::FileRead))
            ->modalHeading(static::w('backups.heading'))
            ->modalDescription(static::w('backups.body'))
            ->modalSubmitActionLabel(static::w('backups.submit'))
            ->modalSubmitAction(fn (Action $action) => $action
                ->disabled(fn () => !$this->isStopped() || !$this->canEdit())
                ->tooltip(fn () => $this->isStopped() ? null : static::w('backups.tooltip_stop', ['state' => $this->stateLabel()])))
            ->schema(fn () => $this->backupsSchema())
            ->action(fn (array $data, Action $action) => $this->doRestore($data, $action));
    }

    /** @return list<string> */
    protected function backupList(): array
    {
        try {
            return $this->service()->backups();
        } catch (Throwable $e) {
            if (!$e instanceof BlueMapException) {
                report($e);
            }

            return [];
        }
    }

    /** "20261110-201208-performance" => "2026-11-10 20:12:08 · performance" */
    public static function backupLabel(string $stamp): string
    {
        if (preg_match('/^(\d{4})(\d{2})(\d{2})-(\d{2})(\d{2})(\d{2})-([a-z][a-z-]*)$/D', $stamp, $m) !== 1) {
            return $stamp;
        }

        return "$m[1]-$m[2]-$m[3] $m[4]:$m[5]:$m[6] · $m[7]";
    }

    /** @return array<int, mixed> */
    protected function backupsSchema(): array
    {
        $list = $this->backupList();
        if ($list === []) {
            return [Text::make(static::w('backups.none'))];
        }

        return [
            Select::make('stamp')->label(static::w('backups.select'))->required()->native(false)
                ->options(collect($list)->mapWithKeys(fn (string $s) => [$s => static::backupLabel($s)])->all()),
            Checkbox::make('confirm')->label(static::w('backups.confirm'))->accepted(),
        ];
    }

    /** @param array<string, mixed> $data */
    protected function doRestore(array $data, Action $action): void
    {
        if (!$this->canEdit()) {
            $this->denied(static::w('notify.restore'));

            return;
        }
        $stamp = (string) ($data['stamp'] ?? '');
        if ($stamp === '' || empty($data['confirm'])) {
            $action->halt();
        }
        try {
            $result = $this->service()->restoreBackup($stamp);
        } catch (BlueMapException $e) {
            $result = ['ok' => false, 'message' => $e->getMessage()];
        } catch (Throwable $e) {
            report($e);
            $result = ['ok' => false, 'message' => static::w('notify.failed_unexpected')];
        }
        $this->bumpVersion();
        $ok = !empty($result['ok']);
        $this->notify(static::w($ok ? 'notify.restore' : 'notify.restore_failed'), ['message' => $ok ? static::w('backups.restored') : (string) ($result['message'] ?? '')], $ok);
        if ($ok && $this->can(SubuserPermission::ControlStart)) {
            // Same start button as after an apply.
            Notification::make()->title(static::w('notify.start_server'))->actions([
                Action::make('start_server')->label(static::w('notify.start_server'))->button()->dispatch('bluemap-start-server')->close(),
            ])->send();
        }
    }
}
