<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Support;

/**
 * Small HTML helpers for the hand-built page fragments. Colours come from the Smoked Glass v4 tokens (--sg-*).
 * The fallbacks are Filament's own colour variables through light-dark(), so with the theme absent the markup
 * still follows Filament's light/dark switch and keeps AA contrast on both backgrounds; no hard-coded palette.
 */
final class Ui
{
    /** Status level => [glyph, token, fallback]. Fallback: text shade for light / dark, same pairs Filament uses (700 / 400; amber needs 800). */
    private const LEVELS = [
        'error' => ['✕', '--sg-red', 'light-dark(var(--danger-700),var(--danger-400))'],
        'warning' => ['▲', '--sg-warn', 'light-dark(var(--warning-800),var(--warning-400))'],
        'ok' => ['✓', '--sg-ok', 'light-dark(var(--success-700),var(--success-400))'],
        'info' => ['●', '--sg-accent', 'light-dark(var(--primary-700),var(--primary-400))'],
    ];

    /** Muted text colour (AA on both themes). */
    public const MUTED = 'var(--sg-muted,light-dark(var(--gray-600),var(--gray-400)))';

    /** Flat inset block (glass inside glass becomes a well). */
    public const WELL = 'var(--sg-well,color-mix(in srgb,currentColor 7%,transparent))';

    /** Status glyph (plain text, coloured by token) in place of colour emoji, which clash with the line-icon set. */
    public static function mark(string $level): string
    {
        [$glyph, $token, $fallback] = self::LEVELS[$level] ?? self::LEVELS['info'];

        return '<span aria-hidden="true" style="display:inline-block;width:1.25em;color:var(' . $token . ',' . $fallback . ')">' . $glyph . '</span>';
    }

    /**
     * One status row. Rows that need attention (error, warning) get a tint and an edge stripe in the status
     * colour (the v4 attention treatment); ok/info rows stay plain. $inner is trusted HTML.
     */
    public static function row(string $level, string $inner, string $extraStyle = ''): string
    {
        $base = 'margin:.35rem 0;overflow-wrap:anywhere;';
        $kind = ['error' => ['--sg-red', 'danger'], 'warning' => ['--sg-warn', 'warning']][$level] ?? null;
        if ($kind !== null) {
            [$token, $fil] = $kind;
            $col = self::LEVELS[$level][2];
            $base .= 'padding:.4rem .65rem;border-radius:var(--sg-radius-sm,.5rem);'
                . 'background:var(' . $token . '-tint,color-mix(in srgb,var(' . $token . ',' . $col . ') 12%,transparent));'
                . 'box-shadow:inset 3px 0 0 var(' . $token . '-edge,color-mix(in srgb,var(' . $token . ',' . $col . ') 50%,transparent));';
        }

        return '<p style="' . $base . $extraStyle . '">' . $inner . '</p>';
    }

    /**
     * Attention stripe for a Filament callout that needs the user (failed install, warning, error). Same idea as the
     * design system's .sg-attn, with a Filament fallback; plain/ok/info callouts get none ('' = no style).
     *
     * @param string $level Filament status: danger|warning|success|info
     */
    public static function attn(string $level): string
    {
        $level = ['danger' => 'error', 'warning' => 'warning'][$level] ?? null;
        if ($level === null) {
            return '';
        }
        $token = $level === 'error' ? '--sg-red' : '--sg-warn';

        return 'border-inline-start:3px solid var(' . $token . '-edge,color-mix(in srgb,var(' . $token . ',' . self::LEVELS[$level][2] . ') 70%,transparent))';
    }

    /** Inline style for a diff line: '+' / '-' / header / context. */
    public static function diffStyle(string $kind): string
    {
        $add = self::LEVELS['ok'];
        $del = self::LEVELS['error'];
        $line = 'padding:0 .35rem;border-radius:3px;';

        // Text is the status colour pulled towards the body text colour: AA on its own 12% tint in both themes.
        $text = static fn (string $token, string $fb) => 'color:color-mix(in srgb,var(' . $token . ',' . $fb . ') 70%,var(--sg-text,CanvasText))';

        return match ($kind) {
            '+' => $line . $text('--sg-ok', $add[2]) . ';background:var(--sg-ok-tint,color-mix(in srgb,var(--sg-ok,' . $add[2] . ') 12%,transparent))',
            '-' => $line . $text('--sg-red', $del[2]) . ';background:var(--sg-red-tint,color-mix(in srgb,var(--sg-red,' . $del[2] . ') 12%,transparent))',
            'h' => 'font-weight:600;margin-top:.5rem;color:var(--sg-ink,light-dark(var(--primary-700),var(--primary-400)))',
            default => $line . 'color:' . self::MUTED,
        };
    }

    /** Wrapper style for a block of diff lines: a flat well in the mono font. */
    public static function diffBlockStyle(): string
    {
        return 'font-family:var(--sg-font-mono,ui-monospace,monospace);font-size:.8rem;white-space:pre-wrap;overflow-wrap:anywhere;'
            . 'padding:.6rem .75rem;border-radius:var(--sg-radius-sm,.5rem);background:' . self::WELL;
    }

    /** Escape $text and render `backtick spans` as code chips ($onTint: keep the row's text colour, for chips inside a tinted status row). Returns an HTML string (wrap in HtmlString). Safe to inject: only the chip markup is added. */
    public static function withCode(string $text, bool $onTint = false): string
    {
        $chip = 'padding:.1em .4em;border-radius:var(--sg-radius-sm,6px);font-family:var(--sg-font-mono,ui-monospace,monospace);font-size:.9em;'
            . 'background:' . self::WELL . ';color:' . ($onTint ? 'inherit' : 'var(--sg-ink,light-dark(var(--primary-700),var(--primary-400)))') . ';overflow-wrap:anywhere';
        $html = preg_replace_callback('/`([^`]+)`/', static fn (array $m) => '<code style="' . $chip . '">' . $m[1] . '</code>', htmlspecialchars($text, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'));

        return (string) $html;
    }
}
