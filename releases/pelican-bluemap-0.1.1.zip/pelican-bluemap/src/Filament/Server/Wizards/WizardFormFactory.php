<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Filament\Server\Wizards;

use Closure;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Filament\Forms\Components\CheckboxList;
use Filament\Forms\Components\ColorPicker;
use Filament\Forms\Components\Radio;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Schemas\Components\Component;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Components\Wizard\Step;

/**
 * Builds Filament form components from the W1 wizard specs (StepSpec / FieldSpec, docs/WIZARDS.md 7.2).
 *
 * The spec is the single source of truth for labels, limits and visibility; the wizard definition's validate() still
 * has the last word on the server, so the limits set here are only for instant feedback in the browser.
 */
final class WizardFormFactory
{
    /**
     * @param list<array<string, mixed>> $steps StepSpec list
     * @param Closure(?string): array<string, mixed> $reload values of the wizard for another map (map-bound wizards)
     * @param array<string, array{replace: bool, components: list<Component>}> $overrides per step id: components that replace or extend the spec's fields
     * @return list<Step>
     */
    public static function steps(array $steps, Closure $reload, array $overrides = []): array
    {
        $live = self::liveFields($steps);
        $names = array_map(static fn (array $f) => (string) $f['name'], WizardInput::fields($steps));
        $out = [];
        foreach ($steps as $step) {
            $components = [];
            foreach ((array) $step['fields'] as $spec) {
                $components[] = self::field($spec, $live, $reload, $names);
            }
            $o = $overrides[(string) $step['id']] ?? null;
            if ($o !== null) {
                $components = $o['replace'] ? $o['components'] : array_merge($components, $o['components']);
            }
            $s = Step::make((string) $step['title'])->key('wizard-step-' . $step['id'])->schema($components);
            if (!empty($step['description'])) {
                $s->description((string) $step['description']);
            }
            $out[] = $s;
        }

        return $out;
    }

    /**
     * Names of fields another field's visible_if depends on: they need ->live().
     *
     * @param list<array<string, mixed>> $steps
     * @return list<string>
     */
    public static function liveFields(array $steps): array
    {
        $live = [];
        foreach (WizardInput::fields($steps) as $f) {
            if (is_array($f['visible_if'] ?? null)) {
                $live[] = (string) $f['visible_if']['field'];
            }
        }

        return array_values(array_unique($live));
    }

    /**
     * @param array<string, mixed> $spec FieldSpec
     * @param list<string> $live names that need ->live()
     * @param list<string> $siblings every top-level field name of the wizard (what a map change or preset may refill)
     */
    public static function field(array $spec, array $live, ?Closure $reload = null, array $siblings = [], bool $child = false): Component
    {
        $name = (string) $spec['name'];
        $type = (string) $spec['type'];
        $c = match ($type) {
            'toggle' => Toggle::make($name)->inline(false),
            'multiselect' => CheckboxList::make($name)->options(self::options($spec))->columns(['default' => 1, 'md' => 2]),
            'radio' => Radio::make($name)->options(self::options($spec)),
            'select' => Select::make($name)->options(self::options($spec))->native(false),
            'map' => Select::make($name)->options(self::options($spec))->native(false)->selectablePlaceholder(false),
            'players' => Select::make($name)->options(self::options($spec))->multiple()->searchable(),
            'int' => self::number(TextInput::make($name)->integer(), $spec),
            'float', 'slider' => self::number(TextInput::make($name), $spec)->step($spec['step'] ?? 'any'),
            'textarea' => Textarea::make($name)->rows(4)->maxLength(is_int($spec['max'] ?? null) ? $spec['max'] : 5000),
            'color' => ColorPicker::make($name),
            'repeater' => self::repeater($spec, $live),
            default => TextInput::make($name)->maxLength(is_int($spec['max'] ?? null) ? $spec['max'] : 255),
        };

        $c->label((string) $spec['label']);
        if (!empty($spec['help'])) {
            $c->helperText((string) $spec['help']);
        }
        if (!empty($spec['warning'])) {
            $c->hint((string) $spec['warning'])->hintColor('warning');
        }
        if (!empty($spec['disabled_reason'])) {
            // dehydrated(): a disabled field is dropped from the submitted data otherwise, and the read-only ids (map id, ...)
            // are exactly what the wizard's validate() keys on (Apply failed with "Unknown map").
            $c->disabled()->dehydrated()->helperText((string) $spec['disabled_reason']);
        }
        if (in_array($name, $live, true)) {
            $c->live();
        }
        if (is_array($spec['visible_if'] ?? null)) {
            // Inside a repeater row $get() is relative to the row, so a child can depend on a sibling of the same map.
            $rule = $spec['visible_if'];
            $c->visible(static fn (Get $get): bool => WizardInput::isVisible($spec, [(string) $rule['field'] => $get((string) $rule['field'])]));
        }

        if (!$child && $type === 'map' && $reload !== null) {
            // A map-bound wizard shows the values of the chosen map: reload them when the map changes.
            $c->live()->afterStateUpdated(static function ($state, Set $set) use ($reload, $siblings, $name): void {
                $values = $reload(is_scalar($state) ? (string) $state : null);
                foreach ($siblings as $f) {
                    if ($f !== $name && array_key_exists($f, $values)) {
                        $set($f, $values[$f]);
                    }
                }
            });
        }
        if (is_array($spec['presets'] ?? null)) {
            // A preset fills the detail fields; "custom" leaves them as they are.
            $presets = $spec['presets'];
            $c->live()->afterStateUpdated(static function ($state, Set $set) use ($presets): void {
                foreach ((array) ($presets[(string) $state] ?? []) as $field => $value) {
                    $set((string) $field, $value);
                }
            });
        }

        return $c;
    }

    /** @param array<string, mixed> $spec @return array<int|string, string> */
    private static function options(array $spec): array
    {
        return array_map('strval', (array) ($spec['options'] ?? []));
    }

    /** @param array<string, mixed> $spec */
    private static function number(TextInput $input, array $spec): TextInput
    {
        $input->numeric();
        if (is_int($spec['min'] ?? null) || is_float($spec['min'] ?? null)) {
            $input->minValue($spec['min']);
        }
        if (is_int($spec['max'] ?? null) || is_float($spec['max'] ?? null)) {
            $input->maxValue($spec['max']);
        }

        return $input;
    }

    /** @param array<string, mixed> $spec @param list<string> $live */
    private static function repeater(array $spec, array $live): Repeater
    {
        $perMap = !empty($spec['per_map']);
        $childLive = self::liveFields([['fields' => (array) ($spec['children'] ?? [])]]);
        $children = [];
        $labelKey = null;
        foreach ((array) ($spec['children'] ?? []) as $child) {
            $children[] = self::field($child, $childLive, null, [], true);
            if ($labelKey === null && in_array($child['type'], ['text', 'int'], true)) {
                $labelKey = (string) $child['name'];
            }
        }
        $r = Repeater::make((string) $spec['name'])
            ->schema($children)
            ->columns(['default' => 1, 'md' => 2])
            ->defaultItems(0)
            ->collapsible()
            ->cloneable(false);
        if (is_int($spec['max_items'] ?? null)) {
            $r->maxItems($spec['max_items']);
        }
        if ($perMap) {
            // One fixed row per map: nothing to add, delete or reorder, every row starts collapsed, header = map id + summary.
            $summary = is_array($spec['summary'] ?? null) ? $spec['summary'] : [];
            $byName = [];
            foreach ((array) ($spec['children'] ?? []) as $child) {
                $byName[(string) $child['name']] = $child;
            }
            $r->addable(false)->deletable(false)->reorderable(false)->collapsed()
                ->itemLabel(static fn (array $state): string => self::rowLabel($state, $summary, $byName));

            return $r;
        }
        if ($labelKey !== null) {
            $r->itemLabel(static fn (array $state): ?string => isset($state[$labelKey]) && is_scalar($state[$labelKey]) && $state[$labelKey] !== '' ? (string) $state[$labelKey] : null);
        }

        return $r;
    }

    /**
     * Header of a collapsed per-map row: "map_id · caves: hide, detail: full". Pure, so it is unit tested.
     *
     * @param array<string, mixed> $state the row's form state
     * @param array<string, string> $summary child field name => short label
     * @param array<string, array<string, mixed>> $specs child FieldSpecs by name
     */
    public static function rowLabel(array $state, array $summary, array $specs): string
    {
        $id = isset($state['id']) && is_scalar($state['id']) ? (string) $state['id'] : '?';
        $parts = [];
        foreach ($summary as $name => $short) {
            if (!array_key_exists($name, $state)) {
                continue;
            }
            $v = $state[$name];
            $type = (string) ($specs[$name]['type'] ?? 'text');
            if ($type === 'toggle') {
                $text = Check::bool($v) ? 'on' : 'off';
            } elseif (is_array($v)) {
                $text = (string) count($v);
            } elseif (!is_scalar($v) || (string) $v === '') {
                $text = '–';
            } else {
                $text = (string) $v;
            }
            $parts[] = $short . ': ' . $text;
        }

        return $parts === [] ? $id : $id . ' · ' . implode(', ', $parts);
    }
}
