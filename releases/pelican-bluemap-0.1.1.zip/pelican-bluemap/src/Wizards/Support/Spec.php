<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Support;

/** Pure builders for FieldSpec / StepSpec arrays (every key always present, docs/WIZARDS.md 7.2). */
final class Spec
{
    /**
     * @param array<string, mixed> $o any FieldSpec key (help, default, options, min, max, step, required, visible_if, children, max_items, warning, disabled_reason, per_map, summary)
     * @return array<string, mixed>
     */
    public static function field(string $name, string $type, string $label, array $o = []): array
    {
        return array_merge([
            'name' => $name, 'type' => $type, 'label' => $label, 'help' => null, 'default' => null, 'options' => null,
            'min' => null, 'max' => null, 'step' => null, 'required' => false, 'visible_if' => null, 'children' => null,
            'max_items' => null, 'warning' => null, 'disabled_reason' => null, 'per_map' => false, 'summary' => null,
        ], $o);
    }

    /**
     * A repeater with one fixed, collapsed row per map: the row header is the map id plus a compact summary.
     * The first child has to be the read-only `id` field; rows can not be added, removed or reordered.
     *
     * @param list<array<string, mixed>> $children
     * @param array<string, string> $summary child field name => short label shown on the collapsed header
     * @param array<string, mixed> $o more FieldSpec keys
     * @return array<string, mixed>
     */
    public static function perMap(string $name, string $label, array $children, array $summary = [], array $o = []): array
    {
        return self::field($name, 'repeater', $label, array_merge(['children' => $children, 'per_map' => true, 'summary' => $summary], $o));
    }

    /** The read-only map id child every per-map row starts with. @return array<string, mixed> */
    public static function mapIdField(): array
    {
        return self::field('id', 'text', 'Map id', ['disabled_reason' => 'Read only']);
    }

    /** @param list<array<string, mixed>> $fields @return array<string, mixed> */
    public static function step(string $id, string $title, ?string $description, array $fields): array
    {
        return ['id' => $id, 'title' => $title, 'description' => $description, 'fields' => $fields];
    }

    /** @return array{field: string, in: list<mixed>} */
    public static function visibleIf(string $field, array $in): array
    {
        return ['field' => $field, 'in' => array_values($in)];
    }
}
