<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconDocument;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconRaw;
use Ehaic\PelicanBlueMap\Wizards\KeyCatalog;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\MaskRenderer;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.1 Maps & dimensions: which maps show up, their names, order, colours, start position; add nether/end. */
final class MapsWizard extends BaseWizard
{
    private const DIMENSIONS = ['overworld' => 'Overworld', 'the_nether' => 'Nether', 'the_end' => 'The End'];

    /** BlueMap's own template values for new dimension maps. */
    private const TEMPLATE = [
        'overworld' => ['sorting' => 0, 'sky' => '#7dabff', 'void' => '#000000', 'ambient' => 0, 'caves' => 55],
        'the_nether' => ['sorting' => 100, 'sky' => '#290000', 'void' => '#150000', 'ambient' => 0.6, 'caves' => -10000],
        'the_end' => ['sorting' => 200, 'sky' => '#080010', 'void' => '#080010', 'ambient' => 0.6, 'caves' => -10000],
    ];

    public function id(): string
    {
        return 'maps';
    }

    protected function title(): string
    {
        return 'Maps & dimensions';
    }

    protected function description(): string
    {
        return 'Choose which worlds and dimensions appear on the map site, and set their names, order, colours and start position.';
    }

    protected function icon(): string
    {
        return 'tabler-world';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        return $this->maps($ctx) === [] ? 'No maps exist yet. Start the server once so BlueMap can create them.' : null;
    }

    public function files(array $ctx): array
    {
        $level = (string) $ctx['level_name'];
        $out = array_column($this->maps($ctx), 'file');
        // trailing "/" = directory existence probe
        foreach ([$level . '/DIM-1/', $level . '/DIM1/', $level . '/dimensions/minecraft/the_nether/', $level . '/dimensions/minecraft/the_end/',
            $level . '_nether/DIM-1/', $level . '_the_end/DIM1/'] as $probe) {
            $out[] = $probe;
        }

        return $out;
    }

    public function current(array $ctx, ?string $mapId): array
    {
        $maps = [];
        $look = [];
        foreach ($this->maps($ctx) as $m) {
            $doc = $this->doc($ctx, $m['file']);
            $name = $doc?->get('name');
            $sort = $doc?->get('sorting');
            $pos = $doc !== null && $doc->has('start-pos') ? $this->parseStartPos((string) $doc->raw('start-pos')) : null;
            $maps[] = [
                'id' => $m['id'], 'dimension' => $m['dimension'] ?? '', 'enabled' => $m['enabled'],
                'name' => is_string($name) && $name !== '' ? $name : $m['id'], 'sorting' => is_int($sort) ? $sort : 0,
            ];
            $look[] = [
                'id' => $m['id'],
                'sky_color' => $this->color($doc, 'sky-color', '#7dabff'), 'void_color' => $this->color($doc, 'void-color', '#000000'),
                'ambient_light' => $this->num($doc, 'ambient-light', 0.0), 'sky_light' => $this->num($doc, 'sky-light', 1.0),
                'start_x' => $pos['x'] ?? null, 'start_z' => $pos['z'] ?? null,
            ];
        }

        return ['maps' => $maps, 'look' => $look, 'add' => []];
    }

    public function steps(array $ctx, array $current): array
    {
        $n = count($this->maps($ctx));
        $s1 = Spec::perMap('maps', 'Maps', [
                Spec::mapIdField(),
                Spec::field('dimension', 'text', 'Dimension', ['disabled_reason' => 'Read only']),
                Spec::field('enabled', 'toggle', 'Show on the map site', ['default' => true]),
                Spec::field('name', 'text', 'Display name', ['required' => true, 'max' => 64]),
                Spec::field('sorting', 'int', 'Order', ['min' => -1000, 'max' => 1000, 'default' => 0, 'help' => 'The lowest number is the default map.']),
        ], ['enabled' => 'shown', 'name' => 'name', 'sorting' => 'order'], [
            'help' => 'One row per map file, all collapsed. Open the ones you want to change. At least one map has to stay on, or BlueMap switches itself off. Disabled maps keep their rendered data until you delete it.',
            'max_items' => $n,
        ]);

        $lookChildren = [
            Spec::mapIdField(),
            Spec::field('sky_color', 'color', 'Sky colour', ['default' => '#7dabff']),
            Spec::field('void_color', 'color', 'Void colour', ['default' => '#000000']),
            Spec::field('ambient_light', 'slider', 'Ambient light', ['min' => 0, 'max' => 1, 'step' => 0.05, 'default' => 0, 'help' => '0 = dark, 1 = every block fully lit.']),
        ];
        if ($this->supports($ctx, 'sky-light')) {
            $lookChildren[] = Spec::field('sky_light', 'slider', 'Sky light', ['min' => 0, 'max' => 1, 'step' => 0.05, 'default' => 1]);
        }
        $lookChildren[] = Spec::field('start_x', 'int', 'Start X', ['min' => -29999984, 'max' => 29999984, 'help' => 'Leave both empty to start at the world spawn.']);
        $lookChildren[] = Spec::field('start_z', 'int', 'Start Z', ['min' => -29999984, 'max' => 29999984]);
        $s2 = Spec::perMap('look', 'Look', $lookChildren, ['sky_color' => 'sky', 'void_color' => 'void', 'ambient_light' => 'ambient', 'start_x' => 'start x', 'start_z' => 'z'], ['max_items' => $n,
            'help' => 'One row per map, all collapsed.']);

        $steps = [Spec::step('maps', 'Maps', null, [$s1]), Spec::step('look', 'Look', 'Colours, light and where the map opens. Changes show up without a re-render.', [$s2])];

        $missing = $this->missingDimensions($ctx);
        if ($missing !== []) {
            $steps[] = Spec::step('add', 'Add a dimension', 'Creates a new map file for a vanilla dimension that has none yet.', [
                Spec::field('add', 'multiselect', 'Dimensions to add', ['options' => $missing, 'default' => []]),
            ]);
        }

        return $steps;
    }

    public function validate(array $ctx, array $input): array
    {
        $e = [];
        $known = array_column($this->maps($ctx), 'id');
        $enabled = 0;
        $seen = [];
        foreach (self::rows($input['maps'] ?? []) as $i => $row) {
            $id = (string) ($row['id'] ?? '');
            if (!in_array($id, $known, true) || isset($seen[$id])) {
                self::err($e, "maps.$i.id", 'Unknown map.');
                continue;
            }
            $seen[$id] = true;
            if (Check::bool($row['enabled'] ?? true, true)) {
                $enabled++;
            }
            if (Check::text($row['name'] ?? null, 64) === null) {
                self::err($e, "maps.$i.name", 'Use 1 to 64 characters, no control characters.');
            }
            if (Check::int($row['sorting'] ?? 0, -1000, 1000) === null) {
                self::err($e, "maps.$i.sorting", 'Use a whole number from -1000 to 1000.');
            }
        }
        if (isset($input['maps']) && $enabled === 0) {
            self::err($e, 'maps', 'Keep at least one map enabled; with no map BlueMap switches itself off.');
        }

        foreach (self::rows($input['look'] ?? []) as $i => $row) {
            if (!in_array((string) ($row['id'] ?? ''), $known, true)) {
                self::err($e, "look.$i.id", 'Unknown map.');
                continue;
            }
            foreach (['sky_color' => 'Sky', 'void_color' => 'Void'] as $f => $l) {
                if (isset($row[$f]) && !Check::blank($row[$f]) && Check::color($row[$f]) === null) {
                    self::err($e, "look.$i.$f", "$l colour must look like #7dabff.");
                }
            }
            foreach (['ambient_light', 'sky_light'] as $f) {
                if (isset($row[$f]) && !Check::blank($row[$f]) && Check::float($row[$f], 0, 1) === null) {
                    self::err($e, "look.$i.$f", 'Use a number from 0 to 1.');
                }
            }
            $x = $row['start_x'] ?? null;
            $z = $row['start_z'] ?? null;
            if (Check::blank($x) !== Check::blank($z)) {
                self::err($e, "look.$i.start_x", 'Enter both start X and start Z, or neither.');
            }
            foreach (['start_x' => $x, 'start_z' => $z] as $f => $v) {
                if (!Check::blank($v) && Check::int($v, -29999984, 29999984) === null) {
                    self::err($e, "look.$i.$f", 'Use a whole number within ±29 999 984.');
                }
            }
        }

        $missing = $this->missingDimensions($ctx);
        foreach ((array) ($input['add'] ?? []) as $d) {
            if (!isset($missing[(string) $d])) {
                self::err($e, 'add', 'That dimension already has a map.');
            }
        }

        return $e;
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        $b = $this->builder($ctx);
        $look = [];
        foreach (self::rows($input['look'] ?? []) as $r) {
            $look[(string) ($r['id'] ?? '')] = $r;
        }
        $rows = [];
        foreach (self::rows($input['maps'] ?? []) as $r) {
            $rows[(string) ($r['id'] ?? '')] = $r;
        }

        $enabledAfter = 0;
        foreach ($this->maps($ctx) as $m) {
            $row = $rows[$m['id']] ?? null;
            $want = $row === null ? $m['enabled'] : Check::bool($row['enabled'] ?? true, true);
            $enabledAfter += $want ? 1 : 0;
        }
        if ($enabledAfter === 0) {
            $b->block('At least one map has to stay enabled: with no valid map BlueMap disables itself.');
        }

        $ids = array_column($this->maps($ctx), 'id');
        foreach ($this->maps($ctx) as $m) {
            $file = $m['file'];
            $row = $rows[$m['id']] ?? null;
            $lk = $look[$m['id']] ?? null;
            $doc = $this->doc($ctx, $file);
            if ($doc === null) {
                $b->warn("{$file} could not be read, so it was skipped.");
                continue;
            }
            $label = fn (string $k) => basename($file) . ' · ' . $k;

            if ($row !== null) {
                $name = Check::text($row['name'] ?? null, 64);
                if ($name !== null && $name !== $doc->get('name')) {
                    $b->upsert($file, 'name', $name, $label('name'));
                }
                $sort = Check::int($row['sorting'] ?? 0, -1000, 1000);
                if ($sort !== null && !self::same($sort, $doc->has('sorting') ? $doc->get('sorting') : 0)) {
                    $b->upsert($file, 'sorting', $sort, $label('sorting'));
                }
            }
            if ($lk !== null) {
                $this->planLook($b, $ctx, $file, $doc, $lk, $label);
            }

            if ($row !== null) {
                $want = Check::bool($row['enabled'] ?? true, true);
                if ($want && !$m['enabled']) {
                    $to = preg_replace('/\.disabled$/', '', $file);
                    if (in_array($m['id'], $ids, true)) {
                        $b->rename($file, (string) $to, basename($file) . ' → ' . basename((string) $to));
                    }
                } elseif (!$want && $m['enabled']) {
                    $b->rename($file, $file . '.disabled', basename($file) . ' → ' . basename($file) . '.disabled');
                    if (!empty($m['storage'])) {
                        $b->post([
                            'action' => 'storage_delete', 'map' => $m['id'], 'storage' => $m['storage'], 'required' => false,
                            'reason' => "Delete the rendered data of the disabled map {$m['id']} (it stays in the {$m['storage']} storage until you do).",
                        ]);
                    }
                }
            }
        }

        $taken = $ids;
        foreach ((array) ($input['add'] ?? []) as $dim) {
            if (isset($this->missingDimensions($ctx)[(string) $dim])) {
                $this->addDimension($b, $ctx, (string) $dim, $taken);
            }
        }

        return $b->build();
    }

    // ------------------------------------------------------------------ plan parts

    private function planLook(PlanBuilder $b, array $ctx, string $file, HoconDocument $doc, array $lk, \Closure $label): void
    {
        foreach (['sky_color' => 'sky-color', 'void_color' => 'void-color'] as $f => $key) {
            if (isset($lk[$f]) && !Check::blank($lk[$f])) {
                $c = Check::color($lk[$f]);
                $cur = $doc->has($key) ? $doc->get($key) : KeyCatalog::KEYS[$key]['default'];
                if ($c !== null && strtolower((string) $cur) !== $c) {
                    $b->upsert($file, $key, $c, $label($key));
                }
            }
        }
        foreach (['ambient_light' => 'ambient-light', 'sky_light' => 'sky-light'] as $f => $key) {
            if (!$this->supports($ctx, $key) || !isset($lk[$f]) || Check::blank($lk[$f])) {
                continue;
            }
            $v = Check::float($lk[$f], 0, 1);
            $cur = $doc->has($key) ? $doc->get($key) : KeyCatalog::KEYS[$key]['default'];
            if ($v !== null && !self::same($v, $cur)) {
                $b->upsert($file, $key, round($v, 3), $label($key));
            }
        }

        $x = $lk['start_x'] ?? null;
        $z = $lk['start_z'] ?? null;
        $cur = $doc->has('start-pos') ? $this->parseStartPos((string) $doc->raw('start-pos')) : null;
        if (!Check::blank($x) && !Check::blank($z)) {
            $xi = Check::int($x, -29999984, 29999984);
            $zi = Check::int($z, -29999984, 29999984);
            if ($xi !== null && $zi !== null && ($cur === null || $cur['x'] !== $xi || $cur['z'] !== $zi)) {
                $b->upsert($file, 'start-pos', ['x' => $xi, 'z' => $zi], $label('start-pos'));
            }
        } elseif (Check::blank($x) && Check::blank($z) && $doc->has('start-pos')) {
            $b->commentOut($file, 'start-pos', 'removed by Pelican BlueMap (world spawn)', $label('start-pos'));
        }
    }

    /** @param array<string, string> $taken */
    private function addDimension(PlanBuilder $b, array $ctx, string $dim, array &$taken): void
    {
        $source = null;
        foreach ($this->maps($ctx) as $m) {
            if ($this->doc($ctx, $m['file']) !== null && ($source === null || (!$source['enabled'] && $m['enabled']) || ($m['enabled'] === $source['enabled'] && self::dimKey($m['dimension']) === 'overworld'))) {
                $source = $m;
            }
        }
        if ($source === null) {
            $b->block('No existing map file could be read to copy from.');

            return;
        }
        $level = (string) $ctx['level_name'];
        $paper = in_array($ctx['loader'] ?? '', ['paper', 'spigot'], true);
        $world = $paper && $dim === 'the_nether' ? $level . '_nether' : ($paper && $dim === 'the_end' ? $level . '_the_end' : $level);

        $base = (string) preg_replace('/\W/', '_', basename($world));
        $id = $base;
        if (in_array($id, $taken, true)) {
            $id = $base . '_' . $dim;
        }
        for ($n = 2; in_array($id, $taken, true); $n++) {
            $id = $base . '_' . $dim . '_' . $n;
        }
        $taken[] = $id;

        $t = self::TEMPLATE[$dim];
        $doc = HoconDocument::parse((string) $ctx['files'][$source['file']]);
        $doc = $doc->upsert('world', $world)->upsert('dimension', 'minecraft:' . $dim)
            ->upsert('name', $level . ' (' . $dim . ')')->upsert('sorting', $t['sorting'])
            ->upsert('storage', 'sql')->upsert('sky-color', $t['sky'])->upsert('void-color', $t['void'])
            ->upsert('ambient-light', $t['ambient'])->upsert('remove-caves-below-y', $t['caves']);
        if ($doc->has('dimension-type')) {
            $doc = $doc->commentOut('dimension-type', 'removed by Pelican BlueMap: unknown for the new dimension');
        }
        if ($doc->has('marker-sets.pelican-pois')) {
            $doc = $doc->remove('marker-sets.pelican-pois');
        }

        $area = ['mode' => 'whole', 'nether_ceiling' => $dim === 'the_nether'];
        $r = MaskRenderer::renderMask($area, $ctx['version']);
        if (isset($r['block'])) {
            $doc = $doc->upsert('render-mask', new HoconRaw($r['block']));
        } else {
            foreach (['min-x', 'max-x', 'min-z', 'max-z', 'min-y', 'max-y'] as $k) {
                if ($doc->has($k)) {
                    $doc = $doc->commentOut($k, 'reset by Pelican BlueMap');
                }
            }
            if ($dim === 'the_nether') {
                $doc = $doc->upsert('max-y', 90);
            }
        }

        $dir = rtrim((string) $ctx['config_dir'], '/') . '/maps/';
        $b->create($dir . $id . '.conf', $doc->text(), "new map {$id} ({$dim})");

        if (!$this->dimensionExists($ctx, $dim, $world)) {
            $b->warn("The {$dim} has no saved chunks yet; it renders once players visit it.");
        }
        $b->post([
            'action' => 'update', 'map' => $id, 'required' => false,
            'reason' => "BlueMap renders the new map {$id} by itself after the start; this only speeds up the first render.",
        ]);
    }

    // ------------------------------------------------------------------ helpers

    /** @return array<string, string> dimension => label for vanilla dimensions with no map file */
    private function missingDimensions(array $ctx): array
    {
        $have = [];
        foreach ($this->maps($ctx) as $m) {
            $have[self::dimKey($m['dimension'])] = true;
        }
        $out = [];
        foreach (self::DIMENSIONS as $k => $label) {
            if (!isset($have[$k])) {
                $out[$k] = $label;
            }
        }

        return $out;
    }

    private function dimensionExists(array $ctx, string $dim, string $world): bool
    {
        if ($dim === 'overworld') {
            return true;
        }
        $level = (string) $ctx['level_name'];
        $probes = $dim === 'the_nether'
            ? [$level . '/DIM-1/', $world . '/DIM-1/', $level . '/dimensions/minecraft/the_nether/']
            : [$level . '/DIM1/', $world . '/DIM1/', $level . '/dimensions/minecraft/the_end/'];
        foreach ($probes as $p) {
            if (($ctx['files'][$p] ?? null) !== null) {
                return true;
            }
        }

        return false;
    }

    /** @return array{x: int, z: int}|null */
    private function parseStartPos(string $raw): ?array
    {
        if (preg_match('/x\s*[:=]\s*(-?\d+).*?z\s*[:=]\s*(-?\d+)/s', $raw, $m) === 1) {
            return ['x' => (int) $m[1], 'z' => (int) $m[2]];
        }

        return null;
    }

    private function color(?HoconDocument $doc, string $key, string $default): string
    {
        $v = $doc !== null && $doc->has($key) ? $doc->get($key) : $default;

        return is_string($v) && Check::color($v) !== null ? (string) Check::color($v) : $default;
    }

    private function num(?HoconDocument $doc, string $key, float $default): float
    {
        $v = $doc !== null && $doc->has($key) ? $doc->get($key) : $default;

        return is_numeric($v) ? (float) $v : $default;
    }
}
