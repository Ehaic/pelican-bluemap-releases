<?php

declare(strict_types=1);

namespace Ehaic\PelicanBlueMap\Wizards\Definitions;

use Ehaic\PelicanBlueMap\Support\ConfigRenderer;
use Ehaic\PelicanBlueMap\Wizards\Hocon\HoconRaw;
use Ehaic\PelicanBlueMap\Wizards\Support\Check;
use Ehaic\PelicanBlueMap\Wizards\Support\PlanBuilder;
use Ehaic\PelicanBlueMap\Wizards\Support\Spec;

/** 4.7 Points of interest: static markers in the managed marker set `pelican-pois`. */
final class MarkersWizard extends BaseWizard
{
    public const SET = 'pelican-pois';
    private const PATH = 'marker-sets.pelican-pois';
    private const LIMIT = 29999984;

    public function id(): string
    {
        return 'markers';
    }

    protected function title(): string
    {
        return 'Points of interest';
    }

    protected function description(): string
    {
        return 'Add spawn, shops and towns as markers on the map.';
    }

    protected function icon(): string
    {
        return 'tabler-map-pin';
    }

    protected function unavailableReason(array $ctx): ?string
    {
        return $this->enabledMaps($ctx) === [] ? 'No enabled map exists yet.' : null;
    }

    public function files(array $ctx): array
    {
        return array_column($this->maps($ctx), 'file');
    }

    /** One row per enabled map; with a map id, just that map's own values (flat). */
    public function current(array $ctx, ?string $mapId): array
    {
        return $mapId === null ? ['maps' => $this->mapRows($ctx)] : $this->currentFor($ctx, $mapId);
    }

    protected function currentFor(array $ctx, string $mapId): array
    {
        $m = $this->pickMap($ctx, $mapId);
        $v = ['map' => $m['id'] ?? null, 'set_label' => 'Points of interest', 'toggleable' => true, 'default_hidden' => false, 'markers' => [], 'edited_outside' => false];
        $doc = $m === null ? null : $this->doc($ctx, $m['file']);
        if ($doc === null || !$doc->has(self::PATH)) {
            return $v;
        }
        $stored = $ctx['state']['blocks'][$m['file'] . '#' . self::PATH] ?? null;
        if ($stored !== null && hash_equals((string) $stored, sha1((string) $doc->raw(self::PATH)))) {
            $saved = $ctx['state']['values'][$m['id']] ?? ($ctx['state']['values'] ?? []);
            foreach (['set_label', 'toggleable', 'default_hidden', 'markers'] as $k) {
                if (isset($saved[$k])) {
                    $v[$k] = $saved[$k];
                }
            }
        } else {
            $v['edited_outside'] = true;
        }

        return $v;
    }

    public function steps(array $ctx, array $current): array
    {
        $children = [
            Spec::mapIdField(),
            Spec::field('dimension', 'text', 'Dimension', ['disabled_reason' => 'Read only']),
            Spec::field('set_label', 'text', 'Marker set name', ['required' => true, 'max' => 64, 'default' => 'Points of interest',
                'help' => 'A set that was edited outside the panel asks for confirmation before it is replaced (a backup is kept).']),
            Spec::field('toggleable', 'toggle', 'Visitors can switch it off', ['default' => true]),
            Spec::field('default_hidden', 'toggle', 'Hidden until switched on', ['default' => false]),
            Spec::field('markers', 'repeater', 'Markers', ['max_items' => 100, 'default' => [], 'help' => 'Markers use the standard map pin icon.', 'children' => [
                Spec::field('label', 'text', 'Label', ['required' => true, 'max' => 64]),
                Spec::field('x', 'int', 'X', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('y', 'int', 'Y', ['required' => true, 'min' => -2048, 'max' => 4096, 'default' => 64]),
                Spec::field('z', 'int', 'Z', ['required' => true, 'min' => -self::LIMIT, 'max' => self::LIMIT]),
                Spec::field('detail', 'textarea', 'Description', ['max' => 500, 'help' => 'Plain text; shown when a visitor clicks the marker.']),
                Spec::field('min_distance', 'int', 'Show from distance', ['min' => 0, 'max' => 10000000]),
                Spec::field('max_distance', 'int', 'Hide beyond distance', ['min' => 0, 'max' => 10000000]),
            ]]),
        ];
        $rows = Spec::perMap('maps', 'Maps', $children, ['markers' => 'markers', 'set_label' => 'set'], ['max_items' => count($this->enabledMaps($ctx)),
            'help' => 'One row per map, all collapsed. Open a map to edit its points of interest; maps you leave alone are not touched.']);

        return [Spec::step('maps', 'Points of interest', null, [$rows])];
    }

    public function validate(array $ctx, array $input): array
    {
        return $this->validateMaps($ctx, $input);
    }

    protected function validateOne(array $ctx, array $input): array
    {
        $e = [];
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled']) {
            self::err($e, 'map', 'Pick one of the enabled maps.');
        }
        if (Check::text($input['set_label'] ?? null, 64) === null) {
            self::err($e, 'set_label', 'Use 1 to 64 characters.');
        }
        $rows = self::rows($input['markers'] ?? []);
        if (count($rows) > 100) {
            self::err($e, 'markers', 'At most 100 markers.');
        }
        foreach ($rows as $i => $r) {
            if (Check::text($r['label'] ?? null, 64) === null) {
                self::err($e, "markers.$i.label", 'Use 1 to 64 characters.');
            }
            foreach (['x' => self::LIMIT, 'z' => self::LIMIT] as $f => $lim) {
                if (Check::int($r[$f] ?? null, -$lim, $lim) === null) {
                    self::err($e, "markers.$i.$f", 'Whole number within ±29 999 984.');
                }
            }
            if (Check::int($r['y'] ?? null, -2048, 4096) === null) {
                self::err($e, "markers.$i.y", 'Y must be -2048 to 4096.');
            }
            $d = $r['detail'] ?? '';
            if (is_string($d) && mb_strlen($d) > 500) {
                self::err($e, "markers.$i.detail", 'At most 500 characters.');
            }
            foreach (['min_distance', 'max_distance'] as $f) {
                if (!Check::blank($r[$f] ?? null) && Check::int($r[$f], 0, 10000000) === null) {
                    self::err($e, "markers.$i.$f", 'Use 0 to 10 000 000.');
                }
            }
        }

        return $e;
    }

    /** The managed block for the input (docs/WIZARDS.md 4.7). */
    public static function render(array $input): string
    {
        $h = fn (string $s) => ConfigRenderer::hoconString($s);
        $ids = [];
        $lines = [];
        foreach (self::rows($input['markers'] ?? []) as $r) {
            $label = trim((string) $r['label']);
            $slug = trim((string) preg_replace('/[^a-z0-9]+/', '-', strtolower($label)), '-');
            $base = 'poi-' . ($slug === '' ? 'marker' : substr($slug, 0, 40));
            $id = $base;
            for ($n = 2; isset($ids[$id]); $n++) {
                $id = $base . '-' . $n;
            }
            $ids[$id] = true;
            $parts = ['type: "poi"', 'position: { x: ' . (int) $r['x'] . ', y: ' . (int) $r['y'] . ', z: ' . (int) $r['z'] . ' }', 'label: ' . $h($label)];
            $detail = trim((string) ($r['detail'] ?? ''));
            if ($detail !== '') {
                $parts[] = 'detail: ' . $h(str_replace(["\r\n", "\n", "\r"], '<br>', htmlspecialchars($detail, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8')));
            }
            $parts[] = 'icon: "assets/poi.svg"';
            $parts[] = 'anchor: { x: 25, y: 45 }';
            foreach (['min_distance' => 'min-distance', 'max_distance' => 'max-distance'] as $f => $k) {
                if (!Check::blank($r[$f] ?? null)) {
                    $parts[] = $k . ': ' . (int) $r[$f];
                }
            }
            $lines[] = '    ' . $id . ': { ' . implode(', ', $parts) . ' }';
        }

        // relative to the key line: the editor adds the key's indent to every continuation line
        return "{\n  # Managed by Pelican BlueMap (points of interest wizard).\n"
            . '  label: ' . $h(trim((string) $input['set_label'])) . "\n"
            . '  toggleable: ' . (Check::bool($input['toggleable'] ?? true, true) ? 'true' : 'false') . "\n"
            . '  default-hidden: ' . (Check::bool($input['default_hidden'] ?? false) ? 'true' : 'false') . "\n"
            . "  sorting: 0\n  markers: {\n" . ($lines === [] ? '' : implode("\n", $lines) . "\n") . "  }\n}";
    }

    public function plan(array $ctx, array $input, array $acks): array
    {
        return $this->planMaps($ctx, $input, $acks);
    }

    protected function planOne(PlanBuilder $b, array $ctx, array $input, array $acks): void
    {
        $m = $this->mapById($ctx, (string) ($input['map'] ?? ''));
        if ($m === null || !$m['enabled'] || $this->doc($ctx, $m['file']) === null) {
            $b->block('Pick an enabled map whose file can be edited.');

            return;
        }
        $file = $m['file'];
        $doc = $this->doc($ctx, $file);
        $block = self::render($input);
        $label = basename($file) . ' · marker-sets.pelican-pois';

        if ($doc->has(self::PATH)) {
            $raw = (string) $doc->raw(self::PATH);
            if (trim($raw) === trim($block)) {
                return;
            }
            $stored = $ctx['state']['blocks'][$file . '#' . self::PATH] ?? null;
            if ($stored === null || !hash_equals((string) $stored, sha1($raw))) {
                $b->requireAck('edited marker set pelican-pois in ' . $file, $acks);
            }
            $b->upsert($file, self::PATH, new HoconRaw($block), $label);
        } elseif ($doc->has('marker-sets')) {
            if ($doc->kind('marker-sets') !== 'object') {
                $b->block('marker-sets in ' . basename($file) . ' is not a block, so the wizard will not edit it.');

                return;
            }
            $b->upsert($file, self::PATH, new HoconRaw($block), $label);
        } else {
            $b->upsert($file, 'marker-sets', new HoconRaw("{\n  " . self::SET . ': ' . str_replace("\n", "\n  ", $block) . "\n}"), basename($file) . ' · marker-sets');
        }
        if (self::rows($input['markers'] ?? []) === []) {
            $b->warn('No markers: the marker set of ' . $m['id'] . ' is written empty.');
        }
    }
}
